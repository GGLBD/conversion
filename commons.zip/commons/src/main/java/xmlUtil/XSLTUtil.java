package xmlUtil;

import java.io.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.*;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import util.FileUtil;

public class XSLTUtil {
	
	public static void main(String args[]) throws Exception{
String homeDir =  "Temp\\LEXUS\\xslt\\";
		 // set the TransformFactory to use the Saxon TransformerFactoryImpl method 
		 System.setProperty("javax.xml.transform.TransformerFactory",
		 "net.sf.saxon.TransformerFactoryImpl");
		  

		 String foo_xml = homeDir + "books.xml"; //input xml
		 String foo_xsl = homeDir + "books.xsl"; //input xsl
		 String foo_html = homeDir + "books.html"; //input xml

         transformer (foo_xml, foo_xsl, foo_html);

		}
	
	/**
	 * transform XML using xslt
	 * set destID = null to output the result to console 
	 */
	public static void transformer(String sourceID, String xslID, String destID)
			throws TransformerException, TransformerConfigurationException, Exception {
		transformer(sourceID, xslID, destID, null, null);
	}
	
	/**
	 * transform XML using xslt
	 * set destID = null to output the result to console 
	 */
	public static void transformer(String sourceID, String xslID, String destID, String paramName1, String paramValue1)
			throws TransformerException, TransformerConfigurationException, Exception {
		transformer(sourceID, xslID, destID, paramName1, paramValue1, null, null);
	}
	
	/**
	 * transform XML using xslt
	 * set destID = null to output the result to console 
	 */
	public static void transformer(
			String sourceID, String xslID, String destID, 
			String paramName1, String paramValue1, String paramName2, String paramValue2)
			throws TransformerException, TransformerConfigurationException, Exception {
		// Create a transform factory instance.
		TransformerFactory tfactory = TransformerFactory.newInstance();

		// Create a transformer for the stylesheet.
		Transformer transformer = tfactory.newTransformer(new StreamSource(
				new File(xslID)));
		
		String sourceStr = FileUtil.reader(sourceID);
		//sourceStr = XMLUtil.removeNonUtf8CompliantCharacters(sourceStr);
		//remove possible leading chars before <?xml ....>
		sourceStr = sourceStr.trim().replaceFirst("^([\\W]+)<","<");
		
		//sourceStr = sourceStr.replace("<!DOCTYPE wi-rl PUBLIC \"-//DOSCO VW//DTD WI-RL R2//DE\" \"wi-rl.dtd\">", "");
		
		
		StreamSource source = new StreamSource(new ByteArrayInputStream(sourceStr.getBytes()));

		if(paramName1!=null){
			transformer.setParameter(paramName1, paramValue1);
		}
		if(paramName2!=null){
			transformer.setParameter(paramName2, paramValue2);
		}
		
		if(destID==null || destID.length() < 1){
			transformer.transform(source,new StreamResult(System.out));
		}else{
			//transformer.transform(new StreamSource(source.getInputStream()),new StreamResult(new File(destID)));
			transformer.transform(source,new StreamResult(new File(destID)));
			//System.out.println("1xml file "+sourceID+ " is transformed into file "+ destID);
		}
	}
	
	/**
	 * transform XML using xslt
	 * Note that if disable-output-escaping used in xslt, this method doesn't support it, since this method transform xml into a DOM rather than a xml string
	 * disable-output-escaping is an instruction to the serializer, that is the component that turns the result tree into 
	 * lexical XML. If your result is not lexical XML but a DOM4J DocumentResult, then d-o-e has no meaning
	 * 
	 * disable-output-escaping is supported by previous transformer method
	 * 
	 */
	public static Document transformer(
			Node srcNode, String xslID,
			String paramName1, String paramValue1, String paramName2, String paramValue2)
			throws TransformerException, TransformerConfigurationException, Exception {
		
		//TODO note: use saxon implmenation instead of java native one
		System.setProperty("javax.xml.transform.TransformerFactory", "net.sf.saxon.TransformerFactoryImpl");
		
		// Create a transform factory instance.
		TransformerFactory tfactory = TransformerFactory.newInstance();
		
		// Create a transformer for the stylesheet.
		Transformer transformer = tfactory.newTransformer(new StreamSource(new File(xslID)));
		
		Source source = new DOMSource(srcNode);

		if(paramName1!=null){
			transformer.setParameter(paramName1, paramValue1);
		}
		if(paramName2!=null){
			transformer.setParameter(paramName2, paramValue2);
		}
		
		DOMResult resultNode = new DOMResult();
		transformer.transform(source, resultNode);
		return (Document)resultNode.getNode();
	}
	
	
	/**
	 * transform XML using xslt
	 * set destID = null to output the result to console 
	 */
	public static Document transformer(Node sourceNode, String xslID)
			throws TransformerException, TransformerConfigurationException, Exception {
		return transformer(sourceNode, xslID,  null, null);
	}
	
	/**
	 * transform XML using xslt
	 * set destID = null to output the result to console 
	 */
	public static Document transformer(Node sourceNode, String xslID,  String paramName1, String paramValue1)
			throws TransformerException, TransformerConfigurationException, Exception {
		return transformer(sourceNode, xslID, paramName1, paramValue1, null, null);
	}
	
	
}
