package elementBeans;

import java.util.Iterator;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import elementBeans.Table.Entry;
import elementBeans.Table.Row;

import util.XMLUtil;

public final class DTCIndexTable extends Table{
	
	public DTCIndexTable(){
		super("DIAGNOSTIC CODE INDEX", 2);
		
		//set default Header Row
		Node n1 = doc.createElement("ptxt");
		n1.setTextContent("DTC");
		Node n2 = doc.createElement("ptxt");
		n2.setTextContent("Description");
		Entry e1 = new Entry(n1);
		Entry e2 = new Entry(n2);
		setHeadRow(new Row(e1,e2));
	}
	
	public static void main(String[] args) throws Exception{
		Table t = new DTCIndexTable();
		
		Node n1 = t.doc.createElement("ptxt");
		n1.setTextContent("this is dtc");
		Node n2 = t.doc.createElement("ptxt");
		n2.setTextContent("this is desc");
		t.addBodyRow(new Row(new Entry(n1.cloneNode(true)), new Entry(n2.cloneNode(true))));
		t.addBodyRow(new Row(new Entry(n1.cloneNode(true)), new Entry(n2.cloneNode(true))));
		System.out.println(XMLUtil.xmlToStringNoHeader(t.getEle()));
	}
}
