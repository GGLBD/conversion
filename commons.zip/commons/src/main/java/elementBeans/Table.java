package elementBeans;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import util.XMLUtil;

public class Table extends ElementBean{
	public enum TableEles{table, title, row, entry};
	
	//optional
	protected String id; //optional
	
	//required
	protected final String title ; 
	protected final int numberOfColumns ; 
	protected Row headRow;
	protected List<Row> bodyRows;
	
	public Table(String title, int numberOfColumns){
		this.title = title;
		this.numberOfColumns = numberOfColumns;
		bodyRows = new ArrayList<>();
	}
	
	public void setHeadRow(Row headRow) {
		if(headRow.entries.size() != numberOfColumns){
			throw new IllegalArgumentException("Number of entries have to match number of columns; entries="
		+headRow.entries.size()+"; number Of Columns="+numberOfColumns);
		}
		this.headRow = headRow;
	}

	public void addBodyRow(Row row) {
		if(row.entries.size() != numberOfColumns){
			throw new IllegalArgumentException("Number of entries have to match number of columns; entries="
		+row.entries.size()+"; number Of Columns="+numberOfColumns);
		}
		this.bodyRows.add(row);
	}
	
	/**
	 * return number of body rows 
	 */
	public int numberOfRows(){
		return bodyRows.size();
	}


	@Override
	public Element getEle() throws Exception{
		String colspec = "";
		for(int i=0; i<this.numberOfColumns; i++){
			colspec += "<colspec colwidth=\"10*\"/>";
		}
		String tableXML = "<table twidth=\"full-pg\" tlead=\"yes\" component-locator=\"isnt\" index-type=\"t-code\"><title>" +
				this.title + "</title><tgroup cols=\"" + this.numberOfColumns + "\" colsep=\"1\" rowsep=\"1\">" +
				colspec + "<thead></thead><tbody></tbody></tgroup></table>";
		
		Element table = (Element)doc.importNode(XMLUtil.parseStr(tableXML).getDocumentElement(), true);
		doc.getDocumentElement().appendChild(table);
		
		if(id != null) table.setAttribute("id", id);
		
		Element thead = (Element)XMLUtil.xpathNode(table, "//thead");
		thead.appendChild(headRow.getEle());
		
		Element tbody = (Element)XMLUtil.xpathNode(table, "//tbody");
		for(Row r: bodyRows){
			tbody.appendChild(r.getEle());	
		}
		
		return table;
	}

	public static class Row extends ElementBean{

		private final List<Entry> entries;
		
		public Row(Entry... entry){
			/*if(entry.length==0){
				throw new IllegalArgumentException("at least one Entry needed");
			}*/
			entries = Arrays.asList(entry);
		}
		
		public void addEntry(Entry entry){
			entries.add(entry);
		}

		@Override
		public Element getEle() {
			Element row = doc.createElement(TableEles.row.toString());
			for(Entry e: entries){
				row.appendChild(e.getEle());
			}
			return row;
		}
	}
	
	public static final class Entry extends ElementBean{

		List<Node> nodes = new ArrayList<>();
		
		public Entry(List<Node> nodes){
			for(Node n:nodes){
				addChildNode(n);
			}
		}
		
		public Entry(Node... nodes){
			for(Node n:nodes){
				addChildNode(n);
			}
		}
		
		public void addChildNode(Node node){
			nodes.add(doc.importNode(node, true));
		}

		@Override
		public Element getEle() {
			Element entry = doc.createElement(TableEles.entry.toString());
			for(Node n: nodes){
				entry.appendChild(n);
			}
			return entry;
		}
	}
	
	public static void main(String[] args) throws Exception{
		Document newDoc = XMLUtil.parseStr("<doc/>");
		
		Table t = new Table("table title", 2);
		
		Node n1 = t.doc.createElement("ptxt");
		n1.setTextContent("this is dtc");
		Node n2 = t.doc.createElement("ptxt");
		n2.setTextContent("this is desc");
		Entry e1 = new Entry(n1);
		Entry e2 = new Entry(n2);
		Row headRow = new Row(e1, e2);
		t.setHeadRow(headRow);
		t.addBodyRow(new Row(new Entry(n1.cloneNode(true)), new Entry(n2.cloneNode(true))));
		t.addBodyRow(new Row(new Entry(n1.cloneNode(true)), new Entry(n2.cloneNode(true))));
		System.out.println(XMLUtil.xmlToStringNoHeader(t.getEle()));
	}
	
}
