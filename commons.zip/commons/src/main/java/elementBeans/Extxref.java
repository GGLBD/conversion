package elementBeans;

import org.w3c.dom.*;

/**
 * 
 * immutable class
 */
public final class Extxref extends Xref {
	
	String document;
	String refid;
	final String filetype = "sgml"; 
	String textContent;
	
	public Extxref(String document){
		this.document = document;
	}
	
	public Extxref(String document, String refid){
		this(document);
		this.refid = refid;
	}
	
	/**
	 * set @refid to null if refid is not needed 
	 */
	public Extxref(String document, String refid, String textContent){
		this(document, refid);
		if(textContent==null){
			this.textContent = "";
		}else{
			this.textContent = textContent;
		}
	}
	
	
	@Override
	public String toString(){
		return String.format("Extxref[refid=%s, document=%s, textContent=%s]", refid, document, textContent);
	}

	@Override
	public Element getEle() throws Exception {
		Element newRef = doc.createElement("extxref");
		newRef.setAttribute("document", document);
		if(refid!=null)
			newRef.setAttribute("extrefid", refid);
		newRef.setTextContent(textContent);
		return newRef;
	}

}
