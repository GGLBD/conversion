package elementBeans;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public abstract class Xref extends ElementBean{
}
