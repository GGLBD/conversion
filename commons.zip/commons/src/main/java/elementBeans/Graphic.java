package elementBeans;

import java.util.Iterator;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import util.XMLUtil;

public final class Graphic extends ElementBean implements Comparable<Graphic>{

	private String gid;
	private String oename;
	private String id;
	private String courtesy;
	private String caption;
	
	public static class Builder{
		//required
		private String gid;
		
		//optional
		private String oename;
		private String id;
		private String courtesy;
		private String caption;
		
		public Builder(String gid){
			this.gid = gid.trim();
		}
		
		public Builder oename(String oename){this.oename = oename.trim(); return this;	}
		public Builder id(String id){this.id = id.trim(); return this;	}
		public Builder courtesy(String courtesy){this.courtesy = courtesy.trim(); return this;	}
		public Builder caption(String caption){this.caption = caption.trim(); return this;	}
	}
	
	public Graphic(Builder builder){
		this.gid = builder.gid;
		this.oename = builder.oename;
		this.id = builder.id;
		this.courtesy = builder.courtesy;
		this.caption = builder.caption;
	}
	
	/**
	 * add a graphic to doc, the graphic need to be repositioned in that doc 
	 */
	public Element addGraphicEle(Document doc){
			Element graphic = doc.createElement("graphic");
			graphic.setAttribute("graphicname",gid);
			if(oename!=null) graphic.setAttribute("oename",oename);
			if(courtesy!=null) graphic.setAttribute("courtesy",courtesy);
			if(id!=null) graphic.setAttribute("id",id);
			return graphic;
	}


	@Override
	public boolean equals(Object o) {
		if(!(o instanceof Graphic)){
			//System.out.println("false g.gid="+((Graphic) o).gid+" this.gid="+this.gid);			
			return false;
		}
		Graphic g = (Graphic) o;
		//System.out.println("g.gid="+g.gid+" this.gid="+this.gid);
		return g.gid.equalsIgnoreCase(this.gid);
	}
	
	@Override
	public int hashCode() {
		for(int i=0; i<gid.length(); i++){
			//GM1234 => 1234
			if(Character.isDigit(gid.charAt(i))){
				//System.out.println("gid=" + gid + " hashCode="+ Integer.parseInt(gid.substring(i)));
				return Integer.parseInt(gid.substring(i));
			}
		}
		System.err.println("Invalid generated_id found:"+gid);
		return 0;
	}
	
	@Override
	public int compareTo(Graphic o) {
		if(this.caption!=null && o.caption!=null){
			return caption.compareTo(o.caption);
		}else{
			return gid.compareTo(o.gid);
		}
	}
	
	public String getGid() {
		return gid;
	}

	public String getOename() {
		return oename;
	}

	public String getId() {
		return id;
	}

	public String getCourtesy() {
		return courtesy;
	}

	public String getCaption() {
		return caption;
	}

	@Override
	public Element getEle() {
		// TODO need implment later
		int j = 1/0;
		System.err.println("Graphic getEle() needed to be implemented first");
		return null;
	}


}
