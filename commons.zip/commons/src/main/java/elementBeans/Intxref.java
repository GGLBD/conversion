package elementBeans;

import org.w3c.dom.*;

/**
 * 
 * immutable class
 */
public final class Intxref extends Xref {
	
	public enum Dest{INFO_OBJ("info-obj"), FTNOTE("ftnote"), LST_ITM("lst-itm"), FIG("fig"), TABLE("tbl");
		
		private String destValue;
		Dest(String destValue){
			this.destValue= destValue;
		}
		
		public String getDestValue(){
			return destValue;
		}
	}
	
	String dest;
	String refid;
	String textContent;
	
	public Intxref(String refid, Dest dest, String textContent){
		this.refid = refid;
		this.dest = dest.getDestValue();
		if(textContent==null){
			this.textContent = "";
		}else{
			this.textContent = textContent;
		}
	}
	
	public Element getEle(){
		Element newRef = doc.createElement("intxref");
		newRef.setAttribute("refid", refid);
		newRef.setAttribute("dest", dest);
		newRef.setTextContent(textContent);
		return newRef;
	}
	
	@Override
	public String toString(){
		return String.format("Intxref[refid=%s, dest=%s, textContent=%s]", refid, dest, textContent);
	}

}
