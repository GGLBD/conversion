package elementBeans;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import util.XMLUtil;

public abstract class ElementBean {
	protected Document doc = SharedDocument.getDoc();
	
	//return an DOM element reflecting the concrete object
	public final Element getEle(Document doc) throws Exception{
		return (Element)doc.importNode(getEle(), true);
	}
	
	public abstract Element getEle() throws Exception;
	
	/*public ElementBean(){
		try {
			doc = XMLUtil.parseStr("<doc id=\"123\"/>");
			System.out.println(doc);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
	/*@Override
	public String toString(){
		try {
			return XMLUtil.xmlToStringNoHeader(this.getEle(null));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}*/
	
	public static class SharedDocument{
		private static Document doc;
		
		private SharedDocument(){};
		
		public static Document getDoc(){
			if(doc==null){
				try {
					doc = XMLUtil.parseStr("<doc/>");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return doc;
		}
	}
}
