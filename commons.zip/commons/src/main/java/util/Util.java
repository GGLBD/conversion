package util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Stack;

public class Util {
	public static final String GX_NOCAPTION = "NO CONTENT";
	public static final String DELIMITER = "@!~@::@";
	public static final String TOOLS_DIR = "src\\main\\resources\\Tools\\";
	public static final String UTIL_RESOURCE_DIR = "resources\\Util\\";
	public static final String PUB_DIR = "\\\\ranger\\data\\Conversion\\SGML_WIP\\ss1819\\";
	//public static final String PUB_DIR = "C:\\Test_Files\\SGML_WIP\\";
	public static final String emptyGIF = TOOLS_DIR + "empty.gif";
	public static final String emptyJPG = TOOLS_DIR + "empty.jpg";
	/**
	 * @param args
	 */
	public static void main(String[] args) {
String connector_name = "connector-name dddd-ffff abc";

String capitalizedConnectorName = Util.capitalizeFirstLetterOfEachWord(connector_name.toLowerCase(), " ") ;
System.out.println("capitalizedConnectorName1=="+capitalizedConnectorName);
capitalizedConnectorName = Util.capitalizeFirstLetterOfEachWord(capitalizedConnectorName, "-") ;
System.out.println("capitalizedConnectorName2=="+capitalizedConnectorName);

	}
	
	//Noninstantiable utility class
	private Util(){
		//prevent instantiation from invoking the private constructor reflectively (Effective Java, item 53)
		//or accidentally invoked from within the class
		throw new AssertionError();
	}
	
	/**
	 * 
	 * capitalize the first letter of each word
	 * @
	 * 	 */
	public static String capitalizeFirstLetterOfEachWord(String givenString) {
	    return capitalizeFirstLetterOfEachWord(givenString, " ");
	}
	
	/**
	 * 
	 * capitalize the first letter of each word
	 * @
	 * 	 */
	public static String capitalizeFirstLetterOfEachWord(String givenString, String wordSeparator) {
	    String[] arr = givenString.split(wordSeparator);
	    StringBuffer sb = new StringBuffer();

	    for (int i = 0; i < arr.length; i++) {
	    	System.out.println("arr[i]=" + arr[i]);
	    	if(arr[i].length() > 0){
		        sb.append(Character.toUpperCase(arr[i].charAt(0)))
	            .append(arr[i].substring(1)).append(wordSeparator);
	    	}

	    }          
	    return sb.toString().substring(0, sb.length()-1);//get rid of the last wordSeparator
	}
	
	/**
	 * use to add package info to existing java files 
	 */
	public static void addPackageInfoToJavaFiles() throws Exception{
		String dir = "C:\\Users\\ss1819\\Downloads\\effective2\\examples\\";
		File d = new File(dir);
		Stack<File> s = new Stack<File>();
		s.add(d);
		System.out.println("added:"+d.getAbsolutePath());
		while(!s.isEmpty()){
			File f = s.pop();
			System.out.println("pop:"+f.getAbsolutePath());
			if(f.getAbsolutePath().contains(" ")){
				f.renameTo(new File(f.getAbsolutePath().replace(" ",  "_")));
			}
			f= new File(f.getAbsolutePath().replace(" ",  "_"));
			File[] kids = f.listFiles();
			for(int i=0; i<kids.length; i++){
				File k = kids[i];
				if(k.isDirectory()){
					s.add(k);
					System.out.println("added:"+k.getAbsolutePath());
				}else if(k.isFile() && k.getName().endsWith("java")){
					System.out.println("k.getName():"+k.getName());
					String packageStr = "package " + k.getAbsolutePath().replace(
							"C:\\Users\\ss1819\\Downloads\\effective2\\", "").replace("\\",".").replace(".java", "") ;
					packageStr = packageStr.substring(0, packageStr.lastIndexOf("."))+ ";" + System.getProperty("line.separator") ;
									
					FileUtil.writer(k.getAbsolutePath(), packageStr + FileUtil.reader(k.getAbsolutePath()));
				}
			}
		}
		System.exit(0);
	}
	
	
	
	//to get three layer dir of a file, fileName with file extension is Ok
	public static String getThreeLayerDir(String fileName){
		//System.out.println("fileName=="+fileName);
		String dir = "";
		String name = fileName;
		//remove possible file extension
		if(fileName.contains("."))
			name = fileName.substring(0, fileName.lastIndexOf(".")).trim();
		//get last three letter/digits
		String d;
		for(int i=0; i<3; i++){
			d = name.substring(name.length()-1);
			name = name.substring(0, name.length()-1);
			dir += d + "\\";
		}
		return dir;
	}
	
	  static final String HEXES = "0123456789ABCDEF";
	  
	  public static String getHex( byte [] raw ) {
	    if ( raw == null ) {
	      return null;
	    }
	    final StringBuilder hex = new StringBuilder( 2 * raw.length );
	    for ( final byte b : raw ) {
	      hex.append(HEXES.charAt((b & 0xF0) >> 4))
	         .append(HEXES.charAt((b & 0x0F)));
	    }
	    return hex.toString();
	  }
	  
	  public static String getHex( String str ) {
		    if ( str == null ) {
		      return null;
		    }
		    final StringBuilder hex = new StringBuilder( 2 * str.length() );
		    for(int i=0; i<str.length(); i++){
		    	char b = str.charAt(i);
			      hex.append(HEXES.charAt((b & 0xF0) >> 4))
			         .append(HEXES.charAt((b & 0x0F)));
		    }
		    return hex.toString();
		  }
	  
	    /**
	     * Convert the byte array to an int starting from the given offset.
	     *
	     * @param b The byte array
	     * @param offset The array offset
	     * @return The integer
	     */
	    public static int byteArrayToInt(byte[] b, int offset) {
	        int value = 0;
	        for (int i = 0; i < b.length; i++) {
	            int shift = (b.length - 1 - i) * 8;
	            value += (b[i + offset] & 0x000000FF) << shift;
	        }
	        return value;
	    }

	
	public static String reverseString(String source) {
		    int i, len = source.length();
		    StringBuffer dest = new StringBuffer(len);

		    for (i = (len - 1); i >= 0; i--)
		      dest.append(source.charAt(i));
		    return dest.toString();
	 }
	
	public static String readFile(String fileName) throws IOException{
		BufferedReader in = new BufferedReader(new FileReader(fileName));
		String content = "";
		String str;
		while ((str = in.readLine()) != null) {
            content +=str;
        }
		
		return content;
	}

}
