package util;

import static util.XMLUtil.parseFile;
import static util.XMLUtil.xmlToStringNoHeader;
import static util.XMLUtil.xpathNode;
import static util.XMLUtil.xpathNodeSet;
import static util.XMLUtil.xpathRemove;

import interfaces.IisIdReferenced;

import java.io.*;
import java.nio.charset.Charset;
import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import xmlUtil.XSLTUtil;

public class MEPSUtil extends Base{

	//public static final int MAX_COLWIDTH = 612;
	//public static final int MAX_COLWIDTH = 100; //max of colwidth should be less than 612, let's take it as 100 
	public static final int MAX_COLWIDTH = 600; //changed from 100 to 600 
	public static final String UNAVAILABL_GRAPHIC_GID = "GEMPTY000";
	String database;
	int count = 0;
	public Connection con;
	public String ARTICLE_WIP_DIR;
	public String GRPHC_PROD_ROOT_DIR;
	public static final String IDPad = "S";
	public static String[] GUIDs = {"A00311476"
		,"A00311477"
		,"A00311561"
		,"A00309594"
		,"A00310326"
		,"A00309594"
		,"A00310997"
		,"A00310978"
		,"A00310825"
		,"A00310997"};
	
	private static final Logger logger = LoggerFactory.getLogger(MEPSUtil.class);
	
	//public static final String MEPS_ARTICLE_WIP_DIR = "\\\\ranger\\data\\MEPS\\Articles\\Wip\\";
	
	public static void main(String[] args) throws Exception {
		//Create a new set of articles out of existing ones for importing into MEPS
		//changeFileNamesAndContent(Util.PUB_DIR+"temp\\", Util.PUB_DIR+"temp\\new\\", "sgm", "4_8K2", "4_8K2_new"); System.exit(0);
		
		MEPSUtil meps = new MEPSUtil("MEPSP");
		
		meps.checkSTUBArticles();System.exit(0);
		
		short[] years = {2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014};
		meps.getAllGUIDsForMakesYearModelBase("Nissan", null, years , null, "%Common%");
		meps.getAllGUIDsForMakesYearModelBase("Infiniti", null, years , null, "%Common%");
		
		meps.getAllGUIDsForMakesYearModelBase("Nissan", null, years , null, "General Information%");
		meps.getAllGUIDsForMakesYearModelBase("Infiniti", null, years , null, "General Information%");
		
		System.exit(0);
		
		meps.copyArticleFromMEPS("A00229960", "..\\data\\");System.exit(0);
	}
	
	public static enum NEW_OLD{
		NEW,
		OLD
	}
	
	/**
	 * change file names and references (intexref and extxref) inside each file from old file name pattern to new file name pattern  
	 * 
	 * for example, we have a list of articles:
	 * 
	 * A004914_4_8K2.sgm
	 * A004915_4_8K2.sgm
	 * 
	 * we run this method against them with old pattern as "4_8K2" , new pattern "4_8K2_New".
	 * 
	 * the result articles will be, plus all strings inside each file will change from "4_8K2" to "4_8K2_New".
	 * 
	 * A004914_4_8K2_New.sgm
	 * A004915_4_8K2_New.sgm
	 */
	static public void changeFileNamesAndContent(String srcDir, String destDir, String fileExt, String oldFileNamePattern, String newFilePattern) throws Exception {
		logger.info("Start of changing file and content");
		
		if(!new File (destDir).exists()){
			FileUtil.flashDir(destDir);
		}

		List<String> files = FileUtil.getAllFilesWithCertainExt(srcDir, fileExt);
		
		for (String file : files) {
			logger.info("changing file and content: "+file);
			String content = FileUtil.reader(srcDir + file);
			content = content.replace(oldFileNamePattern, newFilePattern);
			FileUtil.writer(destDir+file.replace(oldFileNamePattern, newFilePattern),content);
		}
	}
	
	/**
	 * Get Existing generated_ids given a list of oenames
	 * input oenames without file extension
	 * input oenames are case insensitive
	 * 
	 * return a maps of oename->generated_id
	 * 
	 */
	public Map<String, String> getGeneratedIdsGivenOenames(String graphicPrefix) throws Exception{
		Map<String, String> result = new HashMap<>();
		Statement st = con.createStatement();
		String query = "select OE_NAME, GENERATED_ID from OE_TO_GENERATED_ID where GRAPHIC_PREFIX = '" + graphicPrefix + "' " ;
		ResultSet rs = st.executeQuery(query);
		while(rs.next()){
			String oe =  rs.getString("OE_NAME");
			int gid = rs.getInt("GENERATED_ID");
			result.put(oe, "G" + graphicPrefix + gid); 
			//pl("getGeneratedIdsGivenOenames; add oename=" + oe + "; gid=" + gid);
		}
		rs.close();
		st.close();
		//con.close();
		pl("End of getting generated_ids; count= " + result.size());
		return result;
	}
	
	public Map<NEW_OLD, Map<String, String>> getOrCreateGeneratedIdsGivenOenames(String graphicPrefix) throws Exception{
		pl("Starting getGeneratedIdsGivenOenames " + graphicPrefix);
		return getOrCreateGeneratedIdsGivenOenames(null, graphicPrefix);
	}
	
	/**
	 * Get Existing generated_ids for existing oenames or generate new generated_id for new oenames <br>
	 * input oenames without file extension  <br>
	 * input oenames are case insensitive <br>
	 * 
	 * set rawGxs to empty Set or null to return all generated_ids with graphicPrefix
	 * 
	 * return two maps of oename->generated_id, first map is for new oenames, second is for existing oenames;
	 * 
	 */
	public Map<NEW_OLD, Map<String, String>> getOrCreateGeneratedIdsGivenOenames(Set<String> rawGxs, String graphicPrefix) throws Exception{
		pl("Start getGeneratedIdsGivenOenames " + graphicPrefix);
		
		Set<String> gxsInUpperCase = new HashSet<>();
		
		if(rawGxs != null){
			gxsInUpperCase = rawGxs.stream()
	                .map(String::toUpperCase)
	                .collect(Collectors.toSet());
		}

		Map<NEW_OLD, Map<String, String>> result = new HashMap<>();

		Map<String, String> newOenames = new HashMap<>();
		Map<String, String> existingOenames = new HashMap<>();
		result.put(NEW_OLD.NEW, newOenames);
		result.put(NEW_OLD.OLD, existingOenames);
		
		
		int maxId = 1000000;
		
		Set<String> existingOes = new HashSet<>();
		
		//collect existing oenames from database
		Statement st = con.createStatement();
		String query = "select OE_NAME, GENERATED_ID from OE_TO_GENERATED_ID where GRAPHIC_PREFIX = '" + graphicPrefix + "' order by GENERATED_ID " ;
		ResultSet rs = st.executeQuery(query);
		while(rs.next()){
			String oe =  rs.getString("OE_NAME");
			existingOes.add(oe);
			maxId = Math.max(maxId,rs.getInt("GENERATED_ID"));
		}

		pl("existing oename:" + existingOes.size() + "; maxId:" + maxId);
		
		//insert new oenames
		List<String> statements = new ArrayList<String>();
		for(String gx: gxsInUpperCase){
			  
			if(!existingOes.contains(gx)){
				String insertQuery = "insert into OE_TO_GENERATED_ID(ID, GRAPHIC_PREFIX, OE_NAME, GENERATED_ID) "
						+ "values(OE_TO_GENERATED_ID_SEQ.NEXTVAL, '"  + graphicPrefix + "', '" + gx +"', " +  ++maxId + ")";
				pl("insertQuery="+insertQuery);
				statements.add(insertQuery);
			}
		}
		pl("Inserting oenames; count=" + statements.size());
		SQLUtil.batchDML(con, statements);
		
		//Now we should have all the oenames inserted 
		st = con.createStatement();
		query = "select OE_NAME, GENERATED_ID from OE_TO_GENERATED_ID where GRAPHIC_PREFIX = '" + graphicPrefix + "'" ;
		ResultSet rs1 = st.executeQuery(query);
		while(rs1.next()){
			String oe =  rs1.getString("OE_NAME");
			int gid = rs1.getInt("GENERATED_ID");
			if(rawGxs == null){
				existingOenames.put(oe, graphicPrefix + gid);
			}
			else if(gxsInUpperCase.contains(oe)){
				if(existingOes.contains(oe)){
					existingOenames.put(oe, graphicPrefix + gid);
					pl("existingOenames add:" + oe + "; " + graphicPrefix + gid);
				}
				else{
					newOenames.put(oe, graphicPrefix + gid);
					pl("newOenames add:" + oe + "; " + graphicPrefix + gid);
				}
			}
		}
		rs.close();
		rs1.close();
		
		return result;
	}
	
	/**
	 * @CLEANME Given a Node, split this Node on <splitOnEle> elements, 
	 * return a list of copies of Node, each Node only contains a limit number of <splitOnEle> 
	 * to make sure its size is less than input size parameter,
	 * 
	 * Then, if Node really got split, remove the given Node from document at the end
	 */
	public static List<Document> splitElement_OnSize(Document n, String splitOnEle, int maxSize) throws Exception{
		logger.info("Size Splitting on element "+splitOnEle);
		List<Document> returnList = new ArrayList<Document>();
		int fileSize = xmlToStringNoHeader(n).length();
		if(fileSize > maxSize){
			int numOfFiles = fileSize/maxSize + 1;
			int sizePerFile = fileSize/numOfFiles;
			int size = 0;
			int fileNo = 0;
			NodeList splitEles = xpathNodeSet(n, "//"+splitOnEle);
			for(int i=0; i<splitEles.getLength(); i++){
				Element splitEle = (Element)splitEles.item(i);
				size += xmlToStringNoHeader(splitEle).length();
				if(size > sizePerFile){
					size = 0;
					fileNo++;
				}
				splitEle.setAttribute("group", fileNo + "");
			}
			for(int i=0; i<=fileNo; i++ ){
				Document newDoc = XMLUtil.parseStr(XMLUtil.xmlToStringNoHeader(n));
				xpathRemove(newDoc, "//"+splitOnEle+"[@group!='" + i + "']");
				returnList.add(newDoc);
			}
		}else{
			returnList.add(n);
		}
		return returnList;
	}
	
	/**
	 * wrap up all child <lst-itm> into a list, insert these non-lst-itm nodes between <lst-itm> into its preceding <lst-itm> 
	 */
	public static void wrapLstItmIntoList(Document doc) throws Exception{
		while(XMLUtil.xpathNodeSet(doc, "//*[lst-itm and name(.) != 'list']").getLength() > 0 )
		{
			NodeList ns = XMLUtil.xpathNodeSet(doc, "//*[lst-itm and name(.) != 'list' and not(lst-itm/lst-itm)]");
			
			for(int i=0; i<ns.getLength(); i++){
				Element ele = (Element)ns.item(i);
	//if(ele.getAttribute("id").equals("0000000010481734S0201")){				logger.info("Start logging");			}
				Element list = createList(doc);
				NodeList children = XMLUtil.xpathNodeSet(ele, "/node()");
				Node currentEle = null ;
				Node currentLstItm = null ;
				for(int j=0; j<children.getLength(); j++){
					Node child = children.item(j);

					//logger.info("child::" + child.getNodeName() + " text():" + child.getTextContent());
					
					if("lst-itm".equals(child.getLocalName())){
						currentLstItm = list.appendChild(child);
						//logger.info("append to List: child::" + currentLstItm.getNodeName() + " text():" + currentLstItm.getTextContent());
					}else if("info-obj".equals(child.getLocalName())){
						currentEle = child;
						//logger.info("Break info-obj:" + child.getTextContent());
						break;
					}else{
						if(currentLstItm != null){
							currentLstItm.appendChild(child);
							//logger.info("append to Lst-itm: child::" + child.getNodeName() + " text():" + child.getTextContent());
						}
					}
				}
				ele.insertBefore(list,currentEle);
			}
		}

	}
	
	/*
	 * 	public static void wrapLstItmIntoList(Document doc, List<String> lstItemElementNames) throws Exception{
		String lstItemElements = "";
		for(String ele: lstItemElementNames){
			lstItemElements += "|" + ele;
		}
		lstItemElements = lstItemElements.substring(1);
		
		logger.info("lstItemElements:"+lstItemElements);
		
		NodeList ns = XMLUtil.xpathNodeSet(doc, "//*[" + lstItemElements +" and name(.) != 'list']");
		
		
		
		for(int i=0; i<ns.getLength(); i++){
			Element ele = (Element)ns.item(i);
			if(ele.getAttribute("id").equals("0000000010481734S0201")){
				logger.info("Start logging");
			}
			Element list = createList(doc);
			//NodeList children = ele.getChildNodes();
			NodeList children = XMLUtil.xpathNodeSet(ele, "/node()");
			for(int j=0; j<children.getLength(); j++){
				Node child = children.item(j);
				logger.info("child::" + child.getNodeName() + " text():" + child.getTextContent());
				if(lstItemElementNames.contains(child.getLocalName())){
					list.appendChild(child);
					logger.info("append to List: child::" + child.getNodeName() + " text():" + child.getTextContent());
				}else{
					if(list.getChildNodes().getLength() > 0){
						if(child.getNodeType() == Node.ELEMENT_NODE){
							ele.insertBefore(list, child);
							list = createList(doc);
							logger.info("Create a new List: child::" + child.getNodeName() + " text():" + child.getTextContent());
						}
						else{
							list.appendChild(child);
						}
					}


				}
			}
			if(list.getChildNodes().getLength() > 0){
				ele.appendChild(list);
			}
		}
	}*/

	private static Element createList(Document doc){
		Element list = doc.createElement("list");
		list.setAttribute("enumtype", "arabicnum");
		list.setAttribute("type",  "ordered");
		return list;
	}
	
	/**
	 * Return all GUIDs in ascending order, Only include articles in WIP and APPR status, exclude articles in "BLOCK", "BATCH" and "DEL"
	 */
	public List<String> getALL_MEPS_GUIDs() throws Exception{
		logger.info("Start getting all Article GUIDs");

		Statement st = con.createStatement();
		List<String> result = new ArrayList<>();
		
		//obj_st_cd in ('WIP','APPR','BLOCK','BATCH','DEL')
		//String query = "SELECT ARTICLE_GUID FROM MEPS.ARTICLE WHERE OBJ_ST_CD in ('WIP','APPR') and title != 'STUB' ";
		String query = "SELECT ARTICLE_GUID FROM MEPS.ARTICLE WHERE OBJ_ST_CD = 'APPR' and title != 'STUB' ";
		ResultSet rs = st.executeQuery(query);

		while(rs.next()){
			result.add(rs.getString(1));
		}
		rs.close();
		
		Collections.sort(result);
		logger.info("Article GUIDs: "+result.size());
		return result;
	}
	
	public MEPSUtil(String MEPSDB)throws Exception{
		database = MEPSDB;
		con = getMEPSConnect(database);			
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT OWNER, PATH FROM MEPS.PATH_INFO");
		//ResultSet rs = stmt.executeQuery("SELECT OWNER, PATH FROM EDDB-TST.PATH_INFO");
		//SQLUtil.displayResultSet(rs);
		while(rs.next()){
			String owner = rs.getString("OWNER");
			String path = rs.getString("PATH");
			if(!path.endsWith("\\")){
				path = path + "\\";
			}
			if(owner.equalsIgnoreCase("ARTICLE_WIP")){
				ARTICLE_WIP_DIR = path;
			}
			if(owner.equalsIgnoreCase("GRPHC_PROD_ROOT")){
				GRPHC_PROD_ROOT_DIR = path;
			}
		}
	}
	
	public static Document doStandardCleanUpTransform(Document doc) throws Exception{
		Document resultDoc = (Document) doc.cloneNode(true);
		
		int layerOfLists = 0;
		String xpath = "(//list"; //  (//list)[1] return first matching element
		while(XMLUtil.xpathNode(resultDoc, xpath + ")[1]") != null)
		{
			layerOfLists++;
			xpath += "//list";
		}
		logger.info("layerOfLists:"+layerOfLists);
		
		String xslID = Util.TOOLS_DIR + "xslt\\" + "cleanup_List.xsl";
		if(layerOfLists>0){
			for (int i = 0; i < layerOfLists; i++) {
				resultDoc = XSLTUtil.transformer(resultDoc, xslID);
			}
			XMLUtil.xpathRemoveAtt(resultDoc, "cleaned", "//*[@cleaned]");
		}
		
		xslID = Util.TOOLS_DIR + "xslt\\" + "cleanup_ptxt.xsl";
		resultDoc = XSLTUtil.transformer(resultDoc, xslID);

		xslID = Util.TOOLS_DIR + "xslt\\"  + "cleanup_misc.xsl";
		resultDoc = XSLTUtil.transformer(resultDoc, xslID);
		
		return resultDoc;
	}
	
	/**
	 * return a set of graphic generated_id given what the generated_ids look like
	 * i.e  "GM%" to return all generated_ids from GM graphics, "GC%" for Chrysler
	 */
	public Set<String> getGraphicGenerated_IDs(String likeClause) throws Exception{
		logger.info("Start getting all generated_id like "+likeClause);
		Set<String> graphics = new HashSet<>();
		Statement stmt = this.con.createStatement();
		String query = "SELECT GENERATED_ID FROM MEPS.GRPHC_ASSET where generated_id like '" + likeClause.toUpperCase() + "'";
		ResultSet rs = stmt.executeQuery(query);
		while(rs.next()){
			String result = rs.getString(1).toUpperCase();
			graphics.add(result);
		}
		logger.info("End of getting all generated_id; count="+graphics.size());
		return graphics;
	}
	
	/**
	 * find all STUB articles from MEPS
	 * for STUB aritcles without src_guid can be safely deleted (means no extxrefs are pointing to these STUB articles any more) <p>
	 * 
SELECT  distinct a.ARTICLE_GUID src_guid, A.ORG_FILE_NAME src_file,  d.article_guid stub_guid,D.ORG_FILE_NAME stub_file, D.CREATED_DATE
FROM MEPS.ARTICLE a join MEPS.article_incl b on a.article_id = b.article_id 
join MEPS.ARTICLE_INFO_OBJECT c on B.ARTICLE_INFO_OBJECT_ID = C.ARTICLE_INFO_OBJECT_ID right  outer join MEPS.article d on c.article_id = d.article_id
where D.TITLE = 'STUB'  order by  stub_guid
	 */
	public void checkSTUBArticles()throws Exception{
		Statement st = con.createStatement();
		String query = "SELECT  distinct a.ARTICLE_GUID src_guid, A.ORG_FILE_NAME src_file,  d.article_guid stub_guid,D.ORG_FILE_NAME stub_file, D.CREATED_DATE "+
		"FROM MEPS.ARTICLE a join MEPS.article_incl b on a.article_id = b.article_id "+
		"join MEPS.ARTICLE_INFO_OBJECT c on B.ARTICLE_INFO_OBJECT_ID = C.ARTICLE_INFO_OBJECT_ID right  outer join MEPS.article d on c.article_id = d.article_id "+
		"where D.TITLE = 'STUB'  order by  stub_guid ";
		ResultSet rs = st.executeQuery(query);
		boolean hasSTUB = false;
		logger.info(" src_guid,  src_file,        stub_guid,     stub_file,   CREATED_DATE");
		System.out.println(" src_guid,  src_file,        stub_guid,     stub_file,   CREATED_DATE");
		while(rs.next()){
			hasSTUB= true;
			String src_guid = rs.getString(1);
			String src_file = rs.getString(2);
			String stub_guid = rs.getString(3);
			String stub_file = rs.getString(4);
			String CREATED_DATE = rs.getString(5);
			System.err.println( src_guid + "  " +  src_file + "  " +  stub_guid + "  " + stub_file + "  " +  CREATED_DATE);
		}
		if(!hasSTUB){
			logger.info("NO STUB articles found in MEPS");
		}else{
			
		}
	}
	
	public static Element createInfo(Document doc, String id, String title){
		Element infoObj = doc.createElement("info-obj");
		infoObj.setAttribute("id", id);
		Node titleNode = doc.createElement("title");
		titleNode.setTextContent(title);
		infoObj.appendChild(titleNode);
		return infoObj;
	}
	
	public static Element createFigure(Document doc, String graphicname, String oename, String courtesy, String caption){
		String actualOename = oename;
    	if(oename.length() > 32){ //oename max length is 32 in MEPS database
    		actualOename = oename.substring(0, 32);
    	}
    	Element figure = doc.createElement("figure");
    	Element graphic = doc.createElement("graphic");
    	Element captionNode = doc.createElement("caption");
    	figure.appendChild(graphic);
    	figure.appendChild(captionNode);
    	graphic.setAttribute("graphicname", graphicname);
    	graphic.setAttribute("oename", actualOename);
    	graphic.setAttribute("courtesy", courtesy);
    	captionNode.setTextContent(caption);
    	
    	
		return figure;
	}
	
	/**
	 * Get a list of articles which have extxrefs which point to given info-obj ids
	 * return a map with entry<"article GUID",  a list of "target info-obj id", >
	 */
	public Map<String, Set<String>> getReferArticlesFromObjInfoIDs(List<String> infoObjIDs)throws Exception{
		logger.info("Start of getting refer article lists from InfoObuIDs, size()="+infoObjIDs.size());
		int MAX_ITEMS_IN_A_QUERY = 900; //maximum number of expressions in a list is 1000
		Map<String, Set<String>> map = new HashMap<>();
		Statement st = con.createStatement();
		
		List<String> ids = new ArrayList<>(infoObjIDs);
		while(!ids.isEmpty()){
			int batchCount= Math.min(ids.size(), MAX_ITEMS_IN_A_QUERY);
			String idStr = "";
			for(int k=0; k<batchCount; k++){
				idStr += ",'" + ids.remove(0)+ "'";
			}
			idStr = idStr.substring(1);
			
			String query = "SELECT  a.ARTICLE_GUID src_guid, C.INFO_OBJECT_GUID target_INFO_OBJECT_GUID, d.article_guid target_guid " +
	        "FROM MEPS.ARTICLE a join MEPS.article_incl b on a.article_id = b.article_id   " +
	        "join MEPS.ARTICLE_INFO_OBJECT c on B.ARTICLE_INFO_OBJECT_ID = C.ARTICLE_INFO_OBJECT_ID   " +
	        "join MEPS.article d on c.article_id = d.article_id  " +
	        "where C.INFO_OBJECT_GUID in ( " + idStr + "  ) ";
			
			logger.info("getReferArticlesFromObjInfoIDs query="+query);
			
			ResultSet rs = st.executeQuery(query);

			while(rs.next()){
				String referArticleGUID = rs.getString(1);
				String infoObjID = rs.getString(2);
				
				if(!map.containsKey(referArticleGUID)){
					map.put(referArticleGUID, new HashSet<String>());
				}
				Set<String> set = map.get(referArticleGUID);
				set.add(infoObjID);
				
				logger.info("getReferArticlesFromObjInfoIDs; add:"+infoObjID+"  "+referArticleGUID);
			}
		}
		
		logger.info("End of getting refer article lists from InfoObuIDs, resulting items size()="+map.size());
		return map;
	}
	
	/**
	 * given a list of GUIDs, get their status info from database, then write into outputFile 
	 */
	public void getArticleStatus(List<String> GUIDs, String outputFile) throws Exception{
		if(GUIDs.size()==0){
			System.err.println("GUID list is empty");
			return;
		}
		
		StringBuilder result = new StringBuilder();
		List<String> tempGUIDs = new ArrayList<String>(GUIDs);
		Statement st = con.createStatement();
		
		while(tempGUIDs.size() > 0){
			StringBuilder guidBuilder = new StringBuilder();
			//Cannot put more than 1000 items in SQL IN clause
			int endIndex = Math.min(900, tempGUIDs.size());
			for(int i=0; i<endIndex; i++){
				guidBuilder.append( ",'" + tempGUIDs.get(0).trim() + "'");
				tempGUIDs.remove(0);
			}

			String guidStr = guidBuilder.toString().substring(1);
			
			String query = "SELECT  ARTICLE_GUID,  OBJ_ST_CD, APPR_DT,  CREATED_USER_ID, ORG_FILE_NAME, CREATED_DATE,  LAST_UPDT_USER,    LAST_UPDT_DT, TITLE " +
							"FROM MEPS.ARTICLE where article_guid in(" + guidStr + ")";
			ResultSet rs = st.executeQuery(query);
			
			
			while(rs.next()){
				result.append(rs.getString(1) + "," + rs.getString(2) + "," +rs.getString(3) + "," +rs.getString(4) + "," +rs.getString(5) + "," +
			rs.getString(6) + "," +rs.getString(7) + "," +rs.getString(8)  + "," +rs.getString(9) + "\n" );
			}
			rs.close();
		}
		
		FileUtil.writer(outputFile, result.toString());
		logger.info("Article status info output to file "+outputFile);
	}
	
	/**
	 * Either manufacture or makes have to be null to avoid confusion. <div>
	 * 
	 * given manufacture (i.e Chrysler), makes (i.e ford) , years (i.e 2011, 2012) and model (i.e focus), return all associated GUIDs from MEPS, ordered by GUIDs
	 * input makes are case-insensitive <p>
	 * 
	 * e.g input: null, "Ford", [2011,2012], "focus"
	 * return [A00284837, A00284838, A00284839, ...]
	 * return all 2011 and 2012 articles for make Ford (not manufacture Ford, which also include other makes, such as Lincoln, Mercury, etc. <div>
	 * 
	 * e.g input: "Chrysler", null, [2012], null
	 * return [A00284837, A00284838, A00284839]
	 * return all 2012 articles for all makes of Chrysler manufacture, such as Dodge, Jeep, Eagle ...
	 * @param som1SchemaOnly TODO
	 */
	public List<String> getAllGUIDsForMakesYearModel(String manufacture, String[] makes, short[] years, String model, String titleLike, boolean som1SchemaOnly) throws Exception{
		logger.info("Start of getting all GUIDs for manufacture:" + manufacture + "; makes:"+Arrays.toString(makes)+"; years:"+Arrays.toString(years)+"; model:"+model);
		if(manufacture!=null && makes!=null){
			throw new Exception("Either specify manufacture or makes, but not both");
		}
		
		String[] localMakes = makes;
		if(manufacture != null){
			Object[] values = getMakesForManufacture(manufacture).toArray();
			localMakes = Arrays.copyOf(values, values.length, String[].class);
			logger.info("localMakes:" + Arrays.toString(localMakes));
		}
		
		String  makeClause;
		if(localMakes != null){
			makeClause = "upper(make.nm) in (";
			for(String s: localMakes){
				makeClause += "'" + s.toUpperCase() + "',";
			}
			makeClause = makeClause.substring(0, makeClause.length()-1) + ") ";
		}else{
			makeClause = "1=1";
		}
		//logger.info("makeClause:" + makeClause);
		
		String yearsClause = "";
		if(years!=null){
			for(short s: years){
				yearsClause += "or (meps.qlfy_Veh.yr_begin <= " + s + " and meps.qlfy_Veh.yr_end >= " + s + ")";
			}
			yearsClause = yearsClause.substring(3);//get ride of "or "
		}else{
			yearsClause = "1=1";
		}

		
		String modelStr = "";
		if(model!=null && model.trim().length()>0){
			modelStr = " and upper(meps.model.nm) = '" + model.toUpperCase() + "' ";
		}
		
		String titleLikeStr = "";
		if(titleLike != null && titleLike.trim().length()>0){
			titleLikeStr = " and title like '" + titleLike.toUpperCase() + "' ";
		}
		
		String DTDBranch = "";
		if(som1SchemaOnly){
			DTDBranch = " AND MEPS.DTD_BRANCH.DTD_ID = 66 "; // 66 is the DTD id for <som1>
		}
			
		Statement st = con.createStatement();
	
		String query = "SELECT  MEPS.ARTICLE.ARTICLE_GUID"+
				//"       , MEPS.ARTICLE.ORG_FILE_NAME"+
				" FROM  meps.article"+
				"        INNER JOIN (meps.make"+
				"                    INNER JOIN (((meps.article_qlfy_veh"+
				"                                  INNER JOIN meps.qlfy_veh"+
				"                                    ON meps.article_qlfy_veh.qlfy_veh_id ="+
				"                    meps.qlfy_veh.qlfy_veh_id)"+
				"                                 INNER JOIN meps.qlfy_veh_model"+
				"                                   ON meps.qlfy_veh.qlfy_veh_id ="+
				"                                      meps.qlfy_veh_model.qlfy_veh_id)"+
				"                                INNER JOIN meps.model"+
				"                                  ON meps.qlfy_veh_model.model_id = meps.model.model_id " + modelStr + ")"+
				"                      ON meps.make.make_id = meps.model.make_id)"+
				"          ON meps.article.article_id = meps.article_qlfy_veh.article_id"+
				"          join meps.dtd_branch on MEPS.ARTICLE.DTD_BRANCH_ID = MEPS.DTD_BRANCH.DTD_BRANCH_ID"+
				"  WHERE " + makeClause + 
				"  and (" + yearsClause + ")"+
				 titleLikeStr + 
			    DTDBranch + 
				//"    order by ARTICLE_GUID";
		"    order by title";
		
		logger.debug(	"getAllGUIDsForMakesYearModel query=="+query);
		ResultSet rs = st.executeQuery(query);
		
		List<String> values = new ArrayList<>();
		while(rs.next()){
			if(!values.contains(rs.getString(1))){
				values.add(rs.getString(1));
			}
			
		}
		rs.close();
		logger.info("Number of GUIDs retrieved:"+values.size());
		
		logger.info("First 100 GUIDs:");
		for(int i=0; i<Math.min(values.size(), 100000); i++){
			logger.info("GUID"+i+":"+values.get(i));
		}
		
		return values;
	}
	
	/**
	 * Either manufacture or makes have to be null to avoid confusion. <div>
	 * 
	 * given manufacture (i.e Chrysler), makes (i.e ford) , years (i.e 2011, 2012) and model (i.e focus), return 
	 * MEPS.ARTICLE.ARTICLE_GUID, meps.qlfy_Veh.yr_begin, meps.qlfy_Veh.yr_end, meps.make.nm, meps.model.nm, title <p>
	 * 
	 * e.g input: null, "Ford", [2011,2012], "focus"
	 * return [[A00152451, 2000, 2000, Infiniti, I30, COMMON SPECS & PROCEDURES], [A00308910, 2001, 2001, Infiniti, I30, COMMON SPECS & PROCEDURES], ...]
	 * return all 2011 and 2012 articles for make Ford (not manufacture Ford, which also include other makes, such as Lincoln, Mercury, etc. <div>
	 * 
	 * e.g input: "Chrysler", null, [2012], null
	 * return [[A00152433, 2000, 2000, Infiniti, I30, COMMON SPECS & PROCEDURES], [A00308934, 2001, 2001, Infiniti, I30, COMMON SPECS & PROCEDURES], ...]
	 * return all 2012 articles for all makes of Chrysler manufacture, such as Dodge, Jeep, Eagle ...
	 */
	public List<String[]> getAllGUIDsForMakesYearModelBase(String manufacture, String[] makes, short[] years, String model, String titleLike) throws Exception{
		logger.info("Start of getting all GUIDs, year_begin, year_end, make, model, title info for manufacture:" + manufacture + "; makes:"+Arrays.toString(makes)+"; years:"+Arrays.toString(years)+"; model:"+model);
		if(manufacture!=null && makes!=null){
			throw new Exception("Either specify manufacture or makes, but not both");
		}
		
		String[] localMakes = makes;
		if(manufacture != null){
			Object[] values = getMakesForManufacture(manufacture).toArray();
			localMakes = Arrays.copyOf(values, values.length, String[].class);
			logger.info("localMakes:" + Arrays.toString(localMakes));
		}
		
		String  makeClause;
		if(localMakes != null){
			makeClause = "upper(make.nm) in (";
			for(String s: localMakes){
				makeClause += "'" + s.toUpperCase() + "',";
			}
			makeClause = makeClause.substring(0, makeClause.length()-1) + ") ";
		}else{
			makeClause = "1=1";
		}
		//logger.info("makeClause:" + makeClause);
		
		String yearsClause = "";
		if(years!=null){
			for(short s: years){
				yearsClause += "or (meps.qlfy_Veh.yr_begin <= " + s + " and meps.qlfy_Veh.yr_end >= " + s + ")";
			}
			yearsClause = yearsClause.substring(3);//get ride of "or "
		}else{
			yearsClause = "1=1";
		}

		
		String modelStr = "";
		if(model!=null && model.trim().length()>0){
			modelStr = " and upper(meps.model.nm) = '" + model.toUpperCase() + "' ";
		}
		
		String titleLikeStr = "";
		if(titleLike != null && titleLike.trim().length()>0){
			titleLikeStr = " and title like '" + titleLike.toUpperCase() + "' ";
		}
			
		Statement st = con.createStatement();
	
		String query = "SELECT  distinct MEPS.ARTICLE.ARTICLE_GUID, meps.qlfy_Veh.yr_begin, meps.qlfy_Veh.yr_end, meps.make.nm, meps.model.nm, title"+
				//"       , MEPS.ARTICLE.ORG_FILE_NAME"+
				" FROM  meps.article"+
				"        INNER JOIN (meps.make"+
				"                    INNER JOIN (((meps.article_qlfy_veh"+
				"                                  INNER JOIN meps.qlfy_veh"+
				"                                    ON meps.article_qlfy_veh.qlfy_veh_id ="+
				"                    meps.qlfy_veh.qlfy_veh_id)"+
				"                                 INNER JOIN meps.qlfy_veh_model"+
				"                                   ON meps.qlfy_veh.qlfy_veh_id ="+
				"                                      meps.qlfy_veh_model.qlfy_veh_id)"+
				"                                INNER JOIN meps.model"+
				"                                  ON meps.qlfy_veh_model.model_id = meps.model.model_id " + modelStr + ")"+
				"                      ON meps.make.make_id = meps.model.make_id)"+
				"          ON meps.article.article_id = meps.article_qlfy_veh.article_id"+
				"          join meps.dtd_branch on MEPS.ARTICLE.DTD_BRANCH_ID = MEPS.DTD_BRANCH.DTD_BRANCH_ID"+
				"  WHERE " + makeClause + 
				"  and (" + yearsClause + ")"+
				 titleLikeStr + 
			//	"    and MEPS.DTD_BRANCH.DTD_ID = 66 " + // 66 is the DTD id for <som1>, but seems not all <som1> are marked as 66, such as A00161595
				
				//"    order by ARTICLE_GUID";
		//"    order by title";
		"    order by make.nm, model.nm, yr_begin";
		
		logger.info(	"getAllGUIDsForMakesYearModel query=="+query);
		ResultSet rs = st.executeQuery(query);
		
		List<String[]> values = new ArrayList<>();
		while(rs.next()){
			String[] items = new String[6];
			items[0] = rs.getString(1);
			items[1] = rs.getString(2);
			items[2] = rs.getString(3);
			items[3] = rs.getString(4);
			items[4] = rs.getString(5);
			items[5] = rs.getString(6);
			values.add(items);
			
		}
		rs.close();
		logger.info("Number of records retrieved:"+values.size());
		
		logger.info("First 100 GUIDs:");
		for(int i=0; i<Math.min(values.size(), 1100); i++){
			//logger.info("GUID"+i+":"+ Arrays.toString(values.get(i)));
			logger.info("GUID" +  String.format("%1$4d:", i) +  Arrays.toString(values.get(i)));
		}
		
		return values;
	}
	
	/**
	 * return a list of makes of a given manufacture
	 * i.e given "Chrysler", return "Chrysler, Dodge, Eagle, Jeep ..."
	 * given "Ford", return "Ford, Lincoln, Mercury, Merkur"
	 */
	private List<String> getMakesForManufacture(String manufacture) throws Exception{
		Statement st = con.createStatement();
		
		String query = " SELECT DISTINCT a.nm as make " +
				" FROM meps.make a JOIN MFR_MKT_REGN b" +
				" on A.MFR_MKT_REGN_ID = B.MFR_MKT_REGN_ID" +
				" join MFR c" +
				" on B.VEH_MFR_ID = C.MFR_ID" +
				" where upper(C.NM) = '" + manufacture.toUpperCase() + "'" + 
				" order by a.nm";
		
		logger.info("getMakesForManufacture query=="+query);
		ResultSet rs = st.executeQuery(query);
		
		List<String> values = new ArrayList<>();
		while(rs.next()){
			values.add(rs.getString(1));
		}
		
		rs.close();
		logger.info("Makes retrieved:"+values.toString());
		return values;
	}
	
	/**
	 * given makes (i.e toyota, volov) and years (2011, 2012), return all associated GUIDs from MEPS, ordered by GUIDs
	 * input makes are case-insensitive
	 * e.g input: ["Lexus", "Scion", "Toyota"], [2011,2012]
	 * return [A00284837, A00284838, A00284839]
	 */
	public List<String> getAllGUIDsForMakesAndYears(String[] makes, short[] years) throws Exception{
		return getAllGUIDsForMakesYearModel(null, makes, years, null, null, true);
	}
	

	/**
	 * Give a maufacture and years, return a list of GUIDs
	 * inputs are case-insensitive
	 */
	public List<String> getAllGUIDsForManufactureAndYears(String manufacture, short[] years) throws Exception{
		return getAllGUIDsForMakesYearModel(manufacture, null, years, null, null, true);
	}
	
/*
	public List<String> getAllGUIDsForMakesAndYears(String[] makes, short[] years) throws Exception{
		logger.info("Start of getting all GUIDs for makes:"+makes+"; years:"+years);
		
		String makesStr = "";
		for(String s:makes){
			makesStr += ",'" + s.toUpperCase() + "'";
		}
		makesStr = makesStr.substring(1);
		
		String yearsClause = "";
		for(short s: years){
			yearsClause += "or (meps.qlfy_Veh.yr_begin <= " + s + " and meps.qlfy_Veh.yr_end >= " + s + ")";
		}
		yearsClause = yearsClause.substring(3);//get ride of "or "
			
		Statement st = con.createStatement();
		
		
		String query = "SELECT distinct  MEPS.ARTICLE.ARTICLE_GUID"+
				//"       , MEPS.ARTICLE.ORG_FILE_NAME"+
				" FROM  meps.article"+
				"        INNER JOIN (meps.make"+
				"                    INNER JOIN (((meps.article_qlfy_veh"+
				"                                  INNER JOIN meps.qlfy_veh"+
				"                                    ON meps.article_qlfy_veh.qlfy_veh_id ="+
				"                    meps.qlfy_veh.qlfy_veh_id)"+
				"                                 INNER JOIN meps.qlfy_veh_model"+
				"                                   ON meps.qlfy_veh.qlfy_veh_id ="+
				"                                      meps.qlfy_veh_model.qlfy_veh_id)"+
				"                                INNER JOIN meps.model"+
				"                                  ON meps.qlfy_veh_model.model_id ="+
				"                               meps.model.model_id)"+
				"                      ON meps.make.make_id = meps.model.make_id)"+
				"          ON meps.article.article_id = meps.article_qlfy_veh.article_id"+
				"          join meps.dtd_branch on MEPS.ARTICLE.DTD_BRANCH_ID = MEPS.DTD_BRANCH.DTD_BRANCH_ID"+
				"  WHERE upper(make.nm) in ( " + makesStr + ")"+
				"  and (" + yearsClause + ")"+
				"    and MEPS.DTD_BRANCH.DTD_ID = 66 -- 66 is the DTD id for <som1>"+
				"    order by MEPS.ARTICLE.ARTICLE_GUID";
		
		logger.info("query=="+query);
		ResultSet rs = st.executeQuery(query);
		
		List<String> values = new ArrayList<>();
		while(rs.next()){
			values.add(rs.getString(1));
		}
		rs.close();
		logger.info("Number of GUIDs retrieved:"+values.size());
		
		logger.info("First 100 GUIDs:");
		for(int i=0; i<Math.min(values.size(), 100); i++){
			logger.info("GUID"+i+":"+values.get(i));
		}
		
		return values;
	}*/
	
	
	/**
	 * Given a table element, if the col span is more than 1, fix <entry> col span when it is the only entry inside a row 
	 * 
	 *       <tgroup COLS="5" COLSEP="1" ROWSEP="1">
       <colspec COLNAME="col1" COLWIDTH="269*"/>
       <colspec COLNAME="col2" COLWIDTH="312*"/>
       <colspec COLNAME="col3" COLWIDTH="577*"/>
       <colspec COLNAME="col4" COLWIDTH="585*"/>
       <colspec COLNAME="colspec0" COLWIDTH="600*"/>
	 */
	public static void fixTableEntryColSpan(Node doc) throws Exception{ 
		NodeList ns1 = XMLUtil.xpathNodeSet(doc, "//table", "//chart");
		for(int j=0; j<ns1.getLength(); j++){
			Element table =  (Element)ns1.item(j);
			String startCol = XMLUtil.xpathStr(table, "//colspec[1]/@COLNAME");
			String endCol = XMLUtil.xpathStr(table, "//colspec[last()]/@COLNAME");
			if(startCol.equals(endCol)){
				//pl("table row span is 1, nothing to fix");
				continue;
			}
			NodeList ns = XMLUtil.xpathNodeSet(table, "//row[count(entry)=1]/entry");
			for(int i=0; i<ns.getLength(); i++){
				// <entry  NAMEEND="colspec0" NAMEST="col1" >
				Element entry =  (Element)ns.item(i);
				if(entry.getAttribute("NAMEST").trim().isEmpty()){
					pl("fixing fixTableEntryColSpan, entry="+XMLUtil.xmlToStringNoHeader(entry));
					entry.setAttribute("NAMEST", startCol);
					entry.setAttribute("NAMEEND", endCol);
					pl("after fixing fixTableEntryColSpan, entry="+XMLUtil.xmlToStringNoHeader(entry));
				}
			}
		}
	}
	
	/**
	 * in MEPS, all table/chart colwidth should be 
	 * 		1. in relative mode (34* rather than 34in or 34cm)
	 * 		2. as a integer 
	 *		3. MAX_COLWIDTH less than 612 (Todd); 
	 */
	public static void fixTableColWidth(Element table) throws Exception{ 
		NodeList ns = XMLUtil.xpathNodeSet(table, "//colspec");
		if(ns.getLength()>0){
			//logger.info("will fix table/colspec width; number="+ns.getLength());
		}
		
		//find max colwidth in this table/chart first
		float maxColwidth = 0f;
		for(int i=0; i<ns.getLength(); i++){
			Element colspec = (Element)ns.item(i);
			String colwidth = colspec.getAttribute("colwidth");
			//logger.info("colwidth="+colwidth);
			colwidth = trimColwidth(colwidth);
			if(colwidth.equals("") || colwidth.equalsIgnoreCase("1.oo")){
				colwidth = "1";
			}
			float colwidthIntValue = Float.parseFloat(colwidth);
			//logger.info("colwidthIntValue="+colwidthIntValue);
			maxColwidth = Math.max(maxColwidth, colwidthIntValue);
			//logger.info("maxColwidth="+maxColwidth);
		}
		float factor = MAX_COLWIDTH/maxColwidth;
		//logger.info("maxColwidth factor="+factor);
		for(int i=0; i<ns.getLength(); i++){
			Element colspec = (Element)ns.item(i);
			String colwidth = colspec.getAttribute("colwidth");
			//logger.info("colwidth="+colwidth);
			colwidth = trimColwidth(colwidth);
			if(colwidth.equals("") || colwidth.equalsIgnoreCase("1.oo")){
				colwidth = "1";
			}
			int colwidthIntValue = Math.round(Float.parseFloat(colwidth) * factor);
			//logger.info("new colwidthIntValue="+colwidthIntValue+" ; old colwidth="+colwidth);
			colwidthIntValue=Math.max(colwidthIntValue, 1);
			
			colspec.setAttribute("colwidth", colwidthIntValue+"*");
		}
	}
	
	private static String trimColwidth(String colwidth){
		return colwidth.toLowerCase().trim().replace("in.","").replace("in","").replace("*","").
				replace("cm.","").replace("cm","").replace("pt.","").replace("pt","").replace("%","").replace("m", "").replace("\"","");
	}
	
	public static void fixTableColWidth(Document doc) throws Exception{ 
		NodeList ns = XMLUtil.xpathNodeSet(doc, "//table", "//chart");
		for(int i=0; i<ns.getLength(); i++){
			fixTableColWidth((Element)ns.item(i));
		}
	}
	
	
	/**
	 * 	suppress <info-obj> which
	 * 	1. has only one <title> and one <info-obj> children, and
	 * 	2. either this <info-obj> has no title or child <info-obj> has no title, or both of them share the same title
	 * 	3. it is not referenced (determined by function object isReferenced) <br>
	 * 
	 * @param doc
	 * @param isReferenced - make it null to indicate info-objs are not referenced 
	 * @param keepSuppressedInfoObjIDAsAlterId - set to true if want to add the Id of the suppressed infoObj Id as @alterID attribute to the new infoOBj , but the client has to remove this attribute by itself later
	 * @throws Exception
	 */
	public static final String ALTER_ID_ATT = "alterID";
	public static void suppressInfoObjWithOnlyTitleAndOneChildInfoObjs(Document doc, IisIdReferenced<Element> isReferenced, boolean keepSuppressedInfoObjIDAsAlterId) throws Exception{
		//1. has only one <title> and one <info-obj> children
		NodeList ns = XMLUtil.xpathNodeSet(doc, "//info-obj[title and info-obj and count(child::*)=2]");
//			logger.info("suppress InfoObj With Only one Title And one Child InfoObjs");
		for(int i=0; i<ns.getLength(); i++){
			Element infoObj = (Element)ns.item(i);
			Element childInfoObj = (Element)XMLUtil.xpathNode(infoObj, "/info-obj");
			String infoObjTitle = XMLUtil.xpathStr(infoObj, "/title/text()");
			Node childInfoObjTitle = XMLUtil.xpathNode(childInfoObj, "/title");
			if(childInfoObjTitle == null){
				Node titleNode = doc.createElement("title");
				titleNode.setTextContent("NO TITLE");
				childInfoObj.insertBefore(titleNode, childInfoObj.getFirstChild());
				childInfoObjTitle = XMLUtil.xpathNode(childInfoObj, "/title");
			}
			Set<String> set = new HashSet<>();
			if(!infoObjTitle.equalsIgnoreCase("NO TITLE")){
				set.add(infoObjTitle);
			}
			if(!childInfoObjTitle.getTextContent().equalsIgnoreCase("NO TITLE")){
				set.add(childInfoObjTitle.getTextContent());
			}
			
			//2. has only one unique title
			if(set.size()==1){
				//3. not referenced
				if(isReferenced==null || !isReferenced.isReferenced(infoObj)){
					pl("suppressing InfoObj:" + infoObj.getAttribute("id"));
					if(keepSuppressedInfoObjIDAsAlterId){
						String alterId = infoObj.getAttribute("id");
						childInfoObj.setAttribute(ALTER_ID_ATT, alterId);
					}
					childInfoObjTitle.setTextContent(set.iterator().next());
					infoObj.getParentNode().insertBefore(childInfoObj, infoObj);
					XMLUtil.xpathCommentOut(infoObj);
				}
			}
		}
	}
	
	final public static String ID_SURFIX = "-";
	/**
	 * dedup all IDs by append duplicate id with a serial number
	 * e.g id123 => id123-2  
	 */
	public static void dedupIDs(Node node) throws Exception{
		int count = 0;
		Set<String> existingIDs = new HashSet<String>();
		if(node.getNodeType()==Node.ELEMENT_NODE && ((Element)node).hasAttribute("id")){
			existingIDs.add(((Element)node).getAttribute("id"));
		}
		//NodeList ns = XMLUtil.xpathNodeSet(node, "/.[@id]", "//*[@id]");
		NodeList ns = XMLUtil.xpathNodeSet(node, "//*[@id]");
		for(int i=0; i<ns.getLength(); i++){
			Element ele = (Element)ns.item(i);
			String id = ele.getAttribute("id").toLowerCase();
			if(existingIDs.contains(id)){
				ele.setAttribute("id", id + ID_SURFIX + count++);
			}else{
				existingIDs.add(id);
			}
		}
	}
	
	
	/**
	 * move elements which have preceding-sibling::info-obj into its precding-sibling <info-obj> elements 
	 */
	public static void fixNodesAfterInfoObj(Document doc) throws Exception{
		NodeList ns = XMLUtil.xpathNodeSet(doc, "//node()[name()!='info-obj' and preceding-sibling::info-obj]");
		if(ns.getLength()>0){
			//logger.info("move elements which have preceding-sibling info-obj into its precding-sibling <info-obj> elements; number="+ns.getLength());
		}
		while(ns.getLength()>0){
			for(int i=0; i<ns.getLength(); i++){
				Node precedingInfoObj = XMLUtil.xpathNode(ns.item(i), "/preceding-sibling::info-obj[1]");
				if(precedingInfoObj==null){
					logger.info("fixNodesAfterInfoObj:ns.item(i)="+XMLUtil.xmlToStringNoHeader(ns.item(i)));
					logger.info("fixNodesAfterInfoObj="+XMLUtil.xmlToStringNoHeader(ns.item(i).getParentNode()));
				}
				precedingInfoObj.appendChild(ns.item(i));
				//logger.info("node moved into it preceding <info-obj>; info-obj/@id="+((Element)precedingInfoObj).getAttribute("id")+" nodeName="+ns.item(i).getNodeName());
			}
			ns = XMLUtil.xpathNodeSet(doc, "//*[name()!='info-obj' and preceding-sibling::info-obj]");
		}
	}
	
	/**
	 * add a local <figure> for an extxref which pointing to a <figure> 
	 * (M1 DTD doesn't allow externally refer to a <figure>, thus, we create a local <figure>)
	 */
	public static void addALocalFigureForExtxref(Node xref, String id, String graphicname, String oename, String cap) throws Exception{
		Document doc = xref.getOwnerDocument();
		Element figure = doc.createElement("figure");
		Element graphic = doc.createElement("graphic");
		Element caption = doc.createElement("caption");
		figure.appendChild(graphic);
		figure.appendChild(caption);
		if(id!=null){
			graphic.setAttribute("id", id);	
		}
		graphic.setAttribute("graphicname", graphicname);
		graphic.setAttribute("oename", oename);
		caption.setTextContent(cap);
		
		Element para = (Element)XMLUtil.xpathNode(xref, "/ancestor::para");
		if(para!=null){
			para.getParentNode().insertBefore(figure, para.getNextSibling());
		}else{
			Element parentInfo = (Element)xpathNode(xref, "/ancestor::info-obj[1]");
			Node infoObjChild = XMLUtil.xpathNode(parentInfo, "/info-obj[1]");
			if(infoObjChild==null){
				parentInfo.appendChild(figure);	
			}else{
				parentInfo.insertBefore(figure, infoObjChild);
			}
		}
	}
	
	/**
	 *   default ratio = 0.8
	 */
	static public void compareFileSizes(String file1, String file2, float ratio) throws Exception {
		
		float size1 = new File(file1).length();
		float size2 = new File(file2).length();
		logger.info("size1="+size1+"; size2="+size2);
		
		if((size1/size2) < ratio){
			System.err.println("Caution, result file expended!; file1.length/file2.length="+size1/size2+" file1="+file1+" file2="+file2);
		}else if((size2/size1) < ratio){
			System.err.println("Warning, result file downsized!; file1.length/file2.length="+size1/size2+" file1="+file1+" file2="+file2);
		}{
			logger.info("file1.length/file2.length="+size1/size2+" file1="+file1+" file2="+file2);
		}
	}
	
	/**
	 * change all ids and intxref/@refid and extxref/@extrefid to non-MEPS ids to avoid import conflict.  
	 */
	static public void changeMEPSIDs(String srcDir, String destDir) throws Exception {
		logger.info("Start of changing MEPS ids");
		Document doc;

		List<String> files = FileUtil.getAllFilesWithCertainExt(srcDir, "xml");
		
		for (String file : files) {
			logger.info("changing ids for file "+file);
			doc = parseFile(srcDir + file);
			changeMEPSIDs(doc);
			FileUtil.writer(destDir+file, XMLUtil.xmlToString(doc));
		}
	}
	
	/**
	 * change all ids and intxref/@refid and extxref/@extrefid to non-MEPS ids to avoid import conflict.  
	 */
	static public void changeMEPSIDs(Document doc) throws Exception {
		NodeList nodes = xpathNodeSet(doc, "//*[@id]", "//intxref", "//extxref");
		for (int i = 0; i < nodes.getLength(); i++) {
			Element node = (Element) nodes.item(i);
			if(node.hasAttribute("id")){
				node.setAttribute("id", IDPad + node.getAttribute("id"));
			}
			if(node.hasAttribute("refid")){
				node.setAttribute("refid", IDPad + node.getAttribute("refid"));
			}
			if(node.hasAttribute("extrefid")){
				node.setAttribute("extrefid", IDPad + node.getAttribute("extrefid"));
			}
		}
	}
	
	public static String charMapping(String str) throws Exception{
		return charMapping(str, new HashMap<Integer, String>());
	}
	
	/**
	 * map UTF-8 chars to MEPS chars
	 * param substitutes is used to define custom char conversion, which overwrite standard conversion
	 * 
	 * 		String str = "Â°âˆ’abc.";
		for(int i=0; i<str.length(); i++){
			logger.info("111:"+str.codePointAt(i)+"");
			logger.info(Integer.toHexString(str.codePointAt(i)));
		}
		//logger.info(Integer.toHexString(str.codePointAt(0)));
		logger.info("String:\u2212"+new String(Character.toChars(str.codePointAt(0))));
	 */
	public static String charMapping(String str, Map<Integer, String> substitutes) throws Exception{
		if (str ==null) return null;
	    StringBuilder result = new StringBuilder();
	    
	    InputStream fis = new ByteArrayInputStream(str.getBytes("UTF-8"));
		BufferedReader in = new BufferedReader(new InputStreamReader(fis, Charset.forName("UTF-8")));
		int ch; String re ;
		while ((ch = in.read()) > -1) {
			re = ""+(char)ch;
			//logger.info("line="+Integer.toHexString(ch));
			if(substitutes.containsKey(ch)){
				//logger.info("substitutes char; ch:"+ch+" replaced with:"+substitutes.get(ch));
				re = substitutes.get(ch);
			}else{
				switch(ch){
			   	case(0x00a0): re = " "; break;
			   	case(0x00a3): re = "approx. "; break;
			   	case(0x00a4): re = "&circle;"; break;
		       	case(0x00a7): re = " "; break;
		       	case(0x00a8): re = "&circlef;&circlef;"; break;
		       	case(0x00a9): re = "&copy;"; break;
		       	case(0x00ad): re = "&mdash;"; break;
		       	case(0x00ae): re = "&reg;"; break;
		       	case(0x00B0): re = "&deg;"; break;
		       	case(0x00b1): re = "&plusmn;"; break;
		       	case(0x00b2): re = "<sup>2</sup>"; break;
		       	case(0x00b3): re = "<sup>3</sup>"; break;
		       	case(0x00b4): re = " ' "; break;
		       	case(0x00b5): re = "&micro;"; break;
		       	case(0x00B7): re = "."; break;
		       	case(0x00b9): re = "<sup>1</sup>"; break;
		       	case(0x00ba): re = "&deg;"; break;
		       	case(0x00bb): re = "&raquo;"; break;
		       	case(0x00bc): re = " 1/4 "; break;
		       	case(0x00bd): re = " 1/2 "; break;
		       	case(0x00be): re = " 3/4 "; break;
		       	case(0x00bf): re = " "; break;
		       	case(0x00c2): re = " A "; break;
		       	case(0x00c3): re = " A "; break;
		       	case(0x00c4): re = " A "; break;
		       	case(0x00c5): re = " A "; break;
		       	case(0x00c9): re = " E "; break;
		       	case(0x00cd): re = " i "; break;
		       	case(0x00d6): re = " O "; break;
		       	case(0x00d7): re = " X "; break;
		       	case(0x00d8): re = "&Oslash;"; break;
		       	case(0x00dc): re = " U "; break;
		       	case(0x00df): re = " B "; break;
		       	case(0x00e2): re = "&alpha;"; break;
		       	case(0x00e4): re = "&alpha;"; break;
		       	case(0x00e5): re = " "; break;
		       	case(0x00e6): re = " <ae> "; break;
		       	case(0x00e8): re = " e "; break;
		       	case(0x00e9): re = " e "; break;
		       	case(0x00ef): re = " "; break;
		       	case(0x00f1): re = " n "; break;
		       	case(0x00f2): re = "o"; break;
		       	case(0x00f6): re = "o"; break;
		       	case(0x00f7): re = "&divide;"; break;
		       	case(0x00f8): re = "&Oslash;"; break;
		       	case(0x00fc): re = "&micro;"; break;
		       	case(0x02c6): re = " ^ "; break;
		       	case(0x02da): re = "&ordm;"; break;
		       	case(0x037e): re = ";"; break;
		       	case(0x038f): re =  "&Omega;"; break;
		       	case(0x0394): re = "&Delta;"; break;
		       	case(0x039b): re = " ^ "; break;
		       	case(0x039c): re = "M"; break;
		       	case(0x03a9 ): re = "&Omega;"; break;
		       	case(0x03b1): re = "&alpha;"; break;
		       	case(0x03b2 ): re = "&beta;"; break;
		       	case(0x03b3): re = "&gamma;"; break;
		       	case(0x03bb): re = "&lambda;"; break;
		       	case(0x03bc ): re = "&micro;"; break;
		       	case(0x03c6 ): re = " "; break;
		       	case(0x03c9 ): re = "ohms"; break;
		       	case(0x153): re = " Oe "; break;
		       	case(0x161): re = " S "; break;
		       	case(0x17e): re = " Z "; break;
		       	case(0x192): re = " [VS192] "; break;
		       	case(0x2003): re = " "; break;
		       	case(0x2007): re = " "; break;
		       	case(0x2008): re = " "; break;
		       	case(0x2009): re = " "; break;
		       	case(0x200a): re = " "; break;
		       	case(0x200e): re = " "; break;
		       	case(0x2012): re = "&mdash;"; break;
		       	case(0x2013): re = "&mdash;"; break;
		       	case(0x2014): re = "&mdash;"; break;
		       	case(0x2018): re = "'"; break;
		       	case(0x2019): re = "'"; break;
		       	case(0x201a): re = " ' "; break;
		       	case(0x201c): re = "&ldquo;"; break;
		       	case(0x201d): re = "&rdquo;"; break;
		       	case(0x201e): re = "&rdquo;"; break;
		       	case(0x2020): re = "&plus;"; break;
		       	case(0x2021): re = "[DOUBLE DAGGER]"; break;
		       	case(0x2022): re = "&circlef;"; break;
		       	case(0x2026): re = "&circlef;&circlef;&circlef;"; break;
		       	case(0x2030): re = " /1000 "; break;
		       	case(0x2032): re = "'"; break;
		       	case(0x2033): re = "''"; break;
		       	case(0x203a): re = " greater than "; break;
		       	case(0x20ac): re = "[EURO SIGN]"; break;
		       	case(0x2011): re = "-"; break;
		       	case(0x2041): re = " "; break;
		       	case(0x2103): re = "&deg;C"; break;
		       	case(0x2109): re = "&deg;F"; break;
		       	case(0x2122): re = "&trade;"; break;
		       	case(0x2126): re = "&ohm;"; break;
		       	case(0x2154): re = "2/3"; break;
		       	case(0x215a): re = "5/6"; break;
		       	case(0x215b): re = "1/8"; break;
		       	case(0x215c): re = "3/8"; break;
		       	case(0x215d): re = "5/8"; break;
		       	case(0x215e): re = "7/8"; break;
		       	case(0x2190): re = "&larr;"; break;
		       	case(0x2191): re = "&uarr;"; break;
		       	case(0x2192): re = "&rarr;"; break;
		       	case(0x2193): re = "&darr;"; break;
		       	case(0x21d2): re = "&rarr;"; break;
		       	case(0x2205): re = "&oslash;"; break;
		       	case(0x2212): re = "-"; break;
		       	case(0x2219): re = "."; break;
		       	case(0x221e): re = "&infin;"; break;
		       	case(0x2220): re = "&ang;"; break;
		       	case(0x223c): re = "~"; break;
		       	case(0x2248): re = "&ap;"; break;
		       	case(0x2260): re = " != "; break;
		       	case(0x2261): re = " = "; break;
		       	case(0x2264): re = "&le;"; break;
		       	case(0x2265): re = "&ge;"; break;
		       	case(0x2266): re = "&le;="; break;
		       	case(0x22c4): re = " "; break;
		       	case(0x2329): re = "&lt;"; break;
		       	case(0x232a): re = " > "; break;
		       	case(0x2500): re = "&mdash;"; break;
		       	case(0x25a1): re = "&squ;"; break;
		       	case(0x25b2): re = "&larr;"; break;
		       	case(0x25b4): re = " "; break;
		       	case(0x25b6): re = "&rarr;"; break;
		       	case(0x25ba): re = "&rarr;"; break;
		       	case(0x25bc): re = "&darr;"; break;
		       	case(0x25be): re = " "; break;
		       	case(0x25c0): re = "&larr;"; break;
		       	case(0x25c4): re = "&larr;"; break;
		       	case(0x25cb): re = "&circle;"; break;
		       	case(0x25cf): re = "&circlef;"; break;
		       	case(0x2605): re = " * "; break;
		       	case(0x2666): re = " "; break;
		       	
		       	case(0x2dc): re = " ~ "; break;
		       	case(0x3000): re = " "; break;
		       	case(0xa2): re = " CENT SIGN "; break;
		       	case(0xa5): re = " [YEN SIGN] "; break;
		       	case(0xa6): re = " | "; break;
		       	case(0xcb): re = " E "; break;
		       	case(0xce): re = "&uarr;"; break;
		       	
		       	case(0xe3): re = "&alpha;"; break;
		       	case(0xe003): re = "-"; break;
		       	case(0xee41): re = " "; break;
		       	case(0xee43): re = " "; break;
		       	case(0xf020): re = " "; break;
		       	case(0xf02d): re = " "; break;
		       	case(0xfeff): re = " "; break;
		       	case(0xff06): re = "&amp;"; break;
		       	case(0xff08): re = " "; break;
		       	
		       	case(0xff09): re = ")"; break;
		       	case(0xff11): re = " 1 "; break;
		       	case(0xff22): re = " B "; break;
		       	
		       	case(0xff0d): re = " "; break;
		       	case(0xfffd): re = ""; break;
		       	
			       	default: 
			       		if(ch>0x7f){
			       			System.err.println("Unexpected char found (0x"+Integer.toHexString(ch)+")");
			       		}
			   }
			}
			
			result.append(re);
		}
		in.close();
		return result.toString();
	}
	
	/*public static String charMapping(String str) throws Exception{
		if (str ==null) return null;
	    final StringBuilder result = new StringBuilder(str.length());
	    
	    String re = "";
	    final int length = str.length();
		for (int offset = 0; offset < length; ) {
		   final int codepoint = str.codePointAt(offset);
		   logger.info("charCount="+Character.charCount(codepoint)+" hex:0x"+Integer.toHexString(codepoint) 
				   + " isSupplementaryCodePoint="+Character.isSupplementaryCodePoint((char)codepoint)
				   );
		   switch(codepoint){
		   	case(0x00a0): re = " "; break;
		   	case(0x00a3): re = "approx. "; break;
		   	case(0x00a4): re = "&circle;"; break;
	       	case(0x00a7): re = " "; break;
	       	case(0x00a8): re = "&circlef;&circlef;"; break;
	       	case(0x00A9): re = "&copy;"; break;
	       	case(0x00ad): re = "&mdash;"; break;
	       	case(0x00ae): re = "&reg;"; break;
	       	case(0x00B0): re = "&deg;"; break;
	       	case(0x00b1): re = "&plusmn;"; break;
	       	case(0x00b2): re = "<sup>2</sup>"; break;
	       	case(0x00b3): re = "<sup>3</sup>"; break;
	       	case(0x00b4): re = " ' "; break;
	       	case(0x00b5): re = "&micro;"; break;
	       	case(0x00B7): re = "."; break;
	       	case(0x00b9): re = "<sup>1</sup>"; break;
	       	case(0x00ba): re = "&deg;"; break;
	       	case(0x00bb): re = "&raquo;"; break;
	       	case(0x00bc): re = " 1/4 "; break;
	       	case(0x00bd): re = " 1/2 "; break;
	       	case(0x00be): re = " 3/4 "; break;
	       	case(0x00bf): re = " "; break;
	       	case(0x00c2): re = " A "; break;
	       	case(0x00c3): re = " A "; break;
	       	case(0x00c4): re = " A "; break;
	       	case(0x00c5): re = " A "; break;
	       	case(0x00c9): re = " E "; break;
	       	case(0x00cd): re = " i "; break;
	       	case(0x00d6): re = " O "; break;
	       	case(0x00d7): re = " X "; break;
	       	case(0x00d8): re = "&Oslash;"; break;
	       	case(0x00dc): re = " U "; break;
	       	case(0x00df): re = " B "; break;
	       	case(0x00e2): re = "&alpha;"; break;
	       	case(0x00e4): re = "&alpha;"; break;
	       	case(0x00e5): re = " "; break;
	       	case(0x00e6): re = " <ae> "; break;
	       	case(0x00e9): re = " e "; break;
	       	case(0x00ef): re = " "; break;
	       	case(0x00f1): re = " n "; break;
	       	case(0x00f2): re = "o"; break;
	       	case(0x00f6): re = "o"; break;
	       	case(0x00f7): re = "&divide;"; break;
	       	case(0x00f8): re = "&Oslash;"; break;
	       	case(0x00fc): re = "&micro;"; break;
	       	case(0x02c6): re = " ^ "; break;
	       	case(0x02da): re = "&ordm;"; break;
	       	case(0x037e): re = ";"; break;
	       	case(0x0394): re = "&delta;"; break;
	       	case(0x039b): re = " ^ "; break;
	       	case(0x039c): re = "M"; break;
	       	case(0x03a9 ): re = "&Omega;"; break;
	       	case(0x03b1): re = "&alpha;"; break;
	       	case(0x03b2 ): re = "&beta;"; break;
	       	case(0x03b3): re = "&gamma;"; break;
	       	case(0x03bb): re = "&lambda;"; break;
	       	case(0x03bc ): re = "&micro;"; break;
	       	case(0x03c6 ): re = " "; break;
	       	case(0x03c9 ): re = "ohms"; break;
	       	case(0x153): re = " Oe "; break;
	       	case(0x161): re = " S "; break;
	       	case(0x17e): re = " Z "; break;
	       	case(0x192): re = " [VS192] "; break;
	       	case(0x2003): re = " "; break;
	       	case(0x2007): re = " "; break;
	       	case(0x2008): re = " "; break;
	       	case(0x2009): re = " "; break;
	       	case(0x2012): re = "&mdash;"; break;
	       	case(0x2013): re = "&mdash;"; break;
	       	case(0x2014): re = "&mdash;"; break;
	       	case(0x2018): re = "'"; break;
	       	case(0x2019): re = "'"; break;
	       	case(0x201a): re = " ' "; break;
	       	case(0x201c): re = "&ldquo;"; break;
	       	case(0x201d): re = "&rdquo;"; break;
	       	case(0x201e): re = "&rdquo;"; break;
	       	case(0x2020): re = "&plus;"; break;
	       	case(0x2021): re = "[DOUBLE DAGGER]"; break;
	       	case(0x2022): re = "&circlef;"; break;
	       	case(0x2026): re = "&circlef;&circlef;&circlef;"; break;
	       	case(0x2030): re = " /1000 "; break;
	       	case(0x2032): re = "'"; break;
	       	case(0x2033): re = "''"; break;
	       	case(0x203a): re = " greater than "; break;
	       	case(0x20ac): re = "[EURO SIGN]"; break;
	       	case(0x2103): re = "&deg;C"; break;
	       	case(0x2109): re = "&deg;F"; break;
	       	case(0x2122): re = "&trade;"; break;
	       	case(0x2126): re = "&ohm;"; break;
	       	case(0x2154): re = "2/3"; break;
	       	case(0x215b): re = "1/8"; break;
	       	case(0x2190): re = "&larr;"; break;
	       	case(0x2191): re = "&uarr;"; break;
	       	case(0x2192): re = "&rarr;"; break;
	       	case(0x2193): re = "&darr;"; break;
	       	case(0x21d2): re = "&rarr;"; break;
	       	case(0x2205): re = "&oslash;"; break;
	       	case(0x2212): re = "-"; break;
	       	case(0x2219): re = "."; break;
	       	case(0x221e): re = "&infin;"; break;
	       	case(0x2220): re = "&ang;"; break;
	       	case(0x223c): re = "~"; break;
	       	case(0x2248): re = "&ap;"; break;
	       	case(0x2260): re = " != "; break;
	       	case(0x2261): re = " = "; break;
	       	case(0x2264): re = "&le;"; break;
	       	case(0x2265): re = "&ge;"; break;
	       	case(0x22c4): re = " "; break;
	       	case(0x2329): re = "&lt;"; break;
	       	case(0x232a): re = " > "; break;
	       	case(0x2500): re = "&mdash;"; break;
	       	case(0x25a1): re = "&squ;"; break;
	       	case(0x25b2): re = "&larr;"; break;
	       	case(0x25b6): re = "&rarr;"; break;
	       	case(0x25ba): re = "&rarr;"; break;
	       	case(0x25bc): re = "&darr;"; break;
	       	case(0x25be): re = " "; break;
	       	case(0x25c0): re = "&larr;"; break;
	       	case(0x25c4): re = "&larr;"; break;
	       	case(0x25cb): re = "&circle;"; break;
	       	case(0x25cf): re = "&circlef;"; break;
	       	case(0x2666): re = " "; break;
	       	
	       	case(0x2dc): re = " ~ "; break;
	       	case(0x3000): re = " "; break;
	       	case(0xa2): re = " CENT SIGN "; break;
	       	case(0xa5): re = " [YEN SIGN] "; break;
	       	case(0xa6): re = " | "; break;
	       	case(0xcb): re = " E "; break;
	       	case(0xce): re = "&uarr;"; break;
	       	
	       	case(0xe3): re = "&alpha;"; break;
	       	case(0xe003): re = "-"; break;
	       	case(0xf020): re = " "; break;
	       	case(0xf02d): re = " "; break;
	       	case(0xfeff): re = " "; break;
	       	case(0xff06): re = "&amp;"; break;
	       	case(0xff08): re = " "; break;
	       	case(0xff0d): re = " "; break;
	       	
		       	
		       	default: 
		       		if(codepoint<0x7f){ re=str.charAt(offset)+""; break;
		       		}else{
		       			//throw new Exception("Unexpected char found;(\\u"+Integer.toHexString(in)+")");
		       			
		       			String hexStr = "";
		       			for(int i = 0; i<Character.charCount(codepoint); i++){
		       				logger.info("charCount:"+Character.charCount(codepoint));
		       				hexStr += Integer.toHexString(str.charAt(offset+i))+" ";
		       			}
		       			//System.err.println(Integer.toHexString(str.charAt(offset))+" "+Integer.toHexString(str.charAt(offset+1))+" "+Integer.toHexString(str.charAt(offset+2)));
		       			System.err.println("Unexpected char found (0x"+Integer.toHexString(codepoint)+")" + hexStr);
		       		}
		   }
		   result.append(re);
		   offset += Character.charCount(codepoint);
		}
		return result.toString();
	}*/
	
	/*public static String charMapping(String str) throws Exception{
		if (str ==null) return null;
	    final StringBuilder result = new StringBuilder(str.length());
	    String re = "";
	    for ( int i=0; i < str.length(); i++ ) {
	        int in = (int)str.charAt(i);
	        //logger.info(in+"");
	        switch(in){
	        	case(0x00A4): re = "&circle;"; break;
	        	case(0x00A9): re = "&copy;"; break;
	        	case(0x00B0): re = "&deg;"; break;
	        	case(0x00B7): re = "."; break;
	        	case(0x00e6): re = " <ae> "; break;
	        	case(0x03a9 ): re = "&Omega;"; break;
	        	case(0x03b2 ): re = "&beta;"; break;
	        	case(0x03bc ): re = "&micro;"; break;
	        	case(0x03c6 ): re = " "; break;
	        	case(0x2019): re = ", "; break;
	        	case(0x201c): re = "&ldquo;"; break;
	        	case(0x201d): re = "&rdquo;"; break;
	        	case(0x2154): re = " 2/3 "; break;
	        	case(0x2190): re = "&larr;"; break;
	        	case(0x2191): re = "&uarr;"; break;
	        	case(0x2192): re = "&rarr;"; break;
	        	case(0x2193): re = "&darr;"; break;
	        	case(0x221e): re = "&infin;"; break;
	        	case(0x25a1): re = "&squ;"; break;
	        	case(0x25b2): re = "&larr;"; break;
	        	case(0x25bc): re = "&darr;"; break;
	        	case(0x25cb): re = "&circle;"; break;
	        	case(0x25cf): re = "&circlef;"; break;
	        	case(0x3000): re = "&squ;"; break;
	        	case(0xfeff): re = " "; break;
	        	case(0xff06): re = "&amp;"; break;
	        	case(0xff08): re = " "; break;
	        	case(0xff0d): re = " "; break;

	        	//Volvo chars, map them to proper chars
	        	case(0x00a0): re = " "; break;
	        	case(0x00a7): re = " "; break;
	        	case(0x00a8): re = "&circlef;&circlef;"; break;
	        	case(0x00ad): re = "&mdash;"; break;
	        	case(0x00ae): re = "&reg;"; break;
	        	case(0x00b1): re = "&plusmn;"; break;
	        	case(0x00b2): re = " 2 "; break;
	        	case(0x00b3): re = " 3 "; break;
	        	case(0x00b4): re = " ' "; break;
	        	case(0x00b5): re = "&micro;"; break;
	        	case(0x00b9): re = " 1 "; break;
	        	case(0x00ba): re = "&circle;"; break;
	        	case(0x00bb): re = "&raquo;"; break;
	        	case(0x00bc): re = " 1/4 "; break;
	        	case(0x00bd): re = " 1/2 "; break;
	        	case(0x00be): re = " 3/4 "; break;
	        	case(0x00c2): re = ""; break;
	        	case(0x00c3): re = ""; break;
	        	case(0x00c4): re = " A "; break;
	        	case(0x00c5): re = " A "; break;
	        	case(0x00c9): re = " E "; break;
	        	case(0x00cd): re = " i "; break;
	        	case(0x00d6): re = " O "; break;
	        	case(0x00d7): re = " X "; break;
	        	case(0x00d8): re = "&Oslash;"; break;
	        	case(0x00dc): re = " U "; break;
	        	case(0x00e4): re = "&alpha;"; break;
	        	case(0x00e5): re = " "; break;
	        	case(0x00e9): re = " e "; break;
	        	case(0x00f1): re = " n "; break;
	        	case(0x00f2): re = " o "; break;
	        	case(0x00f6): re = " O "; break;
	        	case(0x00f7): re = "&divide;"; break;
	        	case(0x00f8): re = "&Oslash;"; break;
	        	case(0x00fc): re = "&micro;"; break;
	        	case(0x02da): re = "&ordm;"; break;
	        	case(0x0394): re = "&Delta;"; break;
	        	case(0x039b): re = " ^ "; break;
	        	case(0x03b1): re = "&alpha;"; break;
	        	case(0x03b3): re = " Y "; break;
	        	case(0x03bb): re = "&lambda;"; break;
	        	case(0x2013): re = "&mdash;"; break;
	        	case(0x2014): re = "&mdash;&mdash;"; break;
	        	case(0x2022): re = "&circlef;"; break;
	        	case(0x2026): re = "&circlef;&circlef;&circlef;"; break;
	        	case(0x2122): re = "&trade;"; break;
	        	case(0x2126): re = "&ohm;"; break;
	        	case(0x21d2): re = " "; break;
	        	case(0x2205): re = "&oslash;"; break;
	        	case(0x2212): re = " "; break;
	        	case(0x223c): re = " "; break;
	        	case(0x2248): re = "&ap;"; break;
	        	case(0x2261): re = " = "; break;
	        	case(0x2264): re = "&le;"; break;
	        	case(0x2265): re = "&ge;"; break;
	        	case(0x22c4): re = " "; break;
	        	case(0x2500): re = "&mdash;"; break;
	        	case(0x25ba): re = "&rarr;"; break;
	        	case(0xf02d): re = " "; break;
	        	
	        	case(0x2032): re = " ' "; break;
	        	case(0x2103): re = "&deg;C"; break;
	        	case(0x2109): re = "&deg;F"; break;
	        	case(0x2220): re = " "; break;
	        	case(0x00bf): re = " "; break;
	        	case(0x00df): re = "&beta;"; break;
	        	case(0x00ef): re = " "; break;
	        	case(0x2003): re = " "; break;
	        	case(0x2007): re = " "; break;
	        	case(0x2009): re = " "; break;
	        	case(0x2018): re = " ' "; break;
	        	case(0x201e): re = "&rdquo;"; break;
	        	case(0x2260): re = " != "; break;
	        	case(0x2329): re = "&lt;"; break;
	        	case(0x232a): re = " > "; break;
	        	case(0x25be): re = " "; break;
	        	case(0x25c4): re = "&larr;"; break;
	        	case(0x2666): re = " "; break;
	        	
	        	case(0x153): re = " Oe "; break;
	        	case(0x203a): re = " greater than "; break;
	        	case(0x20ac): re = " - "; break;
	        	case(0x2c6): re = " ^ "; break;
	        	case(0x2dc): re = " ~ "; break;
	        	case(0xa2): re = " CENT SIGN "; break;
	        	case(0xa6): re = " | "; break;
	        	case(0xce): re = "&uarr;"; break;
	        	case(0xe2): re = "&alpha;"; break;
	        	
	        	case(0x161): re = " S "; break;
	        	case(0x17e): re = " Z "; break;
	        	case(0x192): re = " [VS192] "; break;
	        	case(0x201a): re = " ' "; break;
	        	case(0x2020): re = "&plus;"; break;
	        	case(0x2030): re = " /1000 "; break;
	        	case(0xa5): re = " [YEN SIGN] "; break;
	        	case(0xcb): re = " E "; break;
	        	case(0xe3): re = "&alpha;"; break;
	        	
	        	default: if(in<0x7f)
	        		{ re=str.charAt(i)+""; break;}
	        		else{
	        			//throw new Exception("Unexpected char found;(\\u"+Integer.toHexString(in)+")");
	        			System.err.println("Unexpected char found;(\\u"+Integer.toHexString(in)+")");
	        		}
	        }
	        result.append(re);
	    }
	    //logger.info("result="+result);
		return result.toString();
	}*/
	
	/**
	 * given an MEPS <info-obj>'s id, return original article file name and id. 
	 * e.g input: S00098429312011061000000
	 * return [VOLVO295-REP-REMOVAL,_REPLACEMENT_AND_INSTALLATION-85,SHORTID-40011]
	 */
	public String[] infoObjID2OrgFileNameAndID(String id) throws Exception{
		Statement st = con.createStatement();
		String query = "SELECT B.ORG_FILE_NAME, ORG_ID " +
				"FROM MEPS.ARTICLE_INFO_OBJECT a join MEPS.article b " +
				"on a.article_id = b.article_id " +
				"where INFO_OBJECT_GUID='" + id + "'";
		ResultSet rs = st.executeQuery(query);
		
		rs.next();
		String[] values = new String[2];
		values[0] = rs.getString(1);//original article file name
		values[1] = rs.getString(2);//original info-obj id
		
		if(rs.next()){
			throw new Exception("More than one record found for id="+id);
		}
		
		rs.close();
		
		return values;
	}
	
	/**
	 * get original article element id to MEPS article GUID and info-obj id mapping
	 * <RM000002GMT003X,  {A00382578,S40254115562011012800000}>
	 * orgFileNameLike = LX09GS350-GS460%
	 */
	public Map<String, String[]> getOrg2MEPSID(Collection<String> orgIDs, String orgFileNameLike) throws Exception{
		logger.info("Getting original article element id to MEPS info-obj id mapping, number of Ids="+orgIDs.size());
		Map<String, String[]> map = new HashMap<String, String[]>();
		Statement st = con.createStatement();
		Iterator<String> it = orgIDs.iterator();
		String query = "select A.ORG_ID, B.ARTICLE_GUID, A.INFO_OBJECT_GUID " +
		"from MEPS.ARTICLE_INFO_OBJECT A join MEPS.ARTICLE B on A.ARTICLE_ID = B.ARTICLE_ID " +
		"where B.ORG_FILE_NAME like '" + orgFileNameLike + "' AND A.ORG_ID in\n(";
		int count = 0;
		while(it.hasNext()){
			String orgid = it.next();
			if(count++ == 0){
				query += "'" + orgid + "'";
			}else{
				query += "\n,'" + orgid + "'";
			}
		}
		query += ")";
		logger.info("getOrg2MEPSID.query="+query);
		ResultSet rs = st.executeQuery(query);
		while (rs.next()) {
			String orgid = rs.getString(1);
			String[] values = new String[2];
			values[0] = rs.getString(2);
			values[1] = rs.getString(3);
			map.put(orgid, values);
				//logger.info("rs.getString()="+rs.getString(1)+" "+ rs.getString(2) + "," + rs.getString(3));
		}
		rs.close();
		return map;
	}
	
	/**
	 * get the Document object of a given article from MEPS
	 */
	public Document getArticleFromMEPS(String articleGUID) throws Exception{
		//logger.info(" Getting Document obj of " + articleGUID);
		String content = getArticleContentFromMEPS( articleGUID);
		content = XMLUtil.Article2XML(content);
		//logger.info("getArticleFromMEPS.content="+content);
		return XMLUtil.parseStr(content);
	}
	
	/**
	 * get the article content of a given article from MEPS
	 */
	public String getArticleContentFromMEPS(String articleGUID) throws Exception{
		//logger.info(" Getting content of " + articleGUID);
		String threeLayerPath = Util.getThreeLayerDir(articleGUID.trim());
		String articleFile = ARTICLE_WIP_DIR + threeLayerPath + articleGUID.trim() + ".sgm";
		String content = FileUtil.reader(articleFile); 
		return content;
	}
	
	/**
	 * get the Document object of a given article from MEPS
	 */
	public String getArticleDir(String articleGUID) {
		String threeLayerPath = Util.getThreeLayerDir(articleGUID);
		return ARTICLE_WIP_DIR + threeLayerPath ;
	}
	
	
	/**
	 * turn all first level <info-obj>'s titles to all upper cases 
	 */
	public static void capTitles(Document doc) throws Exception{
		logger.info("turn all <info-obj>'s titles to all upper cases");
		NodeList titles = XMLUtil.xpathNodeSet(doc, "//info-obj/title", "//table/title", "//doc-head");
		for(int i=0; i<titles.getLength(); i++){
			Element title = (Element)titles.item(i);
			title.setTextContent(title.getTextContent().toUpperCase());
		}
	}
	
	/**
	 * fix 6th level <info-obj> by turning them from their parent <info-obj>'s children into following sibling elements
	 */
	public static void fix6thLevelInfoObj(Document doc) throws Exception{
		//logger.info("Fixing 6th level <info-obj>");
		NodeList lst = XMLUtil.xpathNodeSet(doc, "//info-obj/info-obj/info-obj/info-obj/info-obj/info-obj");
		if(lst.getLength()>0)logger.info("6th level <info-obj> found and fixed:"+(lst.getLength()+1));
		for(int i=0; i<lst.getLength(); i++){
			Element infoObj = (Element)lst.item(i);
			Element parent = (Element)infoObj.getParentNode();
			Node grandParent = parent.getParentNode();
			grandParent.insertBefore(infoObj, parent);
			
			//check if its parent <info-obj> is empty now, if it is, remove it
			if(XMLUtil.xpathNodeSet(parent, "/*[name()!='title']").getLength()==0){
				//check if it is referenced
				if(parent.getAttribute("id").startsWith("dummy")){
					XMLUtil.xpathCommentOut(parent);	
				}
			}
		}
	}
	
	/**
	 * insert NO TITLE to blank table title 
	 */
	public static void insertTableTitle(Document doc) throws Exception{
		logger.info(" Insert NO TITLE to blank table title");
		NodeList titles = XMLUtil.xpathNodeSet(doc, "//table[count(title/node())=0]/title");
		for(int i=0; i<titles.getLength(); i++){
			Element title = (Element)titles.item(i);
			logger.info("MEPSUtil: table title removed----"+title.getTextContent()+"----");
			title.setTextContent("NO TITLE");
		}
	}
	
	/**
	 * 	do some final checks to make sure the article XML is good, it won't stop on issues discovered, check logs to see what issues exist.
	 * 	make sure each <entry> has at least one element <br>
	 * 	no 6-th level info-obj <br>
	 * 	no info-obj title as  "NO TITLE" <br>
	 * docsubHead is not empty
	 * 	table colwidth no more than 612 <br>
	 */
	public static boolean finalCheck(Document doc, String fileName) throws Exception{
		logger.info("Do final check for file " + fileName);
		if(XMLUtil.xpathNodeSet(doc, "//entry[count(*)=0]").getLength() >0){
			logger.error("empty <entry> found! file="+fileName);
			//throw new RuntimeException("empty <entry> found!"); //TODO resume me
		}
		if(XMLUtil.xpathNodeSet(doc, "//info-obj/info-obj/info-obj/info-obj/info-obj/info-obj").getLength() >0){
			logger.error("the 6th layer of <info-obj> found! file="+fileName);			
			//throw new RuntimeException("the 6th layer of <info-obj> found!"); //TODO resume me
		}
		
		if(XMLUtil.xpathNodeSet(doc, "//info-obj[title/text()='NO TITLE']").getLength() >0){
			logger.error("NO TITLE info-obj found! file="+fileName);			
		}
		
		if(XMLUtil.xpathStr(doc, "//doc-subhead/text()").trim().length() == 0){
			logger.error("Doc Subhead is missing! file="+fileName);			
		}
		
		//check colwidth less than 612 (Todd: After talking with John we settled on a max of 612 on a column width)
		NodeList colwidthEles = XMLUtil.xpathNodeSet(doc, "//*[@colwidth]");
		for(int i=0; i<colwidthEles.getLength(); i++){
			String colwidthAtt = ((Element)colwidthEles.item(i)).getAttribute("colwidth");
			int colwidth = Integer.parseInt(colwidthAtt.replace("*", ""));
			if(colwidth>612){
				//throw new RuntimeException("colwidth excesses 612 max:"+colwidth);//TODO resume me
				logger.error("colwidth excesses 612 max:"+colwidthAtt);
			}
		}

		
		return true;
	}
	

	/**
	 * verify all embeded graphics (graphics in table or chart) exist in give generated_ids set. <br>
	 * Return a list of missing graphics and their are enclosing file name <br>
	 * 		e.g GM123456 - 2018Traverse_(10458765)00-Preface-01 <br>
	 * if missing graphics founds <br>
	 * 	  1. replaceNonExistingGraphicsWithEmptyGraphic = true, replace them with emtpy graphic <br>
	 * 		2. replaceNonExistingGraphicsWithEmptyGraphic = false, throw exception
	 */
	public static List<String> checkIfAllOnlineGraphicsExistInMEPS(Document doc, String file, Set<String> generated_ids, boolean replaceNonExistingGraphicsWithEmptyGraphic) throws Exception{
		logger.info("checkIfAllOnlineGraphicsExistInMEPS for file " + file);
		List<String> missingGraphics = new ArrayList<>();
		NodeList tgtGraphics = XMLUtil.xpathNodeSet(doc, "//graphic[ancestor::table or ancestor::chart]");
		for(int i=0; i<tgtGraphics.getLength(); i++){
			Element gx = (Element)tgtGraphics.item(i);
			String graphicname = gx.getAttribute("graphicname");
			//pl("checking graphicname:" + graphicname);
			if(!generated_ids.contains(graphicname)){
				el("embedded graphic is missing:"+graphicname);
				String fileName = FileUtil.getFileName(file);
				missingGraphics.add(graphicname + " @@ " + fileName);
				if(replaceNonExistingGraphicsWithEmptyGraphic){
					el("Replacing it with empty graphic");
					gx.setAttribute("graphicname", UNAVAILABL_GRAPHIC_GID);
				}else{
					throw new Exception("Missing embeded graphic found:" + graphicname);
				}
			}
		}
		return missingGraphics;
	}
	
	protected void finalize() throws Throwable
	{
		con.close();
	} 
	
	/**
	 * to generate a dummy graphic article in order to import <oename, generated_id, caption> mappings into MEPS
	 * return result sgml content  
	 * @throws Exception 
	 */
	public static void genDummyGXArticle(Collection<String[]> col, String destSGML) throws Exception{
		String sgml = "<!DOCTYPE SOM1 PUBLIC \"-//MRIC//DTD SNAPON MITCHELL1//EN\"><!--ArborText, Inc., 1988-1998, v.4002-->" +
				"<som1><doc-head>dummy article</doc-head><doc-subhead>Please don't proof, this is a graphic dummy article</doc-subhead>" +
				"<info-obj id=\"dummy123\"><title>dummy info</title>";
		String oename, id, caption;
		for(String[] s:col){
			oename = s[0];
			id = s[1];
			caption = s[2];
			sgml += "<figure><graphic graphicname=\"" + id + "\" oename=\"" + oename + "\"><caption>"+caption+"</caption></figure>";
		}
		sgml += "</info-obj></som1>";
		logger.info(sgml);
		FileUtil.writer(destSGML, sgml);
	}
	
	/**
	 * return connection to MEPS
	 * "MEPSP" for MEPS production env 
	 * "MEPST" for MEPS test env
	 */
	Connection getMEPSConnect(String MEPSDB) throws Exception{
		Connection con;
		if(MEPSDB.equalsIgnoreCase("MEPSP")){
			logger.info("Connecting to MEPS Production database");
			con = SQLUtil.connectORA(AppProperties.prop.getProperty("mepsp.db.url"), Integer.parseInt(AppProperties.prop.getProperty("mepsp.db.port")), AppProperties.prop.getProperty("mepsp.db.sid"), 
					AppProperties.prop.getProperty("mepsp.db.user"), AppProperties.prop.getProperty("mepsp.db.pass"));
		}
		else if(MEPSDB.equalsIgnoreCase("MEPST")){
			logger.info("Connecting to MEPS Test database");
			con = SQLUtil.connectORA(AppProperties.prop.getProperty("mepst.db.url"), Integer.parseInt(AppProperties.prop.getProperty("mepst.db.port")), AppProperties.prop.getProperty("mepst.db.sid"), 
					AppProperties.prop.getProperty("mepst.db.user"), AppProperties.prop.getProperty("mepst.db.pass"));
		}
		else if(MEPSDB.equalsIgnoreCase("MEPSD")){
			logger.info("Connecting to MEPS Dev database");
			con = SQLUtil.connectORA(AppProperties.prop.getProperty("mepsd.db.url"), Integer.parseInt(AppProperties.prop.getProperty("mepsd.db.port")), AppProperties.prop.getProperty("mepsd.db.sid"), 
					AppProperties.prop.getProperty("mepsd.db.user"), AppProperties.prop.getProperty("mepsd.db.pass"));
		}
		else{
			throw new Exception("unrecognized MEPS database name - " + MEPSDB);
		}
		logger.info("Connected to " + database +" database");
		return con;
	}
	
	/**
	 * to copy mutiple articles to DestDir folder
	 */
	public void copyArticlesFromMEPS(Collection<String> articleGUIDs, String DestDir) throws Exception{
		Object[] articles = articleGUIDs.toArray();
		for(int i=0; i<articles.length; i++){
			copyArticleFromMEPS((String)articles[i], DestDir);
		}
		logger.info(articles.length + " articles copied to " + DestDir);
	}
	
	/**
	 * to copy mutiple articles to DestDir folder
	 */
	public void copyArticlesFromMEPS(String[] articleGUIDs, String DestDir) throws Exception{
		for(int i=0; i<articleGUIDs.length; i++){
			String guid = articleGUIDs[i].trim();
			if(guid.length()>0){
				logger.info("copying article-"+guid+"-");
				copyArticleFromMEPS(guid, DestDir);
			}
		}
		logger.info(articleGUIDs.length + " articles copied to "+ DestDir);
	}
	
	/**
	 * to copy a given article to DestDir folder
	 */
	public void copyArticleFromMEPS(String articleGUID, String DestDir) throws Exception{
		copyArticleFromMEPS(articleGUID, DestDir, articleGUID);
	}
	
	/**
	 * to copy a given article to DestDir folder with a different file name
	 */
	public void copyArticleFromMEPS(String articleGUID, String DestDir, String newFileName) throws Exception{
		
		String threeLayerPath = Util.getThreeLayerDir(articleGUID);
		String articleFile = ARTICLE_WIP_DIR + threeLayerPath + articleGUID + ".sgm";
		String newFileFullName = DestDir + newFileName + (newFileName.toLowerCase().endsWith(".sgm")?"":".sgm");
		FileUtil.copyFile(articleFile, newFileFullName);
		logger.info("Article "+articleGUID+" copied to " +newFileFullName);
	}

	
	/**
	 * give a graphic generated_id, copy it to DestDir folder
	 */
	public void copyGX(String gxFile, String DestDir) throws Exception{
		String filePath = getGXPath(gxFile);
		if(filePath == null){
			throw new Exception(gxFile + " not found in " + GRPHC_PROD_ROOT_DIR);
		}
		FileUtil.copyFile(filePath, DestDir + gxFile );
		logger.info("Graphic "+gxFile+" copied to "+DestDir);
	}
	
	/**
	 * given an generated_id, get a graphic file full path from MEPS, return null if not exists  
	 * generated_id:  GM62293 or GM62293.tif
	 */
	public String getGXPath(String generated_id){
		//GM62293 or GM62293.tif
		String threeLayerPath = Util.getThreeLayerDir(generated_id);
		
		String filePath = GRPHC_PROD_ROOT_DIR + threeLayerPath + generated_id.substring(1); //remove leading G from generated_id
		String command;
		if(generated_id.contains(".")){//has extension
			command = "dir /b " + filePath;
		}else{
			command = "dir /b " + filePath + ".*";
		}
		//logger.info("command="+command);
		List<String> files = new ArrayList<>();
		try{
			files = CMDUtil.callCMD(command);	
		}
		catch(Exception e){
			return null;
		}
		
		if(files.size() == 0){
			return null;
		}else if(files.size()>1){
			//System.err.println("More than one graphic found for generated_id; list="+files);
			if(generated_id.startsWith("GM")){
				return GRPHC_PROD_ROOT_DIR + threeLayerPath + generated_id + ".gif";
			}else{
				throw new RuntimeException("More than one graphic found for generated_id "+generated_id);	
			}
			
		}else{
			return GRPHC_PROD_ROOT_DIR + threeLayerPath + files.get(0);
		}
	}
	
	/**
	 * Convert all figures in given document to Chart (So, editors don't need to populate caption)
	 * strategy: when <figure is inside a <lst-itm>, 
	 * 		if <figure> is after the first <ptxt>, simply replace it with <chart>
	 * 		if <figure> is in front of first <ptxt>, since  chart has to be after first <ptxt>, 
	 *		 thus, after replace <figure> with new <chart>, put an empty <ptxt> in front of <chart>, and then turn the old first <ptxt> into <para><ptxt>
	 * @param doc
	 */
	static Element graphicChartTemplate = null;
	public static void convertAllFigureToChart(Document doc) throws Exception{
		if(graphicChartTemplate == null){
			graphicChartTemplate = XMLUtil.parseFile(Util.UTIL_RESOURCE_DIR + "GraphicChartTemplate.xml").getDocumentElement();
		}
		NodeList figures = XMLUtil.xpathNodeSet(doc, "//figure");
		for(int i=0; i<figures.getLength(); i++){
			Element figure = (Element)figures.item(i);
			Node graphic = XMLUtil.xpathNode(figure, "/graphic");
			Node parentNode = figure.getParentNode();
			
			Element chart = (Element) doc.importNode(graphicChartTemplate.cloneNode(true), true);
			
			if(parentNode.getNodeName().equalsIgnoreCase("lst-itm") ){
				
				parentNode.insertBefore(chart, figure);
				
				Node ptxtBeforeFigure = XMLUtil.xpathNode(figure, "/preceding-sibling::ptxt");
				if(ptxtBeforeFigure == null){
					//turn existing <ptxt> into <para><ptxt>
					Node ptxt = XMLUtil.xpathNode(parentNode, "/ptxt"); //should be only one
					Node para = doc.createElement("para");
					parentNode.insertBefore(para, ptxt);
					para.appendChild(ptxt);
					
					//add <chart>
					
					Node emptyPtxt = doc.createElement("ptxt");
					parentNode.insertBefore(emptyPtxt, chart);
				}

			}else{
				parentNode.insertBefore(chart, figure);
			}
			
			Node entry = XMLUtil.xpathNode(chart, "//entry");
			entry.appendChild(graphic);

			pl("converted figure to chart: " + XMLUtil.xmlToString(figure));
			XMLUtil.xpathCommentOut(figure);
			//figure.getParentNode().removeChild(figure);
		}
	}
	
//	public static void convertAllFigureToChart(Document doc) throws Exception{
//		if(graphicChartTemplate == null){
//			graphicChartTemplate = XMLUtil.parseFile(Util.UTIL_RESOURCE_DIR + "GraphicChartTemplate.xml").getDocumentElement();
//		}
//		NodeList figures = XMLUtil.xpathNodeSet(doc, "//figure");
//		for(int i=0; i<figures.getLength(); i++){
//			Element figure = (Element)figures.item(i);
//			Node graphic = XMLUtil.xpathNode(figure, "/graphic");
//			Node parentNode = figure.getParentNode();
//			
//			Element chart = (Element) doc.importNode(graphicChartTemplate.cloneNode(true), true);
//			
//			//in a <itm-lst>, a figure could be in front of the first ptxt while chart has to be after first ptxt, let's move the new <chart> to the end of last <lst-itm> in this case
//			if(parentNode.getNodeName().equalsIgnoreCase("lst-itm") && XMLUtil.xpathNodeSet(figure, "/preceding-sibling::*").getLength() == 0){
//				Node preListItem = XMLUtil.xpathNode(parentNode, "/preceding-sibling::lst-itm[1]");
//				if(preListItem != null){
//					pl("add graphic chart to previous lst-itm");
//					preListItem.appendChild(chart);
//				}else{//this is first <lst-itm>
//					
//					//turn existing <ptxt> into <para><ptxt>
//					Node ptxt = XMLUtil.xpathNode(parentNode, "/ptxt"); //should be only one
//					Node para = doc.createElement("para");
//					parentNode.insertBefore(para, ptxt);
//					para.appendChild(ptxt);
//					
//					//add <chart>
//					parentNode.insertBefore(chart, figure);
//					Node emptyPtxt = doc.createElement("ptxt");
//					parentNode.insertBefore(emptyPtxt, chart);
//					
//
//				}
//			}else{
//				parentNode.insertBefore(chart, figure);
//			}
//			
//			Node entry = XMLUtil.xpathNode(chart, "//entry");
//			entry.appendChild(graphic);
//
//			pl("converted figure to chart: " + XMLUtil.xmlToString(figure));
//			XMLUtil.xpathCommentOut(figure);
//			//figure.getParentNode().removeChild(figure);
//		}
//	}

}
