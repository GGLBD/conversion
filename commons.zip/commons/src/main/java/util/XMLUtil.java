package util;

import static util.XMLUtil.xmlToString;

import java.io.*;

import javax.xml.XMLConstants;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;
import javax.xml.xpath.*;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.helpers.DefaultHandler;

import java.util.*;
import java.util.regex.*;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;

public class XMLUtil extends Base {

	//public static String fileRoot = "..\\data\\SGMLConversion\\temp\\";
	public static String fileRoot = "..\\data\\SGMLConversion\\";
	public final static String processBookMarks = "==procEssedByJavaCode==";
	public final static String DTDEntityEscapse = "#@SOM1_Entity@#";
	public static List<Node> removeNodes = new ArrayList<Node>();
	public static List<String> xpaths = new ArrayList<String>();

	public static String content;
	public static Document doc;
	public final static String SGMLHeaderEnd = "//EN\">";
	public final static String SGMLHeaderIdentifer = "MITCHELL1//EN\">";
	public final static String SGMLHeaderIdentifer_TSB = "TSB//EN\">";
	public final static String SGMLHeaderIdentifer_RECALLS = "RECALL//EN\">";
	public final static String SOM1Header = "<!DOCTYPE SOM1 PUBLIC \"-//MRIC//DTD SNAPON MITCHELL1//EN\">";
	public final static String COLLISIONHeader = "<!DOCTYPE COLLISION PUBLIC \"-//MRIC//DTD COLLISION//EN\">"; //<!DOCTYPE COLLISION PUBLIC "-//MRIC//DTD COLLISION//EN">
	public final static String ArborText = "<!--ArborText, Inc., 1988-1998, v.4002-->";
	// e.g. <!DOCTYPE SOM1 PUBLIC "-//MRIC//DTD SNAPON MITCHELL1//EN">
	public static String SGMLHeader;
	static int tableID ;
	public static int listFixedCount = 0;
	public static int figureFixedCount = 0;
	public static int stuffedFixedCount = 0;
	private static int dedupCount = 0;
	private static List<String> ids = new ArrayList<String>();
	private static int moveNodesIntoInfoObjCount = 0;
	private static int sharedCount = 0;
	
	
	public static void main(String[] args) throws Exception{

		String utf8String = "<ptxt>10 MΩ or higher</ptxt>";
		
		
		Document doc;
		
		doc = parseFile("C:\\Users\\ss1819\\Desktop\\tmp\\xml\\test.html");
		System.out.println(xmlToString(doc));
		System.exit(0);
		
		String str1 = "<serv-cat servcat.name=\"Driveshaft &amp; Universal Joints\">";
		//str1 = str1.replaceAll("servcat.name=\"[^>]*amp;", "");
		str1 = str1.replaceAll("&amp;", "&");
		pl(str1);
		System.exit(0);
		
		System.out.println(str1.replaceFirst(">", ">" + ArborText));
		System.exit(0);
		

		String content = FileUtil.reader("../data/test.xml");
		System.out.println(1+content);

		System.out.println(2+content);
		doc = parseStr(content);
		System.out.println(3+xmlToString(doc));
		System.out.println(resumeEntities(4+xmlToString(doc)));
		System.exit(0);
		
		System.exit(0);
		
		/**
		 * get all element xpaths
		 */
		
		
		/**
		 * get all element names
		 */
		
		String str = "<infotype id=\"CHRdbef35d0c6f910048cf1bab85d080c5b\" infotypevalue=\"41\">";
		System.out.print(str);
		System.out.print(removeAttribute(str, "id"));
		List<String> lst = new ArrayList<String>();
		lst.add("CHR1245950644161,2010LX-02-01.sgm,extxref,extrefid");
		lst.add("CHR12459,2010LX-02-01.sgm,extxref,extrefid");
		lst.add("CHR124591,2010LX-02-01.sgm,extxref,extrefid");
		lst.add(",2010LX-02-01.sgm,extxref,extrefid");
		System.out.println(idOccurrences(lst, "CHR1245950644161"));
	}
	
	public static Stream<Node> getNodeListStream(NodeList nodeList) {
		Stream<Node> nodeStream = IntStream.range(0, nodeList.getLength())
                .mapToObj(nodeList::item);
		return nodeStream;
	}
	
	/**
	 * insert newNode after afterNode
	 */
	public static void insertAfter(Node parentNode, Node newNode, Node afterNode){
		if(afterNode.getNextSibling() == null){
			parentNode.appendChild(newNode);
		}else{
			parentNode.insertBefore(newNode, afterNode.getNextSibling());
		}
			
	}
	
	/*	
	public static NodeList xpathNodeSet(Node node, String xpath) throws Exception{
		//System.out.println("xpath="+xpath);
	    XPathFactory factory = XPathFactory.newInstance();
	    XPath xp = factory.newXPath();
	    XPathExpression expr ;
		if(node.getNodeType() == Node.DOCUMENT_NODE){
			expr = xp.compile(xpath);
			//System.out.println("xpathBase node.getNodeType() == Node.DOCUMENT_NODE");
			return (NodeList)expr.evaluate(node, XPathConstants.NODESET);
		}
		else{
			//get absoulte xpath against to document
			String absolutePath = getXpath(node) + xpath;
			//System.out.println(absolutePath);
			expr = xp.compile(absolutePath);
			NodeList result = (NodeList)expr.evaluate(node, XPathConstants.NODESET);
			if(result.getLength()==0){
				//System.out.println("xpathBase xpath="+xpath+" abxpath=" +absolutePath + "getXpath(node)="+getXpath(node)+ "\n"+ xmlToString(node));
			}
			return result;
			}
	}
*/
	/**
	 * 
	 *remove processing instructions
	 */
	public static void removeAllProcessingInstructions(Node inputNode) throws Exception{

		NodeList eles = XMLUtil.xpathNodeSet(inputNode,"//*");
		for(int j=0; j<eles.getLength(); j++){
			NodeList nodes = eles.item(j).getChildNodes();
			for(int i=0; i<nodes.getLength(); i++){
				Node node = nodes.item(i);
				if(node.getNodeType() == Node.PROCESSING_INSTRUCTION_NODE){
					pl("removing PI:"+node.getTextContent());
					node.getParentNode().removeChild(node);
					i--; //NodeList nodes is a view
				}
			}
		}
	}

	
	/**
	 * to populate table with more entries for table with <morerows> attribute, all inserted dummy entries coming with attribute called 'deleteme'
	 * use XMLUtil.xpathRemove(table, "//entry[@deleteme]") to remove all dummy entries
	 */
	public static void normalizeTable(Node table)throws Exception{
		//System.out.println("Start of normalizing Table");
		NodeList rows = xpathNodeSet(table, "//tbody/row"); 
		//insert dummy <entry> for possible morerows attribute on some rows <entry valign="middle" morerows="6">
		int rowCount = Integer.parseInt(xpathStr(table, "//tbody/count(row)"));
		int colCount = Integer.parseInt(xpathStr(table, "//tbody/row[1]/count(entry)"));
		//table row and column bitmap, existing entry presented with 0, dummy entry presented with -1
		int[][] tabArr = new int[rowCount][colCount];
		for(int j=0; j<rows.getLength(); j++){
			Element row = (Element)rows.item(j);
			NodeList moreRowsEntries = XMLUtil.xpathNodeSet(row, "/entry[@morerows]");
			for(int k=0; k<moreRowsEntries.getLength(); k++){
				int entryPos = Integer.parseInt(xpathStr(moreRowsEntries.item(k), "/count(preceding-sibling::*)+1"));
				int moreRows = Integer.parseInt(((Element)moreRowsEntries.item(k)).getAttribute("morerows"));
				for(int i=0; i<moreRows; i++){
					tabArr[j+i+1][entryPos-1] = -1;
				}
			}
		}
		for(int i=0; i<rowCount; i++){
			for(int j=0; j<colCount; j++){
				//System.out.print(tabArr[i][j] + " ");
				if(tabArr[i][j]==-1){
					Node row = xpathNode(table, "//tbody/row["+ (i+1) +"]");
					Element dummyEntry = table.getOwnerDocument().createElement("entry");
					dummyEntry.setAttribute("deleteme", "1");
					if(j+1 == colCount){
						row.appendChild(dummyEntry);
					}else{
						Node postEntry = xpathNode(row, "/entry[" + j+2 + "]");
						row.insertBefore(dummyEntry, postEntry);
					}
				}
			}
			System.out.println();
		}
	 }
	
	public static boolean validAgainstSOM1Schema(Document doc, String xsdFile, String fileName)throws Exception{
		  // create a SchemaFactory capable of understanding WXS schemas
	    SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);

	    // load a WXS schema, represented by a Schema instance
	    Source schemaFile = new StreamSource(new File(xsdFile));
	    Schema schema = factory.newSchema(schemaFile);

	    // create a Validator instance, which can be used to validate an instance document
	    Validator validator = schema.newValidator();

	    // validate the DOM tree
	    try {
	        validator.validate(new DOMSource(doc));
	    } catch (SAXException e) {
	    	//if(!e.getMessage().contains("multiple occurrences of ID value"))System.err.println("XML Validation Exception : "+ e.getMessage());  	
	    	
	    	System.err.println("XML Validation Exception : "+ e.getMessage() + " in file:"+fileName);  
	    	
	    	return false;
	    } 
		return true;
	}
	
	public static boolean validAgainstSOM1Schema(Document doc)throws Exception{
		return validAgainstSOM1Schema(doc, "");
	}
	
	public static boolean validAgainstSOM1Schema(Document doc, String fileName)throws Exception{
		return validAgainstSOM1Schema(doc, "C:/Users/ss1819/Desktop/MEPS_ADEPT/som1_con.xsd", fileName);
	}
	/**
	 * evaluate xpath against a node, Note that the return NodeList seems not a dynamic list!! 
	 */
	public static NodeList xpathNodeSet(Node node, String... xpaths) throws Exception{
		return (NodeList)xpath(node, XPathConstants.NODESET, xpaths);
	}
	
	/**
	 * evaluate xpath against a node, return a String value 
	 */
	public static String xpathStr(Node node,String... xpaths) throws Exception{
		return (String)xpath(node, XPathConstants.STRING, xpaths );
	}
	
	/**
	 * evaluate xpath against a node, return a Node value 
	 */
	/*public static Node xpathNode(Node node, String... xpaths) throws Exception{
		return (Node)xpath(node, XPathConstants.NODE, xpaths );
	}*/
	
	/**
	 * evaluate xpath against a node, return a Node value
	 * an Exception is thrown if more than one Node found 
	 */
	public static Node xpathNode(Node node, String... xpaths) throws Exception{
		NodeList lst = xpathNodeSet(node, xpaths );
		if(lst==null || lst.getLength()==0){
			return null;
		}else if(lst.getLength()==1){
			return lst.item(0);
		}else{
			throw new Exception("More than one node found lst.getLength()="+lst.getLength());
		}
	}
	
	/**
	 * evaluate xpath against a node, Note that the return NodeList seems not a dynamic list!! 
	 * returnType = XPathConstants.BOOLEAN, DOM_OBJECT_MODEL, NODE, NODESET, NUMBER, STRING
	 */
	public static Object xpath(Node node, QName returnType, String... xpaths ) throws Exception{
		if(xpaths.length==0){
			xpaths = new String[1];
			xpaths[0] = "";
		}
			
	    XPathFactory factory = new net.sf.saxon.xpath.XPathFactoryImpl();
	   // System.out.println("factory:"+factory.getClass());//net.sf.saxon.xpath.XPathFactoryImpl
	    XPath xp = factory.newXPath();
	    XPathExpression expr ;
	    String absolutePath = "";
	    for(int i=0; i<xpaths.length; i++){
	    	String xpath = xpaths[i];
			//System.out.println("xpath="+xpath);
			if(node.getNodeType() == Node.DOCUMENT_NODE){
				absolutePath += "|" + xpath;
			}
			else{
				//get absoulte xpath against to document
				absolutePath += "|" + getXpath(node) + xpath;
				}
	    }
	    absolutePath = absolutePath.substring(1);
  //System.out.println("absoluteXPath="+absolutePath);
		expr = xp.compile(absolutePath);
		return expr.evaluate(node, returnType);
	}
	
	/**
	 * comment out all elements specified by xpath
	 * return number of affected elements 
	 */
	public static int xpathCommentOut(Node node) throws Exception{
		return xpathCommentOut(node, "");
	}
	
	/**
	 * comment out all elements specified by xpath, add a note (extraNote) to the comment
	 * .return number of affected elements 
	 */
	public static int xpathCommentOut(String extraNode, Node node) throws Exception{
		return xpathCommentOut(extraNode, node, "");
	}

	/**
	 * comment out all elements specified by xpath
	 * return number of affected elements 
	 */
	public static int xpathCommentOut(Node node, String... xpaths) throws Exception{
		return xpathCommentOut("", node, xpaths);
	}
	
	/**
	 * comment out all elements specified by xpath, add a note (extraNote) to the comment
	 * return number of affected elements 
	 */
	public static int xpathCommentOut(String extraNote, Node node, String... xpaths) throws Exception{
		NodeList lst = xpathNodeSet(node, xpaths);
		for(int j=0; j<lst.getLength(); j++){
			Node ele = lst.item(j);
			Node comment = ele.getOwnerDocument().createComment((extraNote + XMLUtil.xmlToStringNoHeader(ele)).replace("--", "=="));
			ele.getParentNode().replaceChild(comment, ele);
		}	
		return lst.getLength();
	}
	

	/**
	 * remove all these elements specified by xpath from the document
	 * return number of affected elements 
	 */
	public static int xpathRemove(Node node, String... xpaths) throws Exception{
		NodeList removeLst = xpathNodeSet(node, xpaths);
		for(int i=0; i<removeLst.getLength(); i++){
			Node n = removeLst.item(i);
			//System.out.println("xpathRemove"+XMLUtil.xmlToString(n));
			n.getParentNode().removeChild(n);
		}
		return removeLst.getLength();
	}
	
	/**
	 * remove all these elements specified by xpath from the document
	 * input att="@*" to remove all attributes from given node
	 * return number of affected elements 
	 */
	public static int xpathRemoveAtt(Node node, String att, String... xpaths) throws Exception{
		NodeList removeLst = xpathNodeSet(node, xpaths);
		for(int i=0; i<removeLst.getLength(); i++){
			Element n = (Element)removeLst.item(i);
			if(att.equals("@*")){
				NamedNodeMap map = n.getAttributes();
				for(int j=0; j<map.getLength(); j++){
					//pl("map.item(j).getNodeName()"+map.item(j).getNodeName());
					n.removeAttribute(map.item(j).getNodeName());
				}
			}else{
				n.removeAttribute(att);	
			}
		}
		return removeLst.getLength();
	}
	
	/**
	 * add attribute to all these elements specified by xpath from the document
	 * return number of affected elements 
	 */
	public static int xpathAddAtt(Node node, String att, String value, String... xpaths) throws Exception{
		NodeList lst = xpathNodeSet(node, xpaths);
		for(int i=0; i<lst.getLength(); i++){
			Element n = (Element)lst.item(i);
			n.setAttribute(att, value);
		}
		return lst.getLength();
	}
	
	/**
	 * return a node's predicate, relatively to its parent node
	 * Predicates are always embedded in square brackets. such as 1 and 2 in /tocxml/tocitem[1]/tocitem[2]
	 */
	public static int getXpathPredicate(Node node)throws Exception{
		int predicate = 1;
		String nodeName = node.getNodeName();
		Node preSibling = node.getPreviousSibling();
		while(preSibling != null){
			if(preSibling.getNodeName().equals(nodeName) && 
					preSibling.getNodeType() == node.getNodeType()){
				//System.out.println("nodeName="+nodeName+" type="+node.getNodeType()+" preSibling="+preSibling.getNodeType());
				predicate++;
			}
			preSibling = preSibling.getPreviousSibling();
		}
		return predicate;
	}
	
	/**
	 * method to return a given node's xpath
	 */
	public static String getXpath(Node node)throws Exception{
		String xpath = "/";
		if(node.getNodeType() == Node.DOCUMENT_NODE){
			return xpath;
		}else{
			//System.out.println("node.getNodeName="+node.getNodeName());
			String nodeName = node.getNodeName();
			
			/*if(nodeName.equals("#comment")){
				nodeName = "comment()";
			}*/
			
			if(node.getNodeType() == Node.COMMENT_NODE ){
				nodeName = "comment()";
			}else if(node.getNodeType() == Node.PROCESSING_INSTRUCTION_NODE ){
				nodeName = "processing-instruction()";
			}/*else{
				throw new RuntimeException("node type "+node.getNodeType() + " needed to be processed");
			}*/
				
			xpath += nodeName + "[" + getXpathPredicate(node) + "]";
			//traverse to the root
			Node parent = node.getParentNode();
			while(parent != null && parent.getNodeType() != Node.DOCUMENT_NODE){
				xpath = "/" + parent.getNodeName() + "[" + getXpathPredicate(parent) + "]" + xpath;
				parent = parent.getParentNode();
			}
		}
		return xpath;
	}
	
	/**
	 * load all xml in a given folder into a Map, with file name as keys and parsed Document as values
	 */
	public static Map<String, Document> loadXMLs2HashMap(String srcDir) throws Exception{
		Map<String, Document> result = new HashMap<String, Document>();
		List<String> xmlFiles = FileUtil.getAllFilesWithCertainExt(srcDir, "xml");
		int count = 0;
		for(String s:xmlFiles){
			result.put(s, parseFile(srcDir + s));
			//System.out.println(s);
			count++; 
			if(count % 100 == 0)
				System.out.print(" " + count);
			//if(count>300000)	break;
		}
		return result;
	}
	
	/**
	 * load all xml in a given folder into a Document list
	 */
	public static List<Document> loadXMLs2List(String srcDir) throws Exception{
		List<Document> result = new ArrayList<Document>();
		List<String> xmlFiles = FileUtil.getAllFilesWithCertainExt(srcDir, "xml");
		for(String s:xmlFiles){
			result.add(parseFile(srcDir + s));
		}
		return result;
	}
	
/*	public static Document parse(InputStream stream) throws Exception {
		Document document = null;
		// Initiate DocumentBuilderFactory
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setExpandEntityReferences(false);

		// To get a validating parser
		factory.setValidating(false);
		// To get one that understands namespaces
		factory.setNamespaceAware(false);

		try {
			// Get DocumentBuilder
			DocumentBuilder builder = factory.newDocumentBuilder();
			// Parse and load into memory the Document
			
			document = builder.parse(stream);
			return document;

		} catch (SAXParseException spe) {
			// Error generated by the parser
			//System.out.println("\n** Parsing error , line "		+ spe.getLineNumber() + ", uri " + spe.getSystemId() );
			//System.out.println(" " + spe.getMessage());
			// Use the contained exception, if any
			Exception x = spe;
			if (spe.getException() != null)
				x = spe.getException();
			x.printStackTrace();
			throw spe;
		} catch (SAXException sxe) {
			// Error generated during parsing
			Exception x = sxe;
			if (sxe.getException() != null)
				x = sxe.getException();
			x.printStackTrace();
			throw sxe;
		} catch (ParserConfigurationException pce) {
			// Parser with specified options can't be built
			pce.printStackTrace();
			throw pce;
		} catch (IOException ioe) {
			// I/O error
			ioe.printStackTrace();
			throw ioe;
		}
//		return null;
	}
*/	
	public static Document parseStr(String xmlStr) throws Exception {
		/*
		* There might be a invalid char before <?xml version="1.0" encoding="utf-8"?>, let's remove it
		* http://mark.koli.ch/2009/02/resolving-orgxmlsaxsaxparseexception-content-is-not-allowed-in-prolog.html
		 */
		String xml = xmlStr.trim().replaceFirst("^([\\W]+)<","<");
		//pl("parsing xml="+xml);
		//String xml = xmlStr;
		return parse_base_DOM(new ByteArrayInputStream(xml.getBytes()));
		/*CharsetDecoder utf8Decoder = Charset.forName("UTF-8").newDecoder();
		utf8Decoder.onMalformedInput(CodingErrorAction.IGNORE);
		utf8Decoder.onUnmappableCharacter(CodingErrorAction.IGNORE);
		ByteBuffer bytes = ByteBuffer.wrap(xmlStr.getBytes());
		CharBuffer parsed = utf8Decoder.decode(bytes);
		return parse_base(new ByteArrayInputStream(parsed.toString().getBytes()));*/
		//return parse_base(new ByteArrayInputStream(removeNonUtf8CompliantCharacters(xmlStr).getBytes()));
		//return parse_base(new ByteArrayInputStream((xmlStr.replaceAll("[^\\x20-\\x7e]", "")).getBytes()));
	}
	
	public static Document parseStr_DTD(String xmlStr) throws Exception {

		String xml = xmlStr.trim().replaceFirst("^([\\W]+)<","<");
		//String xml = xmlStr;
		return parse_base_DOM_DTD(new ByteArrayInputStream(xml.getBytes()));
	}
	
	//this code breaks xml parsing!!!!
	public static String removeNonUtf8CompliantCharacters( final String inString ) {
	    if (null == inString ) return null;
	    byte[] byteArr = inString.getBytes();
	    for ( int i=0; i < byteArr.length; i++ ) {
	        byte ch= byteArr[i]; 
	        // remove any characters outside the valid UTF-8 range as well as all control characters
	        // except tabs and new lines
	        if ( !( (ch > 31 && ch < 253 ) || ch == '\t' || ch == '\n' || ch == '\r') ) {
	            byteArr[i]=' ';
	        }
	    }
	    return new String( byteArr );
	}

	/**
	 * Parse the XML file and return Document
	 */
	public static Document parseFile(String fileName) throws Exception {
		String xml = FileUtil.reader(fileName);
		return parseStr(xml);
	}
	
	/**
	 * Parse the XML file and return Document
	 */
	public static Document parseFile_DTD(String fileName) throws Exception {
		String xml = FileUtil.reader(fileName);
		return parseStr_DTD(xml);
	}
	
	static Document parse_base_DOM_DTD(InputStream inputStream) throws Exception {
		Document document = null;
		// Initiate DocumentBuilderFactory
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setFeature("http://apache.org/xml/features/nonvalidating/load-dtd-grammar", true);
		factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", true);
		factory.setExpandEntityReferences(true);

		// To get a validating parser
		factory.setValidating(true);
		// To get one that understands namespaces
		factory.setNamespaceAware(true);
		
		//SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		//factory.setSchema(schemaFactory.newSchema(new Source[] {new StreamSource("C:\\eclipse\\Eclipse_Java\\workspace\\Util\\bulletin.xsd")}));


		try {
			// Get DocumentBuilder
			DocumentBuilder builder = factory.newDocumentBuilder();
			//System.out.print("\n****" + builder.isValidating());
			// Parse and load into memory the Document
			Reader reader = new InputStreamReader(inputStream,"UTF-8");
			InputSource is = new InputSource(reader);
			is.setEncoding("UTF-8");

			document = builder.parse(is);
			return document;

		} catch (SAXParseException spe) {
			// Error generated by the parser
			System.out.println("\n** Parsing error , line "
					+ spe.getLineNumber() + ", uri " + spe.getSystemId());
			System.out.println(" " + spe.getMessage());
			// Use the contained exception, if any
			Exception x = spe;
			if (spe.getException() != null)
				x = spe.getException();
			x.printStackTrace();
			throw spe;
		} catch (SAXException sxe) {
			// Error generated during parsing
			Exception x = sxe;
			if (sxe.getException() != null)
				x = sxe.getException();
			x.printStackTrace();
			throw sxe;
		} catch (ParserConfigurationException pce) {
			// Parser with specified options can't be built
			pce.printStackTrace();
			throw pce;
		} catch (IOException ioe) {
			// I/O error
			ioe.printStackTrace();
			throw ioe;
		}
//		return null;
	}
	
	static Document parse_base_DOM(InputStream inputStream) throws Exception {
		Document document = null;
		// Initiate DocumentBuilderFactory
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setFeature("http://apache.org/xml/features/nonvalidating/load-dtd-grammar", false);
		factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
		factory.setExpandEntityReferences(false);

		// To get a validating parser
		factory.setValidating(false);
		// To get one that understands namespaces
		factory.setNamespaceAware(false);

		try {
			
			// Get DocumentBuilder
			DocumentBuilder builder = factory.newDocumentBuilder();
			//System.out.print("\n****" + builder.isValidating());
			// Parse and load into memory the Document
			Reader reader = new InputStreamReader(inputStream);
			InputSource is = new InputSource(reader);
			is.setEncoding("UTF-8");
			
			document = builder.parse(is);
			//pl("file="+XMLUtil.xmlToString(document).substring(6100, 6300));
			return document;

		} catch (SAXParseException spe) {
			// Error generated by the parser
			System.out.println("\n** Parsing error , line "
					+ spe.getLineNumber() + ", uri " + spe.getSystemId());
			System.out.println(" " + spe.getMessage());
			// Use the contained exception, if any
			Exception x = spe;
			if (spe.getException() != null)
				x = spe.getException();
			x.printStackTrace();
			throw spe;
		} catch (SAXException sxe) {
			// Error generated during parsing
			Exception x = sxe;
			if (sxe.getException() != null)
				x = sxe.getException();
			x.printStackTrace();
			throw sxe;
		} catch (ParserConfigurationException pce) {
			// Parser with specified options can't be built
			pce.printStackTrace();
			throw pce;
		} catch (IOException ioe) {
			// I/O error
			ioe.printStackTrace();
			throw ioe;
		}
//		return null;
	}
	
	public static void parse_base_SAX(InputStream inputStream, DefaultHandler handler) throws Exception {
		SAXParserFactory factory = SAXParserFactory.newInstance();
		factory.setFeature("http://apache.org/xml/features/nonvalidating/load-dtd-grammar", false);
		factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
		factory.setNamespaceAware(false);
		factory.setValidating(false);

		try {
			SAXParser parser = factory.newSAXParser();
			parser.parse(inputStream, handler);
		} catch (ParserConfigurationException e) {
			System.err.println("The underlying parser does not support "
					+ " the requested features. ");
			throw e;
		} catch (FactoryConfigurationError e) {
			System.err.println("Error occurred obtaining SAX Parser Factory. ");
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * Turn MEPS article SGML to Document
	 */
	public static Document Article2Doc(String articleFileName) throws Exception {
		String content = FileUtil.reader(articleFileName); 
		content = XMLUtil.Article2XML(content);
		return XMLUtil.parseStr(content);
	}
	
	/**
	 * Turn MEPS article SGML to XML for parsing
	 */
	public static String Article2XML(String str) throws Exception {
		String content = str;
		content = toXML(str);
		content = closeTag(content, "article-id");
		content = closeTag(content, "src-pages");
		content = closeTag(content, "fault.code");
		content = closeTag(content, "obd.code");
		content = closeTag(content, "oe.component.name");
		content = closeTag(content, "oe.component.end");
		content = closeTag(content, "spn.code");
		content = closeTag(content, "pid.code");
		content = closeTag(content, "sid.code");
		content = closeTag(content, "oe.engine.name");
		content = closeTag(content, "oe.dtc.end");
		content = closeTag(content, "c-srvcat");
		content = closeTag(content, "c-base");
		content = closeTag(content, "c-systm");
		
		//Non repair manual items
		content = closeTag(content, "bundle.application");
		
		

		//System.out.println("content="+content);
		
		content = closeXMLInstruction(content, "pub");
		content = closeXMLInstruction(content, "tracking");
		
		//System.out.println("content1="+content);

		//System.out.println(content);
		return content;
	}
	
	/**
	 * Turn XML back to MEPS article SGML
	 */
	public static String xml2Article(Document doc) throws Exception {
		//pl("xml2Article");
		XMLUtil.stuffEmptyElement(doc);
		String content = xmlToString(doc);
		content = toSGML(content);
		content = openTag(content, "article-id");
		content = openTag(content, "src-pages");
		content = openTag(content, "fault.code");
		content = openTag(content, "obd.code");
		content = openTag(content, "oe.engine.name");
		content = openTag(content, "oe.component.name");
		content = openTag(content, "oe.component.end");
		content = openTag(content, "spn.code");
		content = openTag(content, "pid.code");
		content = openTag(content, "sid.code");
		content = openTag(content, "oe.dtc.end");
		content = openTag(content, "c-srvcat");
		content = openTag(content, "c-base");
		content = openTag(content, "c-systm");
		
		
		//Non repair manual items
		content = openTag(content, "bundle.application");
		
		
		content = openXMLInstruction(content, "pub");
		//<!-- <page="dn02-79"> -->
		content = content.replace("page=\"dn", "page=\"DN");
		//<?pub *0000220647>
		content = content.replace("<?pub", "<?Pub");
		//System.out.println("content=="+content);
		return content;
	}
	
	
	/**
	 * Turn SGML to XML for parsing
	 */
	public static String toXML(String str) throws Exception {
		String content = str;
		// System.out.println(1+content);
		content = removeHeader(content);
		//System.out.println(2+content);
		content = makeTagsLowerCase(content);
		
		//content = escapeEntities(content);
		//SOM1 DTD allows & inside a element attribut value, XML doesn't, this statement should cover previous escapeEntities() already
		content = content.replace("&",DTDEntityEscapse );
		
		//resume xml entities
		content = content.replace(DTDEntityEscapse+"amp;","&amp;" );
		content = content.replace(DTDEntityEscapse+"lt;","&lt;" );
		content = content.replace(DTDEntityEscapse+"gt;","&gt;" );
		
		content = closeTag(content, "graphic");
		// System.out.println(3+content);
		content = closeTag(content, "colspec");
		content = closeTag(content, "serv-cat"); //for Chrysler
		content = closeTag(content, "spanspec");
		return content;

		//System.out.println(4+content);
	}
	
	/**
	 * Turn XML back to Mitchell1 SGML format
	 */
	public static String toSGML(String str) throws Exception {
		String content = str;
		content = addHeader(content);
		content = resumeEntities(content);
		//remove processBookMarks
		content = content.replaceAll(processBookMarks, "");
		content = openTag(content, "graphic");
		// System.out.println(3+content);
		content = openTag(content, "colspec");
		content = openTag(content, "serv-cat");
		content = openTag(content, "spanspec");
		/*
		 * //SOM1 dtd likes &lt to be &lt;   , however, it likes &gt;  be >   , Strange!!!
		 * <ptxt>Meter warning buzzer &lt; EATON transmission ></ptxt>
		 */
		content = content.replace("&gt;", ">");
		return content;
	}
	
	//replace XML header with SGML header
	public static String addHeader(String content){
		if(!content.contains(ArborText)){
			content = content.replaceFirst(">", ">" + ArborText);
			//System.out.println(content.substring(0, 200));
		}
		return content.replace("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>", 
				SGMLHeader==null?SOM1Header:SGMLHeader).replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>", SGMLHeader==null?SOM1Header:SGMLHeader);
	}

	public static String removeHeader(String str) {
		String content = str.trim();
		// <!DOCTYPE SOM1 PUBLIC "-//MRIC//DTD SNAPON MITCHELL1//EN">
		if(content.startsWith("<!DOCTYPE")){
			int index = content.indexOf(SGMLHeaderEnd);
			SGMLHeader = content.substring(0,index + SGMLHeaderEnd.length());
			content = content.substring(index + SGMLHeaderEnd.length());
		}
		/*int index = content.indexOf(SGMLHeaderIdentifer);
		if (index != -1){
			SGMLHeader = content.substring(0,index + SGMLHeaderIdentifer.length());
			content = content.substring(index + SGMLHeaderIdentifer.length());
			}
		index = content.indexOf(SGMLHeaderIdentifer_TSB);
		if (index != -1){
			SGMLHeader = content.substring(0,index + SGMLHeaderIdentifer_TSB.length());
			content = content.substring(index + SGMLHeaderIdentifer_TSB.length());
			}
		index = content.indexOf(SGMLHeaderIdentifer_RECALLS);
		if (index != -1){
			SGMLHeader = content.substring(0,index + SGMLHeaderIdentifer_RECALLS.length());
			content = content.substring(index + SGMLHeaderIdentifer_RECALLS.length());
			}*/
		return content;
		//System.out.println(content);
	}
	
	public static Element changeElementName(Element element, String newName) throws Exception {
		// Create an element with the new name 
		Element element2 = doc.createElement(newName); 
		
		// Copy the attributes to the new element 
		NamedNodeMap attrs = element.getAttributes(); 
		for (int i=0; i<attrs.getLength(); i++) { 
			Attr attr2 = (Attr)doc.importNode(attrs.item(i), true);
		    element2.getAttributes().setNamedItem(attr2); 
		} 
		
		// Move all the children 
		while (element.hasChildNodes()) {
		 element2.appendChild(element.getFirstChild()); 
		} 
		
		// Replace the old node with the new node 
		element.getParentNode().replaceChild(element2, element);
		
		return element2;
	}
	
	/*
	//convert all entities, such as &reg; , to 
	public static String escapeEntities(String str) {
		String content = str;
		// Create a pattern to match cat
		String regExp = "&[^><&;\t ]*;"; //&reg;
		Pattern p = Pattern.compile(regExp);
		// Create a matcher with an input string
		Matcher m = p.matcher(content);
		StringBuffer sb = new StringBuffer();
		boolean result = m.find();
		// Loop through and create a new String
		// with the replacements
		while (result) {
			//System.out.println(m.group());
			if((m.group().equalsIgnoreCase("&gt;") ||
					m.group().equalsIgnoreCase("&lt;") ||
					m.group().equalsIgnoreCase("&amp;"))){
				m.appendReplacement(sb, m.group().replace("&", DTDEntityEscapse + "XMLSpecialChar"));
			}else{
				m.appendReplacement(sb, m.group().replace("&", DTDEntityEscapse));
			}
			result = m.find();
		}
		// Add the last segment of input to
		// the new String
		m.appendTail(sb);
		content = sb.toString();
		content = content.replace((DTDEntityEscapse + "XMLSpecialChar"), "&");
		return content;
		// System.out.println(sb.toString());
	}
	*/
	
	//resume all entities, such as from #@SOM1_Entity@#reg; to &reg; 
	public static String resumeEntities(String str) {
		return str.replaceAll(DTDEntityEscapse, "&");
	}

	public static String makeTagsLowerCase(String str) {
		String content = str;
		// Create a pattern to match cat
		String regExp = "<[/]?[^>! ]*";
		Pattern p = Pattern.compile(regExp);
		// Create a matcher with an input string
		Matcher m = p.matcher(content);
		StringBuffer sb = new StringBuffer();
		boolean result = m.find();
		// Loop through and create a new String
		// with the replacements
		while (result) {
			m.appendReplacement(sb, m.group().toLowerCase());
			result = m.find();
		}
		// Add the last segment of input to
		// the new String
		m.appendTail(sb);
		content = sb.toString();
		// System.out.println(sb.toString());
		return content;
	}
	
	// to close SGML instructions without end-tags, such as <?Pub *0000003881>, need turn it into <?Pub *0000003881?>
	public static String closeXMLInstruction(String str, String tagName) throws Exception {
		String content = str;
		/**
		 * there are 11 characters with special meanings: the opening square bracket [, the backslash \, the caret ^, 
		 * the dollar sign $, the period or dot ., the vertical bar or pipe symbol |, the question mark ?, the asterisk or star *, 
		 * the plus sign +, the opening round bracket ( and the closing round bracket ). 
		 * These special characters are often called "metacharacters".
		 */
		String regExp = "<\\?" + tagName + "[^>]*" ;
		// Create a pattern to match cat
		Pattern p = Pattern.compile(regExp);
		// Create a matcher with an input string
		Matcher m = p.matcher(content);
		StringBuffer sb = new StringBuffer();
		boolean result = m.find();
		// Loop through and create a new String
		// with the replacements
		while (result) {
			m.appendReplacement(sb, m.group()+"?");
			result = m.find();
		}
		// Add the last segment of input to
		// the new String
		m.appendTail(sb);
		content = sb.toString();
		// System.out.println(sb.toString());
		return content;
	}
	
	/**
	 * open XML instruction tags to meet SGML DTD, e.g.  <?Pub *0000003881?> ->  <?Pub *0000003881>
	 */ 
	public static String openXMLInstruction(String str, String tagName) throws Exception {
		String content = str;
		//openTag("<graphic[^>]*/>");
		String regExp = "<\\?" + tagName + "[^>]*\\?>";
		// Create a pattern to match cat
		Pattern p = Pattern.compile(regExp);
		// Create a matcher with an input string
		Matcher m = p.matcher(content);
		StringBuffer sb = new StringBuffer();
		boolean result = m.find();
		// Loop through and create a new String
		// with the replacements
		while (result) {
			m.appendReplacement(sb, m.group().replace("?>", ">"));
			result = m.find();
		}
		// Add the last segment of input to
		// the new String
		m.appendTail(sb);
		content = sb.toString();
		// System.out.println(sb.toString());
		return content;
	}

	// to close SGML elements without end-tags, such as <graphic>, <colspec colwidth="359*">
	public static String closeTag(String str, String tagName) throws Exception {
		final String BACK_SLASH = "@@bACk_slAsh@@";
		String content = str;
		//		closeTag("<graphic[^>]*");
		String regExp = "<" + tagName + "[^>]*" ;
		// Create a pattern to match cat
		Pattern p = Pattern.compile(regExp);
		// Create a matcher with an input string
		Matcher m = p.matcher(content);
		StringBuffer sb = new StringBuffer();
		boolean result = m.find();
		// Loop through and create a new String
		// with the replacements
		while (result) {
			m.appendReplacement(sb, m.group()+ BACK_SLASH);
			result = m.find();
		}
		// Add the last segment of input to
		// the new String
		m.appendTail(sb);
		content = sb.toString();
		//if that tag is in comments, do NOT add "/", ie. <!--<figure><graphic grap-->
		content = content.replace("--" + BACK_SLASH + ">", "-->");
		
		content = content.replace(BACK_SLASH, "/");
		// System.out.println(sb.toString());
		return content;
	}
	
	// open tags to meet SGML DTD, e.g. <graphic ..../> -> <graphic ....> , <COLSPEC colwidth="359*"/> -> <COLSPEC colwidth="359*"> 
	public static String openTag(String str, String tagName) throws Exception {
		String content = str;
		//openTag("<graphic[^>]*/>");
		String regExp = "<" + tagName + "[^>]*/>";
		// Create a pattern to match cat
		Pattern p = Pattern.compile(regExp);
		// Create a matcher with an input string
		Matcher m = p.matcher(content);
		StringBuffer sb = new StringBuffer();
		boolean result = m.find();
		// Loop through and create a new String
		// with the replacements
		while (result) {
			m.appendReplacement(sb, m.group().replace("/>", ">"));
			result = m.find();
		}
		// Add the last segment of input to
		// the new String
		m.appendTail(sb);
		content = sb.toString();
		// System.out.println(sb.toString());
		return content;
	}


	public static void printDOMList(NodeList nl) {
		for (int i = 0; i < nl.getLength(); i++) {
			System.out.println("\n\n==========Node" + i + "============");
			printDOM(nl.item(i));
		}
	}
	
	/**
	 * 
	 * to check how many occurrences a give id has in give String list 
	 * CHR1245950636946,2010LX-02-01.sgm,extxref,extrefid
	 * C2431121,2010LX-02-01.sgm,intxref,refid
	 */
		public static int idOccurrences(List<String> refIDs, String id) throws Exception {
			int count = 0;
			for(String s:refIDs){
				if(id.equals(s.substring(0, s.indexOf(","))))
					count++;
			}
			return count;
		}
		
		/**
		 * collect all element xpaths in the srcDir, add them to static List<String> xpaths
		 * set removeDup=true to remove duplicate element xpaths, set it to false to keep duplicates
		 */
	public static List<String> collectAllElementXpath(String srcDir,
			boolean removeDup) throws Exception {
		xpaths.clear();
		List<String> files = FileUtil.getAllFilesWithCertainExt(srcDir, "xml");
		System.out.println("Collecting all element xpaths from " + files.size() + " files in folder "+ srcDir);
		int count = 0;
		for (String file : files) {
			if(++count % 100 == 0) System.out.print(count+ " ");
			if(file.equals("toc.xml")) continue;
			Document doc = parseFile(srcDir + file);
			collectAllElementXpath(doc, "", file, removeDup);
		}
		System.out.println("\n" + xpaths.size() + " xpaths collected");
		return xpaths;
	}
	
	/**
	 * collect all element xpaths given a Node, add them to static List<String> xpaths
	 * set removeDup=true to remove duplicate element xpaths, set it to false to keep duplicates
	 * /repair_procedure/metadata[1]
	 */
	public static void collectAllElementXpath(Node node, String parentXpath,String fileName,
			boolean removeDup) throws Exception {
		String xpath;
		if (node.getNodeType() == Node.DOCUMENT_NODE) {
			Element rootEle = ((Document) node).getDocumentElement();
			xpath = "/";
			collectAllElementXpath(rootEle, xpath, fileName, removeDup);
		} else if (node.getNodeType() == Node.ELEMENT_NODE) {
			xpath = parentXpath + "/" + node.getNodeName();
			if (removeDup) {
				/*if (!xpaths.contains(xpath)) {
					xpaths.add(node.getNodeName() + "," + xpath + "," + fileName);
				}*/
				boolean exists = true;
				for(String s:xpaths){
					//testtitle,//repair_procedure/subpara/testgroup/testtitle,RM00000184103VX.xml
					String xp = s.substring(s.indexOf("\t")+1, s.lastIndexOf("\t"));
					//System.out.println("xp=" + xp);
					if(xp.equalsIgnoreCase(xpath))
						exists = false;
				}
				if(exists)
					xpaths.add(node.getNodeName() + "\t" + xpath + "\t" + fileName);
			} else {
				xpaths.add(xpath);
			}
			NodeList children = node.getChildNodes();
			for (int i = 0; i < children.getLength(); i++) {
				collectAllElementXpath(children.item(i), xpath, fileName, removeDup);
			}
		}
	}

		
	/**
	 * collect all elements names in a given folder
	 * set removeDup=true to remove duplicate element names, set it to false to keep duplicates
	 */
	public static List<String> collectAllElementNames(String srcDir,
			boolean removeDup) throws Exception {
		List<String> result = new ArrayList<String>();
		List<String> files = FileUtil.getAllFilesWithCertainExt(srcDir, "xml");
		System.out.println("Collecting all element names from " + files.size() + " files in folder "+ srcDir);
		int count = 0;
		for (String file : files) {
			if(++count % 100 == 0) System.out.print(count+" ");
			//System.out.println(file);
			//skip toc.xml file
			if(file.equals("toc.xml")) continue;
			Document doc = parseFile(srcDir + file);
			NodeList lst = doc.getElementsByTagName("*");
			for (int i = 0; i < lst.getLength(); i++) {
				String name = lst.item(i).getNodeName();
				if (removeDup) {
					if(!result.contains(name)){
						result.add(name);
					}
				} else {
					result.add(name);
				}
			}
		}
		System.out.println("\n" + result.size() + " element names collected");
		return result;
	}
		
			
	/**
	 * 
	 * collect all file names and the <eleName> ids in the following format, append to idList
	 * note that duplicates need to be kept.
	 * 
	 * id1,fileName,eleName,idName
	 * id2,fileName,eleName,idName
	 */
		public static void collectAllId(List<String> idList, String fileName, Node node, String eleName, String idName) {
			if (node.getNodeType() == Node.DOCUMENT_NODE) {
				collectAllId(idList, fileName, ((Document) node).getDocumentElement(), eleName, idName);
			}
			else if (node.getNodeType() == Node.ELEMENT_NODE) {
				NodeList lst = ((Element) node).getElementsByTagName(eleName);
				for (int i = 0; i < lst.getLength(); i++) {
					Element infoObjEle = (Element) lst.item(i);
					idList.add(infoObjEle.getAttribute(idName) + "," + fileName + "," + eleName + "," + idName);
				}
			}
		}
	
		
		/**
		 * For <info-obj> wrapper, if it only has one or two <table> or <list> elements, 
		 * move its content out and remove the <info-obj> if it is not referenced (internally and externally)
		 */
		public static int toRemoveEmptyInfoObjWrapper(Node node, List<String> refIDs) throws Exception {
			sharedCount = 0;
			List<String> tags = new ArrayList<String>();
			tags.add("table");
			tags.add("_comment");
			tags.add("list");
			tags.add("figure");
			tags.add("para");
			removeEmptyInfoObjWrapper(node, tags, refIDs);
			return sharedCount;
		}

		private static void removeEmptyInfoObjWrapper(Node node, List<String> tags, List<String> refIDs) throws Exception {
			if (node.getNodeType() == Node.DOCUMENT_NODE) {
				removeEmptyInfoObjWrapper(((Document) node).getDocumentElement(), tags, refIDs);
			}
			// must be <som1>
			else if (node.getNodeType() == Node.ELEMENT_NODE) {
				NodeList lst = ((Element) node).getElementsByTagName("info-obj");
				List<Node> removeList = new ArrayList<Node>();
				for (int i = 0; i < lst.getLength(); i++) {
					Element infoObjEle = (Element) lst.item(i);
					List<Element> children = getDirectChildElementsByTagName(infoObjEle, null);
					//let's only remove <info-obj> with less than 5 child elements 
					if(children.size() <= 4){
						boolean toRemove = true;
						//check if all elements are in the removable list
						for(Element e: children){
							if(!tags.contains(e.getNodeName()))
								toRemove = false;
						}
						//check if <info-obj> id is referenced
						if(toRemove==true){
							int occur = idOccurrences(refIDs, infoObjEle.getAttribute("id"));
							//System.out.println("occur="+occur+ "   id="+infoObjEle.getAttribute("id"));
							if(occur > 0)
								toRemove = false;
						}
						if(toRemove==true){
							Node parent = infoObjEle.getParentNode();
							while(infoObjEle.getFirstChild()!=null){
								parent.insertBefore(infoObjEle.getFirstChild(), infoObjEle);	
							}

							/*//Caution!!! insertBefore() remove the element from infoObjEle
							NodeList nl = infoObjEle.getChildNodes();
							for(int j = 0; j<nl.getLength(); j++){
								parent.insertBefore(nl.item(j), infoObjEle);								
							}*/
							removeList.add(infoObjEle);
							sharedCount++;	
						}
						
					}
				}
				for(Node n:removeList){
					if(n!=null && n.getParentNode()!=null){
						//System.out.println("<info-obj> is removed");
						//System.out.println(xmlToString(n));
						n.getParentNode().removeChild(n);
					}
				}
			}
		}
		
	/**
	 * For empty list wrapper, we check if it has any lst-itm, if there is no, remove the list wrapper.
	 */
	public static int toRemoveEmptyListWrapper(Node node) throws Exception {
		sharedCount = 0;
		removeEmptyListWrapper(node);
		return sharedCount;
	}

	private static void removeEmptyListWrapper(Node node) throws Exception {
		if (node.getNodeType() == Node.DOCUMENT_NODE) {
			removeEmptyListWrapper(((Document) node).getDocumentElement());
		}
		// must be <som1>
		else if (node.getNodeType() == Node.ELEMENT_NODE) {
			NodeList lst = ((Element) node).getElementsByTagName("list");
			List<Node> removeList = new ArrayList<Node>();
			for (int i = 0; i < lst.getLength(); i++) {
				Element listEle = (Element) lst.item(i);
				//System.out.println(i+" " + listEle.hashCode());
				List<Element> allChildren = getDirectChildElementsByTagName(
						listEle, null);
				List<Element> children = getDirectChildElementsByTagName(
						listEle, "lst-itm");
				//no child <lst-itm> found, move all its children out and remove this <list>
				if(children.size() == 0 && 
						allChildren.size() <= 5){ //only remove small list, leave big ones for manual processes
					Node parent = listEle.getParentNode();
					while(listEle.getFirstChild() != null){
						//insertBefore() actually removes the first child from listEle
						parent.insertBefore(listEle.getFirstChild(), listEle);
					}
					removeList.add(listEle);
					sharedCount++;
				}
			}
			
			for(Node n:removeList){
				if(n!=null && n.getParentNode()!=null){
					n.getParentNode().removeChild(n);
				}
			}
		}
	}
	
	/**
	 * 
	 * som1 DTD doesn't allow lists exist inside a list we promote the lists
	 * into its previous <lst-itm> if it is applicable.
	 * 
	 * @throws Exception
	 */
	public static int toFixListsInsideList(Node node) throws Exception {
		sharedCount = 0;
		fixListsInsideList(node);
		return sharedCount;
	}

	private static void fixListsInsideList(Node node) throws Exception {
		if (node.getNodeType() == Node.DOCUMENT_NODE) {
			fixListsInsideList(((Document) node).getDocumentElement());
		}
		// must be <som1>
		else if (node.getNodeType() == Node.ELEMENT_NODE) {
			NodeList lst = ((Element) node).getElementsByTagName("list");
			for (int i = 0; i < lst.getLength(); i++) {
				Element listEle = (Element) lst.item(i);
				List<Element> children = getDirectChildElementsByTagName(
						listEle, "list");
				for (Element childListEle : children) {
					if (childListEle.getPreviousSibling() != null && 
							childListEle.getPreviousSibling().getNodeName() == "lst-itm") {
						Element lstItm = (Element) childListEle.getPreviousSibling();
						lstItm.appendChild(childListEle);
						sharedCount++;
					}
				}

			}
		}
	}
	
	/**
	 * 
	 * if a table is missing <title>, copy its parent/grandparent info-obj title
	 * to it
	 * 
	 * @throws Exception
	 */
	public static int toTopyInfoObjTitleToTable(Node node) throws Exception {
		sharedCount = 0;
		copyInfoObjTitleToTable(node);
		return sharedCount;
	}
		
	private static void copyInfoObjTitleToTable(Node node) throws Exception {
		if (node.getNodeType() == Node.DOCUMENT_NODE) {
			copyInfoObjTitleToTable(((Document) node).getDocumentElement());
		}
		// must be <som1>
		else if (node.getNodeType() == Node.ELEMENT_NODE) {
			NodeList lst = ((Element) node).getElementsByTagName("table");
			for (int i = 0; i < lst.getLength(); i++) {
				Element tableEle = (Element) lst.item(i);
				NodeList children = tableEle.getChildNodes();
				
				//to check if this <table> has a <title> child
				boolean hasATitle = false;
				hasATitle:
				for (int ii = 0; ii < children.getLength(); ii++) {
					if (children.item(ii).getNodeName() == "title") {
						hasATitle = true;
						break hasATitle;
					}
				}
				
				//if it has no <title> child
				if(!hasATitle){
					//find its parent or grandparent info-obj's <title>
					Node infoObj ;
					Node parent = tableEle.getParentNode();
					if(parent.getNodeName() == "info-obj"){
						infoObj = parent;
					}
					else if(parent.getParentNode().getNodeName() == "info-obj"){
							infoObj = parent.getParentNode();
					}
					else
						//give up
						infoObj = null;
					
					//get info-obj's <title>
					Element title = null;
					if(infoObj != null){
						if(getDirectChildElementsByTagName(infoObj, "title").size()>0)
							title = getDirectChildElementsByTagName(infoObj, "title").get(0);
					}
					
					if(title != null){
						Node newTitle = title.cloneNode(true);
						tableEle.insertBefore(newTitle, tableEle.getFirstChild());
						sharedCount++;
					}
					
				}
			}
		}
	}
	
	/**
	 * 
	 * delete any text elements which are children of specified elements(such as <lst-itm>)
	 * @throws Exception 
 	 */
		public static int toRemoveOutOfScopeText(Node node, String ...elements) throws Exception {
			sharedCount = 0;
			removeOutOfScopeText(node, elements);
			return sharedCount;
		}
		
		private static void removeOutOfScopeText(Node node, String ...elements) throws Exception {
			if (node.getNodeType() == Node.DOCUMENT_NODE) {
				removeOutOfScopeText(((Document) node).getDocumentElement(), elements);
			}
			//must be <som1>
			else if(node.getNodeType() == Node.ELEMENT_NODE) {
				for(String e: elements){
					NodeList lst =  ((Element)node).getElementsByTagName(e);
					for(int i=0; i<lst.getLength(); i++){
						Element ele = (Element)lst.item(i);
						NodeList children = ele.getChildNodes();
						for(int ii=0; ii<children.getLength(); ii++){
							if(children.item(ii).getNodeType() == Node.TEXT_NODE){
								//System.out.println("---"+children.item(ii).getNodeName()+"----");
								//System.out.println(XMLUtil.xmlToString(children.item(ii)));
								Node n = children.item(ii);
								//no need to remove line break
								if(n.getNodeValue().trim().length() > 0){
									//System.out.println("---"+n.getNodeValue().trim()+"----");
								ele.removeChild(n);
								sharedCount++;
								}
							}
						}
					}
				}
			}
		}
	
/**
 * 
 * for nodes which fall out of <info-obj> scope
 *	for each <info-obj>, move all its child items following its child <info-obj> until 
 *  the open tag of another <info-obj> or its own end tag, move all these items into their above <info-obj> 
 */
	public static int toMoveNodesIntoInfoObj(Node node) {
		moveNodesIntoInfoObjCount = 0;
		moveNodesIntoInfoObj(node);
		//call it twice in case nodes need insert into the child <info-obj> of the <info-obj>
		moveNodesIntoInfoObj(node);
		return moveNodesIntoInfoObjCount;
	}
	
	private static void moveNodesIntoInfoObj(Node node) {
		if (node.getNodeType() == Node.DOCUMENT_NODE) {
			moveNodesIntoInfoObj(((Document) node).getDocumentElement());
		}
		// must be <som1>
		else if (node.getNodeType() == Node.ELEMENT_NODE) {
			NodeList lst = ((Element) node).getElementsByTagName("info-obj");
			for (int i = 0; i < lst.getLength(); i++) {
				Element infoObjEle = (Element) lst.item(i);
				// stop at its next sibling <info-obj> if there is one
				whileLoop:
				while (infoObjEle.getNextSibling() != null
						&& infoObjEle.getNextSibling().getNodeName() != "info-obj") {
					if (infoObjEle.getNextSibling().getNodeType() == Node.COMMENT_NODE
							&& infoObjEle.getNextSibling().getTextContent()
									.contains(".xml")) {
						//it is the next <info-obj>'s head comment,<!--39525.xml-->, don't move it
						break whileLoop;
					} else {
						if (infoObjEle.getNextSibling().getNodeType() == Node.ELEMENT_NODE) {
							moveNodesIntoInfoObjCount++;
						}
						infoObjEle.appendChild(infoObjEle.getNextSibling());
					}

				}
			}
		}
	}
	
	/**
	 * @deprecated
	 * use MEPSUtil.dedupIDs(Node node) instead
	 * 	call dedupIDs() to deduplicate id attribute values for specified elements (such as
	 	info-obj AND <graphic>)
	 	all ids of all specified elements will be unique, no ids will be shared
	 	by any specified elements
	 */
	public static int toDedupIDs(Node node, String... elements) {
		dedupCount = 0;
		ids.clear();
		dedupIDs(node, elements);
		return dedupCount;
	}
	
	/**
	 * @deprecated
	 * use MEPSUtil.dedupIDs(Node node) instead
	 */
	private static void dedupIDs(Node node, String... elements) {
		String attrId = "id";		//id attribute name
		if (node.getNodeType() == Node.DOCUMENT_NODE) {
			dedupIDs(((Document) node).getDocumentElement(), elements);
		} else if (node.getNodeType() == Node.ELEMENT_NODE) {
			Element ele = (Element)node;
			boolean isNeededEle = false;
			for(String s : elements){
				//System.out.println(ele.getNodeName());
				if(ele.getNodeName()==s)
					isNeededEle = true;
			}
			
			if(isNeededEle){
				
				String id = ele.getAttribute(attrId);

				if(ids.contains(id)){
					id = id+"-"+dedupCount++;
					//simply assign this new id to the element even thought this new id could already exist, but it is very unlikely t
					ele.setAttribute(attrId, id);
					//System.out.println("fixed, new id ="+id);					
				}
				ids.add(id);
				//System.out.println("ids.size()="+ids.size());
			}
			NodeList nodeList = ele.getChildNodes();
			for(int i=0; i < nodeList.getLength(); i++){
				dedupIDs(nodeList.item(i), elements);
			}
		}
	}
	
	// & <intxref>
	//insert processBookMarks into empty Elements except <graphic> , <colspec>
	//such as <caption>, to avoid <caption/> in the output xml string
	public static void stuffEmptyElement(Node node) {
		if (node.getNodeType() == Node.ELEMENT_NODE ||
				node.getNodeType() == Node.DOCUMENT_NODE){
			//empty node
			if(node.getFirstChild() == null &&
					node.getNodeName() != "graphic" &&
					node.getNodeName() != "colspec" &&
					node.getNodeName() != "spanspec" &&
					node.getNodeName() != "serv-cat"){
				node.setTextContent(processBookMarks);
				stuffedFixedCount++;
			}
			else{
				NodeList nodeList = node.getChildNodes();
				for(int i=0; i < nodeList.getLength(); i++){
					stuffEmptyElement(nodeList.item(i));
				}
			}
		}
	}
	
	//wrap all <ptxt> in <list> with <para>
	public static int wrap_list_Ptxt(Document doc) {
		int ptxtFixedCount = 0;
		Element item;
		List<Element> ptxtList;
		NodeList itemList = doc.getElementsByTagName("list");
		for(int i=0; i < itemList.getLength(); i++){
			item = (Element)itemList.item(i);
			//only get direct child <ptxt>, getElementsByTagName gives all elements, including grandchild elements, which we don't want
			ptxtList = XMLUtil.getDirectChildElementsByTagName(item, "ptxt");
			for(int j=0; j<ptxtList.size(); j++){
				Element ptxt = ptxtList.get(j);
				Element para = doc.createElement("para");
				//book mark the ptxt we changed
				//ptxt.setTextContent(processBookMarks+ptxt.getTextContent());
				Node newPtxt = ptxt.cloneNode(true); 
				para.appendChild(newPtxt);
				item.replaceChild(para,ptxt);
				ptxtFixedCount++;
			}
		}
		return ptxtFixedCount;
	}
	
	//bring <chart>  in a list into its above <lst-itm>
	public static int insertChartInItmList(Document doc) {
		int chartFixedCount = 0;
		Element item;
		List<Element> chartList;
		NodeList itemList = doc.getElementsByTagName("list");
		for(int i=0; i < itemList.getLength(); i++){
			item = (Element)itemList.item(i);
			chartList = XMLUtil.getDirectChildElementsByTagName(item, "chart");
			for(int j=0; j<chartList.size(); j++){
				Element chart = chartList.get(j);
				if(chart.getPreviousSibling()!=null && chart.getPreviousSibling().getNodeName() == "lst-itm"){
					chart.getPreviousSibling().appendChild(chart);
					chartFixedCount++;
				}
			}
		}
		return chartFixedCount;
	}
	
	
	// if <lst-itm>'s first child is a <para> element, move <para> content to <lst-itm>, remove the <para>
	public static int turnPara2PtxtinLstItm(Document doc) {
		int paraFixedCount = 0;
		Element item;
		List<Element> children;
		NodeList itemList = doc.getElementsByTagName("lst-itm");
		for (int i = 0; i < itemList.getLength(); i++) {
			item = (Element) itemList.item(i);
			// get all direct children
			children = XMLUtil.getDirectChildElementsByTagName(item, null);
			//if the first child is para 
			if (children.size() >= 1 && children.get(0).getNodeName() == "para") {
				Node para = children.get(0);
				while(para.getFirstChild()!=null){
					item.insertBefore(para.getFirstChild(), para);
				}
				item.removeChild(para);
				paraFixedCount++;
			}
		}
		return paraFixedCount;
	}
	
	//wrap non first <ptxt> in lst-itm with <para>
	public static int wrap_listItem_Ptxt(Document doc) {
		int ptxtFixedCount = 0;
		Element item;
		List<Element> ptxtList;
		NodeList itemList = doc.getElementsByTagName("lst-itm");
		for(int i=0; i < itemList.getLength(); i++){
			item = (Element)itemList.item(i);
			//only get direct child <ptxt>, getElementsByTagName gives all elements, including grandchild elements, which we don't want
			ptxtList = XMLUtil.getDirectChildElementsByTagName(item, "ptxt");
			//start from the second <ptxt>
			for(int j=1; j<ptxtList.size(); j++){
				Element ptxt = ptxtList.get(j);
				Element para = doc.createElement("para");
				//book mark the ptxt we changed
				//ptxt.setTextContent(processBookMarks+ptxt.getTextContent());
				Node newPtxt = ptxt.cloneNode(true); 
				para.appendChild(newPtxt);
				item.replaceChild(para,ptxt);
				ptxtFixedCount++;
			}
		}
		return ptxtFixedCount;
	}


	/** Prints the specified node, then prints all of its children. */
	public static void printDOM(Node node) {
		int type = node.getNodeType();
		switch (type) {
		// print the document element
		case Node.DOCUMENT_NODE: {
			System.out.println("&lt;?xml version=\"1.0\" ?>");
			printDOM(((Document) node).getDocumentElement());
			break;
		}

			// print element with attributes
		case Node.ELEMENT_NODE: {
			System.out.print("&lt;");
			System.out.print(node.getNodeName());
			NamedNodeMap attrs = node.getAttributes();
			for (int i = 0; i < attrs.getLength(); i++) {
				Node attr = attrs.item(i);
				System.out.print(" " + attr.getNodeName().trim() + "=\""
						+ attr.getNodeValue().trim() + "\"");
			}
			System.out.println(">");

			NodeList children = node.getChildNodes();
			if (children != null) {
				int len = children.getLength();
				for (int i = 0; i < len; i++)
					printDOM(children.item(i));
			}

			break;
		}

			// handle entity reference nodes
		case Node.ENTITY_REFERENCE_NODE: {
			System.out.print("&");
			System.out.print(node.getNodeName().trim());
			System.out.print(";");
			break;
		}

			// print cdata sections
		case Node.CDATA_SECTION_NODE: {
			System.out.print("<![CDATA[");
			System.out.print(node.getNodeValue().trim());
			System.out.print("]]>");
			break;
		}

			// print text
		case Node.TEXT_NODE: {
			System.out.print(node.getNodeValue().trim());
			break;
		}

			// print processing instruction
		case Node.PROCESSING_INSTRUCTION_NODE: {
			System.out.print("<?");
			System.out.print(node.getNodeName().trim());
			String data = node.getNodeValue().trim();
			{
				System.out.print(" ");
				System.out.print(data);
			}
			System.out.print("?>");
			break;
		}
		}

		if (type == Node.ELEMENT_NODE) {
			System.out.println();
			System.out.print("</");
			System.out.print(node.getNodeName().trim());
			System.out.print('>');
		}
	}



	/**
	 * This method writes a DOM document to a file
	 * 
	 * @param filename
	 * @param node
	 */
	public static void writeXmlToFile(String filename, Node node) throws Exception {
		try {
			// Prepare the DOM document for writing
			Source source = new DOMSource(node);

			// Prepare the output file
			File file = new File(filename);
			Result result = new StreamResult(file);

			// Write the DOM document to the file
			// Get Transformer
			Transformer xformer = TransformerFactory.newInstance()
					.newTransformer();
			// Write to a file
			xformer.transform(source, result);
		} catch (TransformerConfigurationException e) {
			System.out.println("TransformerConfigurationException: " + e);
			throw e;
		} catch (TransformerException e) {
			System.out.println("TransformerException: " + e);
			throw e;
		}
	}
	


	/**
	 * Count Elements in Document by Tag Name
	 * 
	 * @param tag
	 * @param document
	 * @return number elements by Tag Name
	 */
	public static int countByTagName(String tag, Document document) {
		NodeList list = document.getElementsByTagName(tag);
		return list.getLength();
	}
	
	public static boolean checkElementTypeByComment(Element ele, String comm){
		if(ele.getFirstChild().getNodeType()!=Node.COMMENT_NODE)
			return false;
		if(ele.getFirstChild().getNodeValue()==null ||
				!ele.getFirstChild().getNodeValue().equalsIgnoreCase(comm))
			return false;
		return true;
	}
	
	//return all direct child element with give tag name, return all child elements if tagName is null
	public static List<Element> getDirectChildElementsByTagName(Node node, String tagName){
		List<Element> result = new ArrayList<Element>();
		Node child;
		String tag = tagName;
		NodeList childList = node.getChildNodes();
		for(int i=0; i<childList.getLength(); i++){
			child = childList.item(i);
			if(tagName==null)
				tag = child.getNodeName();
			if(child.getNodeType() == Node.ELEMENT_NODE && child.getNodeName().equalsIgnoreCase(tag)){
				result.add((Element)child);
			}
		}
		return result;
	}
	
	public static String nodeType(short type) {
		    switch(type) {
		      case org.w3c.dom.Node.ELEMENT_NODE:                return "Element";
		      case org.w3c.dom.Node.DOCUMENT_TYPE_NODE:          return "Document type";
		      case org.w3c.dom.Node.ENTITY_NODE:                 return "Entity";
		      case org.w3c.dom.Node.ENTITY_REFERENCE_NODE:       return "Entity reference";
		      case org.w3c.dom.Node.NOTATION_NODE:               return "Notation";
		      case org.w3c.dom.Node.TEXT_NODE:                   return "Text";
		      case org.w3c.dom.Node.COMMENT_NODE:                return "Comment";
		      case org.w3c.dom.Node.CDATA_SECTION_NODE:          return "CDATA Section";
		      case org.w3c.dom.Node.ATTRIBUTE_NODE:              return "Attribute";
		      case org.w3c.dom.Node.PROCESSING_INSTRUCTION_NODE: return "Attribute";
		    }
		    return "Unidentified";
		  }

	public static String xmlToStringPretty(Node node) throws Exception{
        try {
            Source source = new DOMSource(node);
            StringWriter stringWriter = new StringWriter();
            Result result = new StreamResult(stringWriter);
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
    		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
    		transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            
            transformer.setOutputProperty(OutputKeys.METHOD, "xml"); // make sure Transformer does not add an invalid tag.
        	//transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes"); //this will break xmlToArticle method
            transformer.transform(source, result);
            return stringWriter.getBuffer().toString();
        } catch (TransformerConfigurationException e) {
            e.printStackTrace();
            throw e;
        } catch (TransformerException e) {
            e.printStackTrace();
            throw e;
        }
	}
	
    public static String xmlToString(Node node) throws Exception {
        try {
            Source source = new DOMSource(node);
            StringWriter stringWriter = new StringWriter();
            Result result = new StreamResult(stringWriter);
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            
            transformer.setOutputProperty(OutputKeys.METHOD, "xml"); // make sure Transformer does not add an invalid tag.
        	//transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes"); //this will break xmlToArticle method
        	
        	
            transformer.transform(source, result);
            return stringWriter.getBuffer().toString();
        } catch (TransformerConfigurationException e) {
            e.printStackTrace();
            throw e;
        } catch (TransformerException e) {
            e.printStackTrace();
            throw e;
        }
        //return null;
    }
    
    public static String xmlToStringNoHeader(Node node) throws Exception {
    	if(node==null) 
    		return "EMPTY NODE";
        try {
            Source source = new DOMSource(node);
            StringWriter stringWriter = new StringWriter();
            Result result = new StreamResult(stringWriter);
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.transform(source, result);
            return stringWriter.getBuffer().toString().replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>","");
        } catch (TransformerConfigurationException e) {
            e.printStackTrace();
            throw e;
        } catch (TransformerException e) {
            e.printStackTrace();
            throw e;
        }
        //return null;
    }
    
   
    
	public static String removeAttribute(String str, String att) {
		// Create a pattern to match cat
		String content = str;
		String regExp = "id=\"[^\"]*\"";
		Pattern p = Pattern.compile(regExp);
		// Create a matcher with an input string
		Matcher m = p.matcher(content);
		StringBuffer sb = new StringBuffer();
		boolean result = m.find();
		// Loop through and create a new String
		// with the replacements
		while (result) {
			m.appendReplacement(sb, "");
			result = m.find();
		}
		// Add the last segment of input to
		// the new String
		m.appendTail(sb);
		content = sb.toString();
		// System.out.println(sb.toString());
		return content;
	}
    
	/*public static void compareNodes(Node expected, Node actual) throws Exception {
        if (expected.getNodeType() != actual.getNodeType()) {
          throw new Exception("Different types of nodes: " + expected + " " + actual);
        }
        if (expected instanceof Document) {
          Document expectedDoc = (Document) expected;
          Document actualDoc = (Document) actual;
          compareNodes(expectedDoc.getDocumentElement(), actualDoc.getDocumentElement());
        } else if (expected instanceof Element) {
          Element expectedElement = (Element) expected;
          Element actualElement = (Element) actual;

          // compare element names
          if (!expectedElement.getLocalName().equals(actualElement.getLocalName())) {
            throw new Exception("Element names do not match: " + expectedElement.getLocalName() + " "
                + actualElement.getLocalName());
          }
          // compare element ns
          String expectedNS = expectedElement.getNamespaceURI();
          String actualNS = actualElement.getNamespaceURI();
          if ((expectedNS == null && actualNS != null)
              || (expectedNS != null && !expectedNS.equals(actualNS))) {
            throw new Exception("Element namespaces names do not match: " + expectedNS + " " + actualNS);
          }

          String elementName = "{" + expectedElement.getNamespaceURI() + "}"
              + actualElement.getLocalName();

          // compare attributes
          NamedNodeMap expectedAttrs = expectedElement.getAttributes();
          NamedNodeMap actualAttrs = actualElement.getAttributes();
          if (countNonNamespaceAttribures(expectedAttrs) != countNonNamespaceAttribures(actualAttrs)) {
            throw new Exception(elementName + ": Number of attributes do not match up: "
                + countNonNamespaceAttribures(expectedAttrs) + " "
                + countNonNamespaceAttribures(actualAttrs));
          }
          for (int i = 0; i < expectedAttrs.getLength(); i++) {
            Attr expectedAttr = (Attr) expectedAttrs.item(i);
            if (expectedAttr.getName().startsWith("xmlns")) {
              continue;
            }
            Attr actualAttr = null;
            if (expectedAttr.getNamespaceURI() == null) {
              actualAttr = (Attr) actualAttrs.getNamedItem(expectedAttr.getName());
            } else {
              actualAttr = (Attr) actualAttrs.getNamedItemNS(expectedAttr.getNamespaceURI(),
                  expectedAttr.getLocalName());
            }
            if (actualAttr == null) {
              throw new Exception(elementName + ": No attribute found:" + expectedAttr);
            }
            if (!expectedAttr.getValue().equals(actualAttr.getValue())) {
              throw new Exception(elementName + ": Attribute values do not match: "
                  + expectedAttr.getValue() + " " + actualAttr.getValue());
            }
          }

          // compare children
          NodeList expectedChildren = expectedElement.getChildNodes();
          NodeList actualChildren = actualElement.getChildNodes();
          if (expectedChildren.getLength() != actualChildren.getLength()) {
            throw new Exception(elementName + ": Number of children do not match up: "
                + expectedChildren.getLength() + " " + actualChildren.getLength());
          }
          for (int i = 0; i < expectedChildren.getLength(); i++) {
            Node expectedChild = expectedChildren.item(i);
            Node actualChild = actualChildren.item(i);
            compareNodes(expectedChild, actualChild);
          }
        } else if (expected instanceof Text) {
          String expectedData = ((Text) expected).getData().trim();
          String actualData = ((Text) actual).getData().trim();

          if (!expectedData.equals(actualData)) {
            throw new Exception("Text does not match: " + expectedData + " " + actualData);
          }
        }
      }*/
	
    public static void compareNodes(Node expected, Node actual) throws Exception {
        if (expected.getNodeType() != actual.getNodeType()) {
          throw new Exception("Different types of nodes: " + expected + " " + actual);
        }
        if (expected instanceof Document) {
          Document expectedDoc = (Document) expected;
          Document actualDoc = (Document) actual;
          compareNodes(expectedDoc.getDocumentElement(), actualDoc.getDocumentElement());
        } else if (expected instanceof Element) {
          Element expectedElement = (Element) expected;
          Element actualElement = (Element) actual;

          // compare element names
          if (!expectedElement.getNodeName().equals(actualElement.getNodeName())) {
            throw new Exception("Element names do not match: " + expectedElement.getLocalName() + " "
                + actualElement.getLocalName());
          }
          // compare element ns
          String expectedNS = expectedElement.getNamespaceURI();
          String actualNS = actualElement.getNamespaceURI();
          if ((expectedNS == null && actualNS != null)
              || (expectedNS != null && !expectedNS.equals(actualNS))) {
            throw new Exception("Element namespaces names do not match: " + expectedNS + " " + actualNS);
          }

          String elementName = "{" + expectedElement.getNamespaceURI() + "}"
              + actualElement.getLocalName();

          // compare attributes
          NamedNodeMap expectedAttrs = expectedElement.getAttributes();
          NamedNodeMap actualAttrs = actualElement.getAttributes();
          if (countNonNamespaceAttribures(expectedAttrs) != countNonNamespaceAttribures(actualAttrs)) {
            throw new Exception(elementName + ": Number of attributes do not match up: "
                + countNonNamespaceAttribures(expectedAttrs) + " "
                + countNonNamespaceAttribures(actualAttrs));
          }
          for (int i = 0; i < expectedAttrs.getLength(); i++) {
            Attr expectedAttr = (Attr) expectedAttrs.item(i);
            if (expectedAttr.getName().startsWith("xmlns")) {
              continue;
            }
            Attr actualAttr = null;
            if (expectedAttr.getNamespaceURI() == null) {
              actualAttr = (Attr) actualAttrs.getNamedItem(expectedAttr.getName());
            } else {
              actualAttr = (Attr) actualAttrs.getNamedItemNS(expectedAttr.getNamespaceURI(),
                  expectedAttr.getLocalName());
            }
            if (actualAttr == null) {
              throw new Exception(elementName + ": No attribute found:" + expectedAttr);
            }
            if (!expectedAttr.getValue().equals(actualAttr.getValue())) {
              throw new Exception(elementName + ": Attribute values do not match: "
                  + expectedAttr.getValue() + " " + actualAttr.getValue());
            }
          }

          // compare children
          NodeList expectedChildren = expectedElement.getChildNodes();
          NodeList actualChildren = actualElement.getChildNodes();
          if (expectedChildren.getLength() != actualChildren.getLength()) {
            throw new Exception(elementName + ": Number of children do not match up: "
                + expectedChildren.getLength() + " " + actualChildren.getLength());
          }
          for (int i = 0; i < expectedChildren.getLength(); i++) {
            Node expectedChild = expectedChildren.item(i);
            Node actualChild = actualChildren.item(i);
            compareNodes(expectedChild, actualChild);
          }
        } else if (expected instanceof Text) {
          String expectedData = ((Text) expected).getData().trim();
          String actualData = ((Text) actual).getData().trim();

          if (!expectedData.equals(actualData)) {
            throw new Exception("Text does not match: " + expectedData + " " + actualData);
          }
        }
      }
    
    public static int countNonNamespaceAttribures(NamedNodeMap attrs) {
        int n = 0;
        for (int i = 0; i < attrs.getLength(); i++) {
          Attr attr = (Attr) attrs.item(i);
          if (!attr.getName().startsWith("xmlns")) {
            n++;
          }
        }
        return n;
      }
}
