package util;

public enum EnumSolveRefers {
	FILE, 
	NODE_NAME, 
	TITLE, 
	NEW_ID, 
	PARENT_INFO_OBJ_ID, 
	PARENT_INFO_OBJ_TITLE, 
	GRAPHICNAME, OENAME, 
	CAPTION, 
	TABLE_GRAPHIC 
}
