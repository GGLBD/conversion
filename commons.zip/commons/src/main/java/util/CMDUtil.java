package util; 

import java.io.*;
import java.lang.Runtime;
import java.util.*;

public class CMDUtil {

	public static void main(String args[]) throws Exception{
		
		callCMD("dir /b /s N:\\Automation\\Toyota\\In\\09GX470_RM10P0U_EN_10-01-26_UB\\*.eps");
		
	}
	
	/*
	 * callExe("dir /b /s N:\\Automation\\Toyota\\In\\09GX470_RM10P0U_EN_10-01-26_UB\\*.eps");
	 */
	public static List<String> compairFilesBase_Binary(String file1, String file2) throws Exception {
		List<String> lst = new ArrayList<String>();
		Runtime r = Runtime.getRuntime();
		Process p = null;
		String command =  "FC /b "+file1+" "+file2 ;
			// p = r.exec(new String[]{"cmd","/c","start C:/temp/DR.bat"});
		//System.out.println("executing command - " + command);
			p = r.exec(new String[] { "cmd", "/c", command });
			BufferedReader input = new BufferedReader(new InputStreamReader(
					p.getInputStream()));

			String line = null;
			while ((line = input.readLine()) != null) {
				lst.add(line);
				//System.out.println(line);
			}
			// Method waitFor() will make the current thread to wait until the
			// external program finish and return the exit value to the waited
			// thread.
			int status = p.waitFor();
			//if(status != 0)	throw new Exception("Exit Value = " + status);
			//System.out.println("Exit Value = " + status);
			//for(String s:lst) System.out.println(s);
		return lst;
	}
	
	/*
	 * callExe("dir /b /s N:\\Automation\\Toyota\\In\\09GX470_RM10P0U_EN_10-01-26_UB\\*.eps");
	 */
	public static List<String> callCMD(String command) throws Exception {
		List<String> lst = new ArrayList<String>();
		Runtime r = Runtime.getRuntime();
		Process p = null;
			// p = r.exec(new String[]{"cmd","/c","start C:/temp/DR.bat"});
		//System.out.println("executing command " + command);
			p = r.exec(new String[] { "cmd", "/c", command });
			BufferedReader input = new BufferedReader(new InputStreamReader(
					p.getInputStream()));

			String line = null;
			while ((line = input.readLine()) != null) {
				lst.add(line);
				//System.out.println(line);
			}
			// Method waitFor() will make the current thread to wait until the
			// external program finish and return the exit value to the waited
			// thread.
			int status = p.waitFor();
			if(status != 0)	throw new Exception("Exit Value = " + status);
			//System.out.println("Exit Value = " + status);
			//for(String s:lst) System.out.println(s);
		return lst;
	}
	
	/*
	 * to check if two files are identical using Beyond Compare
	 * "C:\Program Files (x86)\Beyond Compare 2\BC2.exe" @%Scrpdir%\ConvertFrags\CompareScript.txt %Workdir%\NewSvg %Workdir%\OldSvg %Workdir%\SVG_NeedConversion %Workdir%\CompareLog.txt /silent
	 */
	/*public static boolean isFilesIdentical(String file1, String file2) throws Exception {
		List<String> lst = new ArrayList<String>();
		Runtime r = Runtime.getRuntime();
		Process p = null;
		System.out.println("comparing file " + file1 + " with file " + file2 );
		String command = "c:\\Program Files (x86)\\Beyond Compare 2\\BC.exe " + file1 + " " + file2 +  " /slient";
		System.out.println("comparing file " +command);
			p = r.exec(new String[] { "cmd", "/c", command });
			BufferedReader input = new BufferedReader(new InputStreamReader(
					p.getInputStream()));

			String line = null;

			while ((line = input.readLine()) != null) {
				lst.add(line);
				//System.out.println(line);
			}
			// Method waitFor() will make the current thread to wait until the
			// external program finish and return the exit value to the waited
			// thread.
			int status = p.waitFor();
			if(status != 0)
				throw new Exception("Exit Value = " + status);
			System.out.println("Exit Value = " + status);
			//for(String s:lst) System.out.println(s);
		return false;
	}*/

}
