package util;

import org.w3c.dom.Document;

/**
 * This is for classes which need implement XML fragment reuse
 * XML fragment reuse is achieved by retrieving proofed XML fragments (<info-obj> in MEPS), then inject them into new articles  
 *
 */
public interface IXMLFragReuse {
	

}
