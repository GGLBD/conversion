package util;

import org.xml.sax.SAXException;

public class MySAXTerminatorException extends SAXException {
	public MySAXTerminatorException(String msg){
		super(msg);
	}
	
	/*
	public String getMessage(){
		return "";
	}
	
	public StackTraceElement[] getStackTrace(){
		return null;
	}
	
	public String getLocalizedMessage(){
		return "";
	}*/
	
}
