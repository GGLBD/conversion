package util;
import static util.XMLUtil.*;

import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Base {
	
	final static String errorStr = "eRROR:";
	
	public static final String DEFAULT_LOG_FILE = "c:\\Temp\\log.txt";
	
	public static String logFile = DEFAULT_LOG_FILE;

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub

	}
	
	public static void p(String str){
		System.out.print(str);
		if(logFile != null){
			
		}
	}
	
	public static void pl(String str){
		System.out.println(str);
	}
	
	public static void e(String str){
		System.err.print(errorStr + str);
	}
	
	public static void el(String str){
		System.err.println(errorStr + str);
	}
	
	private static void log(String str) throws Exception{
		Logger logger = Logger.getLogger("");
	    //logger.setLevel(Level.INFO);//Loget Info, Warning dhe Severe do ruhen
		FileHandler fh = new FileHandler(logFile);
		SimpleFormatter formatter = new SimpleFormatter();  
        fh.setFormatter(formatter);
	    logger.addHandler(fh);
	}


}
