
package util;

import java.io.*; 
import java.util.*; 
import java.util.zip.*; 

import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

 
public class Unzip  {  
 
	public static final String zipWorkspace = "zipWorkSpace";
	public static String zipFile = "..\\data\\gm.zip";
	
	private static final Logger logger = LoggerFactory.getLogger(Unzip.class);
	
  public static final void copyInputStream ( InputStream in, OutputStream out )  
  throws IOException 
   {  
    byte [  ]  buffer = new byte [ 1024 ] ; 
    int len; 
    while (  ( len = in.read ( buffer )  )   >= 0 )  
      out.write ( buffer, 0, len ) ; 
    in.close (  ) ; 
    out.close (  ) ; 
   }  
 
  public static final void main ( String [  ]  args ) throws Exception   {  
	  unzip("N:\\Automation\\Temp\\SavvionBPM\\", "");
	  //unzip("..\\data\\20101105campaigns.zip");
	  
   }  
  
  /**
   * unzip all zips in the rootDir into rootDir/unzipped/ folder
   */
  public static void unzip(String rootDir, String destDir) throws Exception{
		List<String> fileList = FileUtil.getAllFilesWithCertainExt(rootDir, "zip");
		for(String fileName: fileList){
			unzip(rootDir, destDir, fileName, true);	
		}
  }

  
  /**
   * unzip a zip file into dest folder, set fileExt as empty string to unzip all
   */
	public static void unzipFile(String zip, String destDir, String fileExt, boolean overwrite)
			throws Exception {
		String realFileExt = fileExt;
		if(fileExt == null){
			realFileExt = "";
		}
		Enumeration entries;
		ZipFile zipFile;
		// try {
		// zipFile = new ZipFile ( "..\\data\\20101105campaigns.zip") ;
		zipFile = new ZipFile(zip);

		entries = zipFile.entries();
		
		int count = 0;

		while (entries.hasMoreElements()) {
			ZipEntry entry = (ZipEntry) entries.nextElement();
			
			if (entry.isDirectory()) {
				// Assume directories are stored parents first then children.
				System.err.println("Extracting directory: " + entry.getName());
				// This is not robust, just for demonstration purposes.
				(new File(destDir + entry.getName())).mkdirs();
				continue;
			}

			if (entry.getName().toLowerCase().endsWith(realFileExt.toLowerCase())) {
				if(!overwrite){
					if(new File(destDir + entry.getName()).exists()){
						System.out.println("existing file skipped: " + entry.getName());
						continue;
					}
				}
				System.out.println("Extracting file: " + entry.getName());
				String dir = destDir + new File(entry.getName()).getParent();
				if(!new File(dir).exists()){
					new File(dir).mkdirs();
				}
				
				copyInputStream(zipFile.getInputStream(entry),
						new BufferedOutputStream(new FileOutputStream(destDir
								+ entry.getName())));
			}
			
		}
		zipFile.close();
	}
	
	final static int BUFFER = 2048;
	
	public static void unZipTarGZFile(String tarGZFile, String destDir) throws IOException {
		 
		  /** create a TarArchiveInputStream object. **/
		 
		  FileInputStream fin = new FileInputStream(tarGZFile);
		  BufferedInputStream in = new BufferedInputStream(fin);
		  GzipCompressorInputStream gzIn = new GzipCompressorInputStream(in);
		  TarArchiveInputStream tarIn = new TarArchiveInputStream(gzIn);
		 
		  TarArchiveEntry entry = null;
		 
		  /** Read the tar entries using the getNextEntry method **/
		 
		  while ((entry = (TarArchiveEntry) tarIn.getNextEntry()) != null) {
		 
		   System.out.println("Extracting: " + entry.getName());
		 
		   /** If the entry is a directory, create the directory. **/
		 
		   if (entry.isDirectory()) {
		 
		    File f = new File(destDir + entry.getName());
		    f.mkdirs();
		   }
		   /**
		    * If the entry is a file,write the decompressed file to the disk
		    * and close destination stream.
		    **/
		   else {
		    int count;
		    byte data[] = new byte[BUFFER];
		 
		    FileOutputStream fos = new FileOutputStream(destDir  + entry.getName());
		    BufferedOutputStream dest = new BufferedOutputStream(fos,
		      BUFFER);
		    while ((count = tarIn.read(data, 0, BUFFER)) != -1) {
		     dest.write(data, 0, count);
		    }
		    dest.close();
		   }
		  }
		 
		  /** Close the input stream **/
		 
		  tarIn.close();
		  System.out.println("untar completed successfully!!");
	}
	
  /**
   * unzip a zip file into dest folder
   */
  public static void unzipFile ( String zip, String destDir, boolean overwrite ) throws Exception   {  
	  unzipFile(zip, destDir, "", overwrite);
  }  
  
  /**
   * unzip zipFile in rootDir folder into dest folder
   */
  public static void unzip ( String rootDir, String zip, String destDir, boolean overwrite ) throws Exception   {  
	    unzipFile(rootDir+zip, destDir, overwrite);
	   }   
  
	// List all file names in a given zip, input "" as extension to retrive all file names
	public static List<String> getFileNames(String rootDir, String zip, String extension)
			throws Exception {
		return getFileNames(rootDir+zip, extension);
	}
	
	// List all file names in a given zip, input "" as extension to retrive all file names
	public static List<String> getFileNames(String zip, String extension)
			throws Exception {
		logger.info("Unzipping file:{}",  zip);
		List<String> lst = new ArrayList<String>();
		String str = zip+ "\n";
		Enumeration entries;
		ZipFile zipFile;
		// zipFile = new ZipFile ( "..\\data\\20101105campaigns.zip") ;
		zipFile = new ZipFile(zip);
		entries = zipFile.entries();
		while (entries.hasMoreElements()) {
			ZipEntry entry = (ZipEntry) entries.nextElement();
			if (!entry.isDirectory()) {
				if(entry.getName().endsWith(extension)){
					//logger.info("Zip item:{}",   entry.getName());
					str += entry.getName() + "\n";
					if(!lst.contains(entry.getName())){
						lst.add(entry.getName());
					}
				}
			}
		}			zipFile.close();
		//FileUtil.appendWriter("files.txt", str);
		return lst;
	}
 
 
 } 

