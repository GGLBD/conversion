package util;

import java.io.*;

public class GXUtil {

	/**
	 * @param args
	 */
	public static void main(String[] args)  throws Exception{
		eps2Gif("", "");

	}
	
	/**
	 * convert EPS file into GIF file using AbleBatch converter 
	 * @throws Exception 
	 */
	public static void eps2Gif(String eps, String gif) throws Exception{
		String dir = gif.substring(0, gif.lastIndexOf("\\") + 1);
		File getGIFs = new File(dir + "getGIFs.cmd");
		if(!getGIFs.exists()){
			getGIFs.createNewFile();
		}
		String command = "ablebatchconverter.exe /inputfile=\"" + eps + "\" /outputfile=\"" + gif + "\""; 
		FileUtil.appendWriter(dir + "getGIFs.cmd", "\n"+command);
		
		//CMDUtil._callCMD("C:\\\"Program Files (x86)\"\\AbleBatchConverter\\ablebatchconverter.exe /inputfile=\"C:\\temp\\A030137E02-A.eps\" /outputfile=\"C:\\temp\\A030137E02-A.gif\"");
		//CMDUtil.callCMD("C:\\\"Program Files (x86)\"\\AbleBatchConverter\\ablebatchconverter.exe /inputfile=\"C:\\Users\\ss1819\\Desktop\\Public\\A030137E02-A.eps\" /outputfile=\"C:\\Users\\ss1819\\Desktop\\Public\\A030137E02-A.gif\"");
		
		//CMDUtil._callCMD("C:\\\"Program Files (x86)\"\\AbleBatchConverter\\ablebatchconverter.exe");
		//CMDUtil._callCMD("C:\\Users\\ss1819\\Desktop\\tmp\\gx\\tst.cmd");
	}

}
