package util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class AppProperties {
	
	public static void main(String[] args){
		System.out.println("prop.db.url="+ prop.getProperty("db.url"));
	}
	
	public static Properties prop;
	
	static{
		System.out.println("Start uploading application properties");
		try (InputStream input = new FileInputStream("C:/Users/ss1819/Documents/workspace/config.properties")) {

            prop = new Properties();

            // load a properties file
            prop.load(input);

            // get the property value and print it out
            System.out.println("testProperty=" + prop.getProperty("testProperty"));

        } catch (IOException ex) {
            ex.printStackTrace();
        }
	}

}
