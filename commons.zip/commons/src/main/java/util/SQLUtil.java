package util;


/***********************************************************************
 **	Description:	Simple utility class used for reporting SQLExceptions/SQLWarnings
 **			and driver/database metadata.
 ************************************************************************/



import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;




public class SQLUtil {
	private static final Logger logger = LoggerFactory.getLogger(SQLUtil.class);
	/**
	 */
	public static Connection con;
	public static void main(String[] args) throws Exception{
		//
		//connectSQL("jdbc:sqlserver://C-SQL-BI-01\\SANDBOX01:55910;databaseName=Conversion;", "ss1819", "");
		System.exit(0);
		//String[] stmt = {"insert into temp values(2)", "insert into temp values(3)"};
		//String[] stmt = {"update temp set id = 1", "update temp set id = 111"};
		String[] stmt = {"delete temp where id = 1", "delete temp where id = 111"};
		int count = batchDML(con, new ArrayList<String>());
		System.out.println(count + " rows affected");
		con.close();
	}
	
	/**
	 * connect to Oracle database 
	 */
	public static Connection connectORA(String host, int port, String SID, String usr, String pass) throws Exception{
		System.out.println("Connecting to database " + SID);
		Connection con ;
		Class.forName("oracle.jdbc.driver.OracleDriver");
		//String conStr = "jdbc:oracle:thin:@" + host + ":" + port + ":" + SID;
		String conStr = "jdbc:oracle:thin://@" + host + ":" + port + "/" + SID;
		//String conStr = "jdbc:oracle:oci://@eddb-prod";
		System.out.println("connection String = " + conStr);
		con = DriverManager.getConnection(conStr,	usr, pass);
				// Show some database/driver metadata
		printDriverInfo(con);
		System.out.println(SID + " is connected successfully.");
		return con;
	}
	
	/**
	 * connect to SQL Server database 
	 */
	public static Connection connectSQL(String conStr, String usr, String pass) throws Exception{
		System.out.println("Connecting to database " + conStr);
		Connection con ;
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		con = DriverManager.getConnection(conStr,	usr, pass);
		// Show some database/driver metadata
		printDriverInfo(con);
	//con.close();
		System.out.println(conStr + " is connected successfully.");
		return con;
	}
	
	/**
	 * batch DML (insert, update or delete rows), return number of affected rows 
	 * para stmt could be either one of the following statements: 
	 * insert into temp values(2)
	 * update temp set id = 1
	 * delete temp where id = 1
	 */
	public static int batchDML(Connection con, List<String> stmt) throws Exception{
		//int maxStatementsPerBatch = 10000;
		int maxStatementsPerBatch = 1000;
		Statement st = con.createStatement();
		List<String> tempStatements = new ArrayList<>();
		int	rowsAffected = 0;
		for(int i=0; i<stmt.size(); i++){
			st.addBatch(stmt.get(i));	
			tempStatements.add(stmt.get(i));
			if( ((i+1) % maxStatementsPerBatch) == 0  || 
					i== (stmt.size()-1)){
				System.out.println("Execute batch; (i+1)="+ (i+1));
				int[] rc;
				try{
					rc = st.executeBatch();
					for (int j=0; j<rc.length; ++j)
						rowsAffected+=rc[j];
				}
				catch(Exception e){
					e.printStackTrace();
					throw new Exception("error statments:" + tempStatements);
					//logger.info("error statments:" + tempStatements);
				}

				st.clearBatch();
				tempStatements.clear();
			}
		}
		System.out.println(stmt.size() + " statements executed;  " + rowsAffected + " rows affected");
		st.close();
		return rowsAffected;
	}


	static public void displayResultSet(ResultSet rs) throws SQLException {
		int i;

		// Get the ResultSetMetaData. This will be used for the column headings
		ResultSetMetaData rsmd = rs.getMetaData();

		// Get the number of columns in the result set
		int numCols = rsmd.getColumnCount();

		// Display column headings
		for (i = 1; i <= numCols; i++) {
			if (i > 1)
				System.out.print(",");
			System.out.print(rsmd.getColumnLabel(i));
		}
		System.out.println("\n-------------------------------------");

		// Display data, fetching until end of the result set
		while (rs.next()) {
			// Loop through each column, getting the
			// column data and displaying
			for (i = 1; i <= numCols; i++) {
				if (i > 1)
					System.out.print(",");
				System.out.print(rs.getString(i));
			}
			System.out.println("");
			// Fetch the next result set row
		}
	}

	/**
	 * This method checks for warnings and displays the warnings' information.
	 * Note that multiple warning objects could be chained together. Very
	 * similar to printSQLExceptions.
	 * 
	 * @param warn
	 *            The list of SQLWarnings.
	 * @return true if a warning existed, false otherwise.
	 * @exception SQLException.
	 * @see Utils#printSQLExceptions
	 * @exception SQLException.
	 */
	static public boolean printSQLWarnings(SQLWarning warn) throws SQLException {
		boolean rc = false;

		if (warn != null) {
			System.out.println("\n *** Warning ***\n");
			rc = true;
			while (warn != null) {
				System.out.println("SQLState: " + warn.getSQLState());
				System.out.println("Message:  " + warn.getMessage());
				System.out.println("Vendor:   " + warn.getErrorCode());
				System.out.println("");
				warn = warn.getNextWarning();
			}
		}
		return rc;
	}

	/**
	 * This method checks for exceptions and displays error information. Note
	 * that multiple exception objects could be chained together. Very similar
	 * to printSQLWarnings.
	 * 
	 * @param warn
	 *            The list of SQLException.
	 * @return true if an exception existed, false otherwise.
	 * @see Utils#printSQLWarnings
	 */
	static public boolean printSQLExceptions(SQLException ex) {
		boolean rc = false;

		if (ex != null) {
			System.out.println("\n*** SQLException caught ***\n");
			rc = true;
			while (ex != null) {
				System.out.println("SQLState: " + ex.getSQLState());
				System.out.println("Message:  " + ex.getMessage());
				System.out.println("Vendor:   " + ex.getErrorCode());
				System.out.println("");
				ex = ex.getNextException();
			}
		}
		return rc;
	}

	static public boolean printSQLExceptions(String method, SQLException ex) {
		boolean rc = false;

		if (ex != null) {
			System.out.println("\n*** SQLException caught in " + method
					+ " ***\n");
			rc = true;
			while (ex != null) {
				System.out.println("SQLState: " + ex.getSQLState());
				System.out.println("Message:  " + ex.getMessage());
				System.out.println("Vendor:   " + ex.getErrorCode());
				System.out.println("");
				ex = ex.getNextException();
			}
		}
		return rc;
	}

	/**
	 * This method displays driver name and version.
	 * 
	 * @param con
	 *            The current connection.
	 * @return None.
	 * @exception SQLException.
	 */
	static public void printDriverInfo(Connection con) throws SQLException {
		// Get the DatabaseMetaData object and display
		// some information about the connection
		DatabaseMetaData dma = con.getMetaData();

		System.out.println("Database\t" + dma.getDatabaseProductVersion());
		System.out.println("Driver\t\t" + dma.getDriverVersion());
		System.out.println("URL\t\t" + dma.getURL() + ", user '"
				+ dma.getUserName() + "'");
		System.out.println("-------------------------------------");
	}

}
