package util;

import java.io.File;
import java.sql.*;
import java.util.*;

/**
 * A universal service to map/manage between original OE names and generated ids (for both OE storage and applicable MEPS graphic generated_id) 
 */
public class OEMapper extends Base{
	
	public static final String OE_TYPE_XML = "XML";
	public static final String OE_TYPE_SVG = "SVG";
	public static final String OE_TYPE_JPG = "JPG";
	public static final String OE_TYPE_GIF = "GIF";
	public static final String OE_TYPE_TIF = "TIF";
	public static final String OE_TYPE_EPS = "EPS";
	
	
	public static final String CHRYSLER = "Chrysler";
	public static final String VOLVO = "Volvo";
	public static final String GM = "GM";
	public static final String Toyota = "Toyota";
	
	String mfr;
	String lib_dir;

	int count = 0;
	public Connection con;
	
	public static void main(String[] args) throws Exception {
	}
	
	protected void finalize() throws Throwable
	{
		con.close();
	} 
	
	/**
	 * copy a list of OE items from Lib into dest Dir
	 */
	public void getFromLib(Collection<String> oes, String destDir, String oeType) throws Exception{
		Map<String, String> map = new HashMap<String, String>();
		String dir = lib_dir + oeType + "\\";
		map = query(oes, null);

		Iterator<String> it = oes.iterator();
		while(it.hasNext()){
			String oe = it.next();
			String mappedName = map.get(oe);
			String src = dir + Util.getThreeLayerDir(mappedName);

			FileUtil.copyFile(src+oe, destDir+oe);
		}
	}
	
	/**
	 * copy or move a list of OE items into their destination lib dir
	 * existingOEOnly=true will only copy/move existing OEs (already registered in OE_Map table) into lib
	 * existingOEOnly=false will register all new OEs (if there are any) in OE_Map table, then move all of them into lib
	 */
	public void toLib(Collection<String> oeFiles, String oeType, boolean makeNewcopy, boolean existingOEOnly) throws Exception{
		Map<String, String> map = new HashMap<String, String>();
		String dir = lib_dir + oeType + "\\";
		if(!new File(dir).exists()){
			new File(dir).mkdir();
		}
		List<String> oes = new ArrayList<String>();
		Iterator<String> it = oeFiles.iterator();
		while(it.hasNext()){
			String oeFile = it.next();
			String oe = oeFile.substring(oeFile.lastIndexOf("\\")+1);
			oes.add(oe);
		}
		if(existingOEOnly){
			map = query(oes, null);
		}else{
			map = upsert(oes);
		}
		
		//moving
		it = oeFiles.iterator();
		while(it.hasNext()){
			String oeFile = it.next();
			String oe = oeFile.substring(oeFile.lastIndexOf("\\")+1);
			if(map.get(oe)!=null){
				String mappedName = map.get(oe);

				String destDir = dir + Util.getThreeLayerDir(mappedName);
				pl("destDir="+destDir);
				//create destDir if not exist
				File DIR = new File(destDir); 
				if(!DIR.exists()){
					DIR.mkdirs();
				}
				
				String newFile = destDir+oe;
				
				if(makeNewcopy){
					FileUtil.copyFile(oeFile, newFile);
				}else{
					new File(oeFile).renameTo(new File(newFile));
				}
			}else{
				if(!existingOEOnly){
					throw new Exception("oe="+oe+" not upserted into OE_Map table");
				}
			}
		}
	}
	
	/**
	 * query existing oe_name to generated_id mapping
	 * make oes null to return all records of given mfr 
	 * oeType: XML	SVG	JPEG GIF TIF
	 */
	public Map<String, String> query(Collection<String> oes, String oeType) throws Exception{
		System.out.println("Getting original OE names to generated id mapping");
		Map<String, String> map = new HashMap<String, String>();
		String query;
		if(oeType==null){
			query = "SELECT oe_name, entry_id " +
			"FROM [Conversion].[dbo].[OE_Map] a join [Conversion].[dbo].MFR b " +
			"on a.fk_mfr = b.id " +
			"where b.MFR = '" + mfr + "'";
		}else{
			query = "SELECT oe_name, entry_id " +
			"FROM [Conversion].[dbo].[OE_Map] a join [Conversion].[dbo].MFR b " +
			"on a.fk_mfr = b.id " +
			"join [Conversion].[dbo].oe_type c " +
			"on a.oe_type = c.id " +
			"where b.MFR = '" + mfr + "' and c.type='"+oeType+"'";
		}

		if(oes==null){
			
		}else if(oes.size()==0){
			return map;
		}else{
			String oeStr = "";
			Iterator<String> it = oes.iterator();
			while(it.hasNext()){
				String orgid = it.next();
				oeStr += "'" + orgid + "',";
			}
			if(oeStr.endsWith(",")){
				oeStr = oeStr.substring(0, oeStr.lastIndexOf(","));
			}
			query += " and a.oe_name in (" + oeStr + ")";
		}
		//"where b.MFR = '" + mfr + "' and a.oe_name in ()";
		Statement st = con.createStatement();
		int count = 0;
		//pl("OEMapper.query="+query);
		ResultSet rs = st.executeQuery(query);
		while (rs.next()) {
			count++;
			String oe = rs.getString(1);
			String id = rs.getString(2);
			map.put(oe, id);
			pl("oe mapping added oe="+oe+" id="+id);
		}
		pl("OEMapper number of OE mapping found="+count);
		return map;
	}
	
	/**
	 * given a list of OE names, 
	 * 		for existing OE names, return it's generated ids
	 * 		for non-existing oe names, insert them into dbo.OE_Map table, generate new ids for them
	 * 		then return all ids for all oe names (both existing and non-existing) 
	 */
	public Map<String, String> upsert(Collection<String> oes) throws Exception{
		System.out.println("Upserting OE names to OE_Map table");
		Map<String, String> map = new HashMap<String, String>();
		String oeStr = "";			
		String[] results;
		if(oes==null || oes.size()==0){
			return map;
		}else{

			Iterator<String> it = oes.iterator();
			while(it.hasNext()){
				String orgid = it.next();
				oeStr += orgid + ",";
			}
			if(oeStr.endsWith(",")){
				oeStr = oeStr.substring(0, oeStr.lastIndexOf(","));
			}
		}
		
		CallableStatement stmt = con.prepareCall("{ call Conversion.dbo.upsertOEMap(?, ?, ?)}");
	    stmt.setNString(1, oeStr);
	    stmt.setNString(2, mfr);
	    stmt.registerOutParameter(3, java.sql.Types.NCHAR);
	    stmt.execute();
	    results = stmt.getNString(3).split(";");
	    if(oes.size() != results.length){
	    	throw new Exception("number of returned records doesn't match with number of input records; oes.size="+oes.size()+" results.length="+results.length);
	    }
	    for(int i=0; i<results.length; i++){
	    	String oe = results[i].substring(0, results[i].indexOf(","));
	    	String id = results[i].substring(results[i].indexOf(",")+1);
	    	map.put(oe, id);
	    	pl("oe="+oe+" id="+id);
	    }

		pl("OEMapper number of OE mapping found="+results.length);
		return map;
	}

}
