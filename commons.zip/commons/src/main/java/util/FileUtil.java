package util;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.w3c.dom.Document;


public class FileUtil extends Base{

	/**
	 * @param args
	 * @throws Exception 
	 */
	
	private static int count = 0;
	//public static final String MEPS_ARTICLE_WIP_DIR = "\\\\ranger\\data\\MEPS\\Articles\\Wip\\";
	

	public static void main(String[] args) throws Exception {
		
		
		
		String dir = "\\\\ranger\\data\\Conversion\\SGML_WIP\\ss1819\\GM\\2018_GX\\Cheyenne,_Sierra,_Silverado_Service_Manual_(10994838)\\TIF\\";
splitFilesIntoBatchs(dir, 1500);
		
		System.exit(0);

		
		splitFilesIntoBatchs("\\\\ranger\\data\\Conversion\\SGML_WIP\\ss1819\\Toyota\\importMEPS2\\png\\Update\\batch-1\\", 1500);
		splitFilesIntoBatchs("\\\\ranger\\data\\Conversion\\SGML_WIP\\ss1819\\Toyota\\importMEPS2\\png\\Update\\batch-2\\", 1500);
		splitFilesIntoBatchs("\\\\ranger\\data\\Conversion\\SGML_WIP\\ss1819\\Toyota\\importMEPS2\\png\\Update\\batch-3\\", 1500);
		splitFilesIntoBatchs("\\\\ranger\\data\\Conversion\\SGML_WIP\\ss1819\\Toyota\\importMEPS2\\png\\Update\\batch-4\\", 1500);
		splitFilesIntoBatchs("\\\\ranger\\data\\Conversion\\SGML_WIP\\ss1819\\Toyota\\importMEPS2\\png\\Update\\batch-5\\", 1500);
		splitFilesIntoBatchs("\\\\ranger\\data\\Conversion\\SGML_WIP\\ss1819\\Toyota\\importMEPS2\\png\\Update\\batch-6\\", 1500);
		splitFilesIntoBatchs("\\\\ranger\\data\\Conversion\\SGML_WIP\\ss1819\\Toyota\\importMEPS2\\png\\Update\\batch-7\\", 1500);
		splitFilesIntoBatchs("\\\\ranger\\data\\Conversion\\SGML_WIP\\ss1819\\Toyota\\importMEPS2\\png\\Update\\batch-8\\", 1500);
		splitFilesIntoBatchs("\\\\ranger\\data\\Conversion\\SGML_WIP\\ss1819\\Toyota\\importMEPS2\\png\\Update\\batch-9\\", 1500);
		splitFilesIntoBatchs("\\\\ranger\\data\\Conversion\\SGML_WIP\\ss1819\\Toyota\\importMEPS2\\png\\Update\\batch-10\\", 1500);
		
		System.exit(0);
		//splitFilesIntoBatchs("Z:\\Automation\\VW\\input\\AUDI\\PNG\\", 1500);System.exit(0);
		
		System.out.println("End:"+new Date());
		System.exit(0);
		
		List<String> files = getAllFilesWithCertainExt("N:\\Automation\\Toyota\\Rawdata\\", "zip", true);
		Collections.sort(files);
		//Collections.reverse(files);
		for(int i=0; i<files.size(); i++){
			String file = files.get(i).toLowerCase();
			if(file.contains("\\ewd\\")){
				System.out.println(files.get(i));
				FileUtil.copyFile(files.get(i), "N:\\Conversion\\SGML_WIP\\mg1813\\ToyotaEWD\\"+files.get(i).substring(files.get(i).lastIndexOf("\\")));
			}
		}
		System.exit(0);
		
		 String id = "en-US0900";
			System.out.println("en-US0900\"1aa".replaceAll("en-US0900(?!\\d)", "newID"));
		 
		 id = "en-US0900c8af827084ff";
		System.out.println("en-US0900c8af827084ffdd232".replaceAll(id + "?!\\d", "newID"));
		System.exit(0);
		
        String newDir2 = "..\\data\\New Folder";
        flashDir(newDir2);
        System.out.print(count + " items deleted from folder "+newDir2);
	}
	
	public static String getFileName(String fileFullName){
		if(fileFullName == null) return null;
		if(!fileFullName.contains("\\")) return fileFullName;
		return fileFullName.substring(fileFullName.lastIndexOf("\\") + 1);
	}
	/**
	 * Split all files in srcDir (shallow operation, doesn't check sub folder) into batchs based on given batch size, files will be processed in ascending order

	 */
	public static void splitFilesIntoBatchs(String srcDir, int batchSize) throws Exception{
		pl("Splitting files into batchs; batchSize=" + batchSize + "; folder="+srcDir);
		List<String> files = getAllFilesWithCertainExt(srcDir, "");
		if(files.size() <= batchSize){
			pl("Abort, number of files is no more than batch size; count=" + files.size() + "; batchSize="+batchSize);
			return;
		}
		pl("number of files =" + files.size() + "; batchSize="+batchSize);
		Collections.sort(files);
		
		int batchs = (files.size() / batchSize);
		if(files.size() % batchSize != 0){
			batchs++;
		}
		for(int i=1; i<= batchs; i++){
			String newDir = srcDir + "batch-" + i  + "\\";
			if(new File(newDir).exists()){
				throw new Exception("Batch folder already exist: "+newDir);
			}
			pl("Creating new batch dir:" + newDir);
			flashDir (newDir);
		}
		
		for(int i=0; i<files.size(); i++){
			String file = files.get(i);
			String destDir = srcDir + "batch-" +( i/batchSize + 1) + "\\";
			FileUtil.moveFile_OverWrite(srcDir + file, destDir + file);
		}
		pl(files.size() + " files split into " + batchs + " batchs");
	}
	
	/**
	 * compare two files, return true if they are identical, false otherwise 
	 * @throws Exception 
	 */
	public static boolean compareFiles_Binary(String file1, String file2) throws Exception{
		List<String> result = CMDUtil.compairFilesBase_Binary(file1, file2);
		//for(String s:result) System.out.println(s);
		if(result.get(1).equalsIgnoreCase("FC: no differences encountered")){
			return true;
		}
		return false;
	}
	
	/**
	 * to check if two files have same binary content
	 */
	public static boolean isSameFile(String file1, String file2) throws Exception {
		File f1 = new File(file1);
		File f2 = new File(file2);
		if(!f1.exists() || !f2.exists()){
			throw new Exception("File(s) not found; "+ file1 + "  " + file2);
		}
		return FileUtil.compareFiles_Binary(file1, file2);
	}
	

	/*public static String reader (String fileName) throws Exception{
		StringBuffer buffer = new StringBuffer();
		BufferedReader in = new BufferedReader(new FileReader(fileName));
		char ch;
		while ((ch = (char)in.read()) > -1) {
			buffer.append(ch);
		}
		in.close();
		return buffer.toString();
	}*/
	
	/*public static String reader (String fileName) throws Exception{
		StringBuilder builder = new StringBuilder();
		BufferedReader in = new BufferedReader(new FileReader(fileName));
		String line;
		while ((line = in.readLine()) != null) {
			builder.append(line);
			builder.append(System.getProperty("line.separator"));
		}
		in.close();
		return builder.toString();
	}*/
	
	public static String reader (String fileName) throws Exception{
		StringBuilder builder = new StringBuilder();
		InputStream fis = new FileInputStream(fileName);
		BufferedReader in = new BufferedReader(new InputStreamReader(fis, Charset.forName("UTF-8")));
		int ch;
		while ((ch = in.read()) > -1) {
			//System.out.println("line="+Integer.toHexString(ch));
			builder.append((char)ch);
			//builder.append(System.getProperty("line.separator"));
		}
		in.close();
		return builder.toString();
	}
	
	public static StringBuilder reader_UTF8_Str (String str) throws Exception{
		StringBuilder builder = new StringBuilder();
		InputStream fis = new ByteArrayInputStream(str.getBytes());
		BufferedReader in = new BufferedReader(new InputStreamReader(fis, Charset.forName("UTF-8")));
		int ch;
		while ((ch = in.read()) > -1) {
			//System.out.println("line="+Integer.toHexString(ch));
			builder.append((char)ch);
			//builder.append(System.getProperty("line.separator"));
		}
		in.close();
		return builder;
	}
	
	/*public static String reader (String fileName) throws Exception{
		String result = "";
			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String str;
			while ((str = in.readLine()) != null) {
				result += str;
				result += System.getProperty("line.separator");
			}
			in.close();
		return result;
	}*/

	public static void writer (String fileName, String content) throws Exception{
		Writer out = new BufferedWriter(new OutputStreamWriter(
			    new FileOutputStream(fileName), "UTF-8"));
			try {
			    out.write(content);
			} finally {
			    out.close();
			}
	}
	
	/*	public static void writer (String fileName, String content) throws Exception{
			BufferedWriter out = new BufferedWriter(new FileWriter(fileName));
			out.write(content);
			out.close();
	}*/
	
	//to move file from sourceFile to DestFile, overwrite if already exist
	public static boolean moveFile_OverWrite (String sourceFile, String DestFile) throws Exception{
		File destF = new File(DestFile);
		File sourceF = new File(sourceFile);
		return moveFile_OverWrite(sourceF, destF);
}
	
	//to move file from sourceFile to DestFile, overwrite if already exist
	public static boolean moveFile_OverWrite (File sourceF, File destF) throws Exception{
		if(destF.exists())
			destF.delete();
		return sourceF.renameTo(destF);
}

	
	public static void appendWriter (String fileName, String content) throws Exception{
		BufferedWriter out = new BufferedWriter(new FileWriter(fileName, true)) ;
		out.write(content);
		out.close();
}
	/**
	 * set deep to true to retrieve files in subfolders as well 
	 * <p>Note that deep=true return file full names, deep=false only return file names w/o folder info</p>
	 */
	public static List<String> getAllFilesWithCertainExt (String dir, final String extenstion, boolean deep)  throws Exception {
		if(deep){
			final List<String> result = new ArrayList<>();
			Files.walkFileTree(Paths.get(dir), new SimpleFileVisitor<Path>() {
		        @Override
		        public FileVisitResult visitFile(Path file, java.nio.file.attribute.BasicFileAttributes attrs)
		                throws IOException {
		        	String fullPath = file.toString();
		        	if(fullPath.toLowerCase().endsWith(extenstion.toLowerCase())){
		        		result.add(fullPath);
		        	}
		            
		            return FileVisitResult.CONTINUE;
		        }
		    });
			return result;
		}else{
			return getAllFilesWithCertainExt (dir, extenstion);
		}

	}
	
		public static List<String> getAllFilesWithCertainExt_CMD (String dir, String extenstion, boolean deep)  throws Exception {
		if(deep){
			String command = "dir /b /s " + dir + "*." + extenstion; 
			//N:\Automation\Toyota\In\in\09ES350_RM10K0U_EN_10-03-19_UB\graphics\gif\E050367.gif
			//System.out.println("command:"+command);
			List<String> files = CMDUtil.callCMD(command);
			return files;
		}else{
			return getAllFilesWithCertainExt (dir, extenstion);
		}
	}
	
	/**
	 * make @extension as empty string to include all files <br>
	 * extension is case insensitive
	 */
	public static List<String> getAllFilesWithCertainExt (String dir, String extenstion) {
		List<String> result = new ArrayList<String>();
	    File folder = new File(dir);
	    File[] listOfFiles = folder.listFiles();

	    for (int i = 0; i < listOfFiles.length; i++) {
	      if (listOfFiles[i].isFile() && listOfFiles[i].getName().toLowerCase().endsWith(extenstion.toLowerCase())) {
	        result.add(listOfFiles[i].getName());
	    }}
	    Collections.sort(result);
	    return result;
	}
	
	public static List<String> getAllFilesWithKeywords (String dir, String keyWord) {
		List<String> result = new ArrayList<String>();
	    File folder = new File(dir);
	    File[] listOfFiles = folder.listFiles();

	    for (int i = 0; i < listOfFiles.length; i++) {
	      if (listOfFiles[i].isFile() && listOfFiles[i].getName().contains((keyWord))) {
	        result.add(listOfFiles[i].getName());
	    }}
	    return result;
	}
	
	public static List<String> getAllFilesWithKeywords (String dir, String keyWord, boolean deep) {
		List<String> result = new ArrayList<String>();

		File folder = new File(dir);
		//System.out.println("folder.isDirectory():"+folder.isDirectory());
	    File[] listOfFiles = folder.listFiles();

	    for (int i = 0; i < listOfFiles.length; i++) {
	      if (listOfFiles[i].isFile()) {
	    	  if(listOfFiles[i].getName().contains((keyWord))){
	    		  result.add(dir + listOfFiles[i].getName());	  
	    	  }
	      }else if(listOfFiles[i].isDirectory()){//folder
	    	  if(deep){
	    		  result.addAll(getAllFilesWithKeywords (listOfFiles[i].getAbsolutePath()+"\\" , keyWord, true));  
	    	  }
	      }
	    }
	    return result;
	}
	
	public static String findFileInDirTree (String rootDir, final String fileName) throws Exception {
    	final List<String> result = new ArrayList<>();
		Files.walkFileTree(Paths.get(rootDir), new SimpleFileVisitor<Path>() {
		    @Override 
		    public FileVisitResult visitFile(Path aFile, BasicFileAttributes aAttrs) throws IOException {
		    	if(aFile.getFileName().toString().contains(fileName)){
		    		System.out.println("Found file:" + aFile);
		    		result.add(aFile.toString());
		    	}
		      return FileVisitResult.CONTINUE;
		    }
		});
		return result.get(0);
	}
	
	 /**
     * Deletes the directory passed in.
     * @param dir Directory to be deleted
     */
    private static void doDeleteEmptyDir(String dir) {

        boolean success = (new File(dir)).delete();

        if (success) {
            System.out.println("Successfully deleted empty directory: " + dir);
        } else {
            System.out.println("Failed to delete empty directory: " + dir);
        }

    }
    
    /**
     * Deletes all files and subdirectories under "dir".
     * @throws InterruptedException 
     */
    public static void flashDir(String dir) {
    	File d = new File(dir);
    	
    	if(d.exists() && d.list().length==0)
    		return;
    	
    	deleteDir(d);
    	if(!d.mkdir()){
    		try {
				Thread.sleep(1000) ;
			} catch (InterruptedException e) {
				throw new RuntimeException(e);
			}
    		boolean success = d.mkdir();
    		if(!success){
    			throw new RuntimeException("Failed to create folder "+dir);
    		}
    	}
    }

    /**
     * Deletes all files and subdirectories under "dir".
     * @param dir Directory to be deleted
     * @return boolean Returns "true" if all deletions were successful.
     *                 If a deletion fails, the method stops attempting to
     *                 delete and returns "false".
     */
    public static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i=0; i<children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                count++;
                if (!success) {
                    return false;
                }
            }
        }
        // The directory is now empty so now it can be smoked
        return dir.delete();
    }
    
	/**
	 * move all files (including files in subfolder) in sourceDir with specified
	 * extension to destDir, subfolder structure in sourceDir will be removed in destDir
	 * @throws IOException  
	 */
	public static void moveFiles(String sourceDir, String destDir, boolean overwrite,
			String... fileExtensions) throws IOException  {
		File source = new File(sourceDir);

		if (source.isDirectory()) {
			String[] children = source.list();
			for (int i = 0; i < children.length; i++) {
				moveFiles(sourceDir + "\\" + children[i], destDir,overwrite, fileExtensions);
			}
		} else {
			for (String ext : fileExtensions) {
				if (source.getName().endsWith(ext)) {
					Path sourceFile = Paths.get(source.getAbsolutePath());
					Path target = Paths.get(destDir + source.getName());
					//Files.move(sourceFile, target, StandardCopyOption.REPLACE_EXISTING);
					if(overwrite){
						Files.move(sourceFile, target, StandardCopyOption.REPLACE_EXISTING);	
					}else{
						try{
							Files.move(sourceFile, target);	
						}catch(java.nio.file.FileAlreadyExistsException e){
							System.out.println("Skipping existing file:"+source.getAbsolutePath());
						}
					}
				}
			}
		}
	}
	
	/*Path source = Paths.get("C:\\My Documents\\Stuff.txt");
	Path target = Paths.get("D:\\Backup\\MyStuff.txt");
	Files.move(source, target, REPLACE_EXISTING, COPY_ATTRIBUTES);
	*/
	/*public static void moveFiles(String sourceDir, String destDir,
			String... fileExtensions) {
		File source = new File(sourceDir);

		if (source.isDirectory()) {
			String[] children = source.list();
			for (int i = 0; i < children.length; i++) {
				moveFiles(sourceDir + "\\" + children[i], destDir, fileExtensions);
			}
		} else {
			for (String ext : fileExtensions) {
				if (source.getName().endsWith(ext)) {
					if(source.renameTo(new File(destDir, source.getName()))){
						System.out.println("file "+ source.getName() + " successfully moved to "+ destDir);
					}else{
						System.err.println("file "+ source.getName() + " FAILED moved to "+ destDir);
						System.err.println("file "+ source.getAbsolutePath() + " FAILED moved to "+ destDir);
					}
				}
			}
		}
	}*/
	
	/**
	 * copy files in overwrite mode 
	 */
	public static int copyFiles(String sourceDir, String destDir,
			String... fileExtensions) throws Exception{
		count = 0;
		_copyFiles(sourceDir, destDir,fileExtensions);
		System.out.println(count + " files copied from "+ sourceDir + " to "+ destDir);
		return count;
	}
	
	/**
	 * copy all files (including files in subfolder) in sourceDir with specified
	 * extension to destDir, subfolder structure in sourceDir will be removed in destDir
	 */
	private static void _copyFiles(String sourceDir, String destDir,
			String... fileExtensions) throws Exception{
		File source = new File(sourceDir);
		if (source.isDirectory()) {
			String[] children = source.list();
			for (int i = 0; i < children.length; i++) {
				_copyFiles(sourceDir + "\\" + children[i], destDir, fileExtensions);
			}
		} else {
			for (String ext : fileExtensions) {
				if (source.getName().endsWith(ext)) {
					//source.renameTo(new File(destDir, source.getName()));
					copyFile(sourceDir , destDir + "\\" + source.getName() );
					count++;
				}
			}
		}
	}
	
	/**
     * Copies folder to destination location
     * @param source
     * @param destination
	 * @throws Exception 
     */
    public static void copyFolder(File source, File destination) throws Exception
    {
        if (source.isDirectory())
        {
            if (!destination.exists())
            {
                destination.mkdirs();
            }

            String files[] = source.list();

            for (String file : files)
            {
                File srcFile = new File(source, file);
                File destFile = new File(destination, file);

                copyFile(srcFile.getAbsolutePath(), destFile.getAbsolutePath());
            }
        }
    }
	
	  public static void copyFile(String srFile, String dtFile) throws Exception{
		      File f1 = new File(srFile);
		      File f2 = new File(dtFile);
		      InputStream in = new FileInputStream(f1);
		      
		      //For Append the file.
		      //OutputStream out = new FileOutputStream(f2,true);

		      //For Overwrite the file.
		      OutputStream out = new FileOutputStream(f2);

		      byte[] buf = new byte[1024];
		      int len;
		      while ((len = in.read(buf)) > 0){
		        out.write(buf, 0, len);
		      }
		      in.close();
		      out.close();
		  }
	  
		/**
		 * to serialize input object to a file 
		 */
		public static void serialize(Object obj, String fileName) throws Exception{
			FileOutputStream fos = new FileOutputStream(fileName);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(obj); 
			oos.flush();
			oos.close(); 
		}
		
		/**
		 * read serialize object file back to object 
		 */
		public static Object deSerialize(String fileName) throws Exception{
			FileInputStream fis = new FileInputStream(fileName);
			ObjectInputStream ois = new ObjectInputStream(fis);
			Object obj = ois.readObject();
			ois.close(); 
			return obj;
		}

    
    /**
     * Deletes all files and subdirectories under "dir".
     * @param dir Directory to be deleted
     * @return boolean Returns "true" if all deletions were successful.
     *                 If a deletion fails, the method stops attempting to
     *                 delete and returns "false".
     */
    public static boolean deleteDir(String dir) {
    	return deleteDir(new File(dir));
    }


	


}
