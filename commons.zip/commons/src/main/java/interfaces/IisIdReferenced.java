package interfaces;

/**
 * THis is a strategy interface
 * 
 *   method isReferencedID return if element e's id is referenced or not
 *
 */
public interface IisIdReferenced<E> {
	boolean isReferenced(E e);
}
