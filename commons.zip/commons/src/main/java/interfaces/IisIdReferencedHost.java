/**
 * 
 */
package interfaces;

import org.w3c.dom.Element;

/**
 * This is a host class to hold concrete IisIdReferenced strategies
 *
 */
public class IisIdReferencedHost {
	
	public static final IisIdReferenced<Element> DUMMY_ID_STRATEGY = new IisIdReferenced<Element>(){
		public boolean isReferenced(Element e){
			return e.getAttribute("id").startsWith("dummy")?false:true;
		}
	};

}
